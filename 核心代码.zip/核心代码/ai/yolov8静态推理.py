#此文件能初步运行YOLOv8模型并保存推理结果（静态图片）
#注意要改模型路径
from libs.YOLO import YOLOv8
from libs.Utils import *
import os,sys,gc
import image#导入图像处理模块
import ulab.numpy as np#导入轻量级的numpy模块
import json  # 新增：用于保存检测结果为JSON文件

def Yolo_detect():
    #导入图片，模型的例子
    img_path = "/sdcard/examples/16-AI-Cube/logo.jpg"
    kmodel_path = "/sdcard/examples/kmodel/yolov8n_320.kmodel"
    labels = ["stone"]
    model_input_size = [640,640]

    # 新增：定义保存路径（确保目录存在）
    save_img_path = "/sdcard/examples/16-AI-Cube/detect_result.jpg"  # 保存绘制后的图片
    save_res_path = "/sdcard/examples/16-AI-Cube/detect_result.json"  # 保存检测结果数据

    #导入img
    img,img_ori = read_image(img_path)
    rgb888p_size=[img.shape[2],img.shape[1]]

    #定义yolo检测模式
    yolo=YOLOv8(task_type="detect",mode="image",kmodel_path=kmodel_path,labels=labels,
                rgb888p_size=[640,640],model_input_size=model_input_size,
                conf_thresh=0.5,nms_thresh=0.25,max_boxes_num=50,debug_mode=0)

    #预处理配置函数
    yolo.config_preprocess()

    #运行(检测图片img,返回检测框位置，分数，类别索引列表) img格式为ulab.numpy.ndarray
    res = yolo.run(img)

    #在屏幕或图像上绘制推理结果
    yolo.draw_result(res,img_ori)

    # ====================== 新增：保存推理结果 ======================
    # 1. 保存绘制了检测框的图片（核心）
    try:
        # 将img_ori（ulab数组）转换为image.Image对象，再保存为JPG
        if isinstance(img_ori, np.ndarray):
            # 适配CanMV的image模块：创建Image对象
            draw_img = image.Image(img_ori.shape[2], img_ori.shape[1], image.RGB888,
                                  alloc=image.ALLOC_REF, data=img_ori)
            # 保存图片到指定路径
            draw_img.save(save_img_path)
            print(f"绘制后的图片已保存至：{save_img_path}")
    except Exception as e:
        print(f"保存图片失败：{e}")

    # 2. 保存检测结果数据（坐标、置信度、类别，JSON格式，易读取）
    try:
        # 格式化检测结果（将tuple/list转为易读的字典）
        detect_results = []
        for i, obj in enumerate(res):
            # 检测框格式：x1, y1, x2, y2, score, class_id
            x1, y1, x2, y2, score, class_id = obj
            result_dict = {
                "目标序号": i+1,
                "类别": labels[class_id] if class_id < len(labels) else "未知",
                "置信度": round(float(score), 4),  # 保留4位小数
                "检测框坐标": {
                    "x1": int(x1),
                    "y1": int(y1),
                    "x2": int(x2),
                    "y2": int(y2)
                }
            }
            detect_results.append(result_dict)

        # 保存为JSON文件
        with open(save_res_path, 'w') as f:
            json.dump(detect_results, f, ensure_ascii=False, indent=4)
        print(f"检测结果数据已保存至：{save_res_path}")
        print(f"共检测到 {len(detect_results)} 个目标")
    except Exception as e:
        print(f"保存检测结果数据失败：{e}")

    # 资源释放
    yolo.deinit()
    gc.collect()

if __name__=="__main__":
    Yolo_detect()
