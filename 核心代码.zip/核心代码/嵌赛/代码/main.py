'''
主线程（main.py）
├── 初始化所有硬件（Display、Sensor、LVGL、蓝牙、EC200）
├── 启动子线程
└── 主循环：LVGL task_handler（必须在主线程跑） + 蓝牙轮询

子线程1：AI推理线程
├── 从 Sensor 取帧
├── 运行模型推理
├── 绘制OSD结果
└── 受全局状态控制（运行/暂停）

子线程2：EC200推流线程
├── 从队列取帧
└── HTTP/TCP上传到云服务器

#在按键按下前先开始预热模型，保证帧率稳定

'''
#ai检测
from libs.PipeLine import PipeLine, ScopedTiming  
from libs.AI2D import Ai2d  
from libs.AIBase import AIBase
import nncase_runtime as nn
import ulab.numpy as np  
import aidemo  
#硬件驱动
from media.display import *  # 显示模块
from media.media import *  # 媒体管理模块
#固件系统
import utime, os, sys, gc, image  # 时间、系统、垃圾回收模块
import _thread  # 多线程支持
#蓝牙
from machine import UART, FPIOA
#云服务器（EC200）
import network,socket
#lvgl控件
import lvgl as lv
from machine import TOUCH

from media.uvc import *
import uctypes

#屏幕
DISPLAY_WIDTH = 960
DISPLAY_HEIGHT = 536
# LVGL 小窗口，放屏幕左上角
LVGL_W = 160
LVGL_H = 300
LVGL_X = 0
LVGL_Y = 0

rgb888p_size = [640, 480]       # UVC原始分辨率，AI2D自动padding到640x640
display_size = [960, 536]       # 显示分辨率
#蓝牙串口
BT_UART = UART.UART2
BT_TX_PIN = 11          # FPIOA引脚号
BT_RX_PIN = 12
BT_BAUDRATE = 9600
# 图像传输质量
JPEG_QUALITY = 50

#服务端口
SERVER_HOST    = "8.156.80.207"
SERVER_PORT    = 8080  # 裸TCP端口，和Flask 8080分开

#sock = None           # TCP socket


# --- 线程安全的状态管理 ---
_state_lock = _thread.allocate_lock()#状态锁，保护_ai_det_stop、_running、_stream_enabled等变量的读写
_confidence_lock = _thread.allocate_lock()#线程锁，保护置信度等变量的读写
_queue_lock = _thread.allocate_lock()#帧队列锁，保护_frame_queue等变量的读写
_sock_lock = _thread.allocate_lock()#socket锁，保护sock变量的读写

# 内部状态变量
_ai_det_stop = False
_running = False
_stream_enabled = False
_confidence_threshold = 0.5#默认值

def set_ai_det_stop(val):
    with _state_lock:
        global _ai_det_stop
        _ai_det_stop = val

def is_ai_det_stop():
    with _state_lock:
        return _ai_det_stop

def set_running(val):
    with _state_lock:
        global _running
        _running = val

def is_running():
    with _state_lock:
        return _running

def set_stream_enabled(val):
    with _state_lock:
        global _stream_enabled
        _stream_enabled = val

def is_stream_enabled():
    with _state_lock:
        return _stream_enabled
    
def change_confidence_threshold(val):
    with _confidence_lock:
        global _confidence_threshold
        _confidence_threshold = val
def get_confidence_threshold():
    with _confidence_lock:
        return _confidence_threshold
def align_to_8(x): return (x // 8) * 8
def align_to_16(x): return (x // 16) * 16

# ========================
# 帧队列（AI线程 -> 推流线程）
# ========================

_frame_queue = []
# 发送队列长度
QUEUE_SIZE = 2
def queue_put(jpeg_bytes):
    global _frame_queue
    with _queue_lock:
        while len(_frame_queue) >= QUEUE_SIZE:
            _frame_queue.pop(0)
        _frame_queue.append(jpeg_bytes)

def queue_get():
    with _queue_lock:
        if _frame_queue:
            return _frame_queue.pop(0)
    return None

class ObjectDetectionApp(AIBase):
    """YOLOv8目标检测应用类（继承自AIBase）"""

    def __init__(self, kmodel_path, labels, model_input_size, max_boxes_num,
                 confidence_threshold = get_confidence_threshold(), nms_threshold=0.2,
                 rgb888p_size=[224,224], display_size=[1920,1080], debug_mode=0):
        """
        初始化YOLO检测器
        Args:
            kmodel_path: kmodel模型文件路径
            labels: 类别标签列表
            model_input_size: 模型输入尺寸 [w, h]
            max_boxes_num: 最大检测框数量
            confidence_threshold: 置信度阈值
            nms_threshold: NMS阈值
            rgb888p_size: Sensor给AI的图像分辨率
            display_size: 显示分辨率
            debug_mode: 调试模式（0=关闭，>0=开启）
        """
        super().__init__(kmodel_path, model_input_size, rgb888p_size, debug_mode)
        self.kmodel_path = kmodel_path
        self.labels = labels
        self.model_input_size = model_input_size
        self.confidence_threshold = confidence_threshold
        self.nms_threshold = nms_threshold
        self.max_boxes_num = max_boxes_num

        # 分辨率对齐（满足硬件要求）
        self.rgb888p_size = [align_to_16(rgb888p_size[0]), rgb888p_size[1]]
        self.display_size = [align_to_16(display_size[0]), align_to_8(display_size[1])]
        self.debug_mode = debug_mode

        # 坐标缩放因子（模型坐标 -> Sensor坐标）
        self.x_factor = float(self.rgb888p_size[0]) / self.model_input_size[0]
        self.y_factor = float(self.rgb888p_size[1]) / self.model_input_size[1]

        # AI2D预处理对象（用于图像缩放、填充等）
        self.ai2d = Ai2d(debug_mode)
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.RGB_packed, nn.ai2d_format.NCHW_FMT,
                                  np.uint8, np.uint8)

    def config_preprocess(self, input_image_size=None):
        """配置图像预处理流程（缩放+填充）"""
        with ScopedTiming("set preprocess config", self.debug_mode > 0):
            ai2d_input_size = input_image_size if input_image_size else self.rgb888p_size
            # 计算填充参数
            top, bottom, left, right = self.get_padding_param()
            # 添加填充（灰色背景）
            self.ai2d.pad([0,0,0,0,top,bottom,left,right], 0, [128,128,128])
            # 双线性插值缩放
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
            # 构建预处理流程
            self.ai2d.build([1, ai2d_input_size[1], ai2d_input_size[0], 3],
                           [1, 3, self.model_input_size[1], self.model_input_size[0]])

    def get_padding_param(self):
        """计算填充参数（保持宽高比的Letterbox填充）"""
        dst_w = self.model_input_size[0]   # 目标宽度
        dst_h = self.model_input_size[1]   # 目标高度
        ratio_w = dst_w / self.rgb888p_size[0]  # 宽度缩放比
        ratio_h = dst_h / self.rgb888p_size[1]  # 高度缩放比
        ratio = min(ratio_w, ratio_h)      # 取较小比例（保持完整图像）

        new_w = int(ratio * self.rgb888p_size[0])  # 缩放后宽度
        new_h = int(ratio * self.rgb888p_size[1])  # 缩放后高度

        # 计算需要填充的像素数
        dw = (dst_w - new_w) / 2
        dh = (dst_h - new_h) / 2
        top = int(round(0))
        bottom = int(round(dh * 2 + 0.1))
        left = int(round(0))
        right = int(round(dw * 2 - 0.1))
        return top, bottom, left, right

    def postprocess(self, results):
        with ScopedTiming("postprocess", self.debug_mode > 0):
            # 人头检测模型输出 [1,6,8400]，6=4坐标+1置信度+1类别
            output = results[0][0]  # shape [6, 8400]
            det_res = aidemo.yolov8_det_postprocess(
                output.transpose().copy(),
                [self.rgb888p_size[1], self.rgb888p_size[0]],#640x480
                [self.model_input_size[1], self.model_input_size[0]],#640x640
                [self.display_size[1], self.display_size[0]],#960x536
                len(self.labels), self.confidence_threshold,
                self.nms_threshold, self.max_boxes_num
            )
            return det_res

    def draw_result(self, osd_img, dets):
        """在OSD图层上绘制检测结果（边界框+标签）"""
        with ScopedTiming("display_draw", self.debug_mode > 0):
            osd_img.clear()  # 清除上一帧残留

            if dets:
                # 遍历所有检测到的目标
                for i in range(len(dets[0])):
                    # 获取原始坐标 (cx, cy, w, h) 中心点格式
                    x, y, w, h = map(lambda v: int(round(v, 0)), dets[0][i])

                    # 中心点转左上角
                    x1 = x
                    y1 = y

                    

                    # 绘制黄色边界框
                    osd_img.draw_rectangle(x1, y1, w, h, color=(255, 255, 0, 255), thickness=2)

                    # 绘制标签和置信度
                    conf = dets[2][i]
                    label_text = f"{self.labels[dets[1][i]]} {conf:.1%}"
                    osd_img.draw_string_advanced(x1, y1-50, 32, label_text, color=(255, 255, 0, 255))

def thread_AI_detect():


    """YOLOv8目标检测线程函数"""
    global uvc, rgb888p_size, display_size, yolo_osd_img

    # YOLO模型配置
    kmodel_path = "/sdcard/examples/kmodel/best_simplified.kmodel"

    labels = ["stones"]

    #confidence_threshold = 0.9
    nms_threshold = 0.2

    ob_det = ObjectDetectionApp(kmodel_path, labels=labels,
                                model_input_size=[640,640],
                                max_boxes_num=50,
                                confidence_threshold=get_confidence_threshold(),
                                nms_threshold=nms_threshold,
                                rgb888p_size=rgb888p_size,
                                display_size=display_size,
                                debug_mode=0)
    ob_det.config_preprocess()


    # FPS计算器
    fps = utime.clock()
    fps.tick()
    frame_count = 0

    print("[预热] 开始...")
    for _ in range(5):
        img_uvc = UVC.snapshot()
        if img_uvc is not None:
            img_uvc = img_uvc.to_rgb565()
            img_ai = img_uvc.to_rgb888()
            img_np = img_ai.to_numpy_ref()
           
            ob_det.run(img_np)
            del img_uvc, img_ai, img_np
    print("[预热] 完成")

    
    last_display_img = None#上一帧图片
    while True:
        if is_ai_det_stop():
            break

        if not is_running():
            yolo_osd_img.clear()
            yolo_osd_img.draw_string_advanced(640, 500, 24, get_osd_status_text(0.0), color=(255, 0, 0))
            Display.show_image(yolo_osd_img, 0, 0, Display.LAYER_OSD1)
            utime.sleep_ms(1)
            continue

        # 获取图像并推理
        img_uvc = UVC.snapshot()
        if img_uvc is None:# 判断图像无效
        
            utime.sleep_ms(10)
            continue
        
        try:
            img_uvc = img_uvc.to_rgb565()  # 用于显示
            img_ai = img_uvc.to_rgb888()   # 用于AI推理
            img_np = img_ai.to_numpy_ref()
            ob_det.confidence_threshold = get_confidence_threshold()

            det_res = ob_det.run(img_np)
            
            

            ob_det.draw_result(yolo_osd_img, det_res)#检测结果
            yolo_osd_img.draw_string_advanced(640, 500, 24, get_osd_status_text(fps.fps()), color=(255, 0, 0))
            
           
            
            # 画面和框 用相同的系数放大
            img_display = img_uvc.scale(x_scale=1.5, y_scale=(536/480))

            
            # # 减轻多余运算，提升帧率（启用EC200上传到云服务器时启用）
            # if is_stream_enabled():
            #     img_ec200 = img_uvc.scale(x_scale=0.5, y_scale=0.5)
            #     jpeg = img_ec200.compressed(JPEG_QUALITY)
            #     queue_put(jpeg)
            #     del img_ec200, jpeg
            if is_stream_enabled():
                # 1. 直接用屏幕显示的那张【已经带框】的图！最简单最稳！
                for i in range(len(det_res[0])):
                    x, y, w, h = map(lambda v: int(round(v, 0)), det_res[0][i])
                    img_display.draw_rectangle(x, y, w, h, color=(255, 255, 0), thickness=2)
    
    # 2. 缩成适合推流的大小
                img_ec200 = img_display.scale(x_scale=0.33, y_scale=0.33)
    
    # 3. 压缩发送（这张图本身就带框！）
                jpeg = img_ec200.compressed(JPEG_QUALITY)
                queue_put(jpeg)
    
                del img_ec200, jpeg
            # ==========================================
            # 3. 居中显示 (计算偏移量，消除黑边不对称)
            # ==========================================
            # 缩放后宽度：640 * 1.1166 = 714
            # 居中偏移量：(960 - 714) / 2 = 123
            OFFSET_X = 0
            OFFSET_Y = 0
            
            # 显示放大后的画面和放大后的框，偏移量必须一致！
            Display.show_image(img_display, OFFSET_X, OFFSET_Y, Display.LAYER_OSD0)
            Display.show_image(yolo_osd_img, OFFSET_X, OFFSET_Y, Display.LAYER_OSD1)
            
            # 安全释放内存
            if last_display_img is not None:
                del last_display_img
            last_display_img = img_display
          

            # 打印检测统计
            frame_count += 1
            fps.tick()
            if frame_count % 10 == 0:
                det_count = len(det_res[0]) if det_res else 0
                print(f"[YOLOv8检测] 检测到 {det_count} 个物体")
                
        finally:
            del img_np
            del img_ai
            del img_uvc 

            if frame_count % 30 == 0:  
                gc.collect()

            

    ob_det.deinit()

def media_init():
    print("media_init OK")
    global yolo_osd_img
    Display.init(Display.NT35516, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, to_ide=False, osd_num=3)

    yolo_osd_img = image.Image(display_size[0], align_to_8(display_size[1]), image.ARGB8888)

    MediaManager.init()
    print("等待UVC摄像头...")
    while True:
        plugin, dev = UVC.probe()
        if plugin:
            print(f"检测到摄像头: {dev}")
            break
        utime.sleep_ms(500)

    mode = UVC.video_mode(640, 480, UVC.FOURCC_YUY2, 30)
    succ, mode = UVC.select_video_mode(mode)
    print(f"select mode success: {succ}, mode: {mode}")
    UVC.start(cvt=True)
    print("media_init OK")

def media_deinit():
    global uvc
    UVC.stop()
    Display.deinit()
    utime.sleep_ms(100)
    MediaManager.deinit()
    print("media_deinit OK")



_sock = None

def get_socket():

    """
    获取socket连接的函数，使用单例模式确保只有一个TCP连接
    如果连接不存在则创建新的连接，如果存在则直接返回
    """
    global _sock  # 声明全局变量_sock，用于存储socket连接
    with _sock_lock:  # 使用锁机制确保线程安全
        if _sock is None:  # 检查socket连接是否存在
            try:
                # 创建TCP socket连接
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
                s.settimeout(5)
                s.connect((SERVER_HOST, SERVER_PORT))
                _sock = s
                print("TCP连接成功")
            except Exception as e:
                print("TCP连接失败:", e)
                _sock = None
        return _sock

def close_socket():
    global _sock
    with _sock_lock:
        if _sock:
            try:
                _sock.close()
            except:
                pass
            _sock = None

def get_net_status_text():
    if not is_stream_enabled():
        return "NET:OFF"

    with _sock_lock:
        if _sock:
            return "NET:OK"

    return "NET:WAIT"

def get_osd_status_text(fps_value):
    return f"FPS:{fps_value:.1f} {get_net_status_text()}"

def send_frame_safe(jpeg_bytes):
    sock = get_socket()
    if not sock:
        return
    
    try:
        size = len(jpeg_bytes)
        header = bytes([(size>>24)&0xFF, (size>>16)&0xFF, (size>>8)&0xFF, size&0xFF])
        sock.send(header + jpeg_bytes)
    except Exception as e:
        print("发送失败:", e)
        close_socket() # 安全关闭并置空

def thread_EC200():
    nic = network.LAN()
    utime.sleep(2)
    #print(f"EC200 IP: {nic.ifconfig()[0]}")
    nic_info = nic.ifconfig()
    if nic_info:
        ip = nic_info[0]
        print(f"EC200 IP: {ip}")
    else:
        print("⚠️ EC200 网卡未获取到 IP")
    #get_socket()    
    send_fps = utime.clock()
    send_fps.tick()
    sent_count = 0
 

    try:
        while True:
            if is_ai_det_stop():
                break

            os.exitpoint()
            
            if not is_stream_enabled():
                close_socket()
                utime.sleep_ms(100)
                continue
            sock = get_socket()
            if not sock:
                utime.sleep_ms(500)
                continue

            jpeg_byte = queue_get()#从ai模型获取图像
            if jpeg_byte:

                send_frame_safe(jpeg_byte)
                sent_count += 1
                send_fps.tick()
                if sent_count % 10 == 0:
                    print(f"[EC200发送] FPS: {send_fps.fps():.2f}")
            else:
                utime.sleep_ms(10)#让出cpu，避免空转占用过高
    finally:
        close_socket()
     


def disp_drv_flush_cb(disp_drv, area, color):
    global disp_img1, disp_img2
    if disp_drv.flush_is_last() == True:
        if disp_img1.virtaddr() == uctypes.addressof(color.__dereference__()):
            Display.show_image(disp_img1, LVGL_X, LVGL_Y, Display.LAYER_OSD2)
            disp_img1.clear()
        else:
            Display.show_image(disp_img2, LVGL_X, LVGL_Y, Display.LAYER_OSD2)
            disp_img2.clear()
        #utime.sleep(0.01)
    disp_drv.flush_ready()

class touch_screen():
    def __init__(self):
        self.state = lv.INDEV_STATE.RELEASED
        self.indev_drv = lv.indev_create()
        self.indev_drv.set_type(lv.INDEV_TYPE.POINTER)
        self.indev_drv.set_read_cb(self.callback)
        self.touch = TOUCH(0)

    def callback(self, driver, data):
        x, y, state = 0, 0, lv.INDEV_STATE.RELEASED
        tp = self.touch.read(1)
        if len(tp):
            raw_x, raw_y = tp[0].x, tp[0].y
            event = tp[0].event
            # 过滤噪声（无效默认值）
            if raw_x > 960 or raw_y > 536:
                return
            # y轴翻转（触摸屏左下角=屏幕左上角）
            x = raw_x
            y = DISPLAY_HEIGHT - raw_y
            x -= LVGL_X
            y -= LVGL_Y
            if event == 2 or event == 3:
                state = lv.INDEV_STATE.PRESSED
            else:
                state = lv.INDEV_STATE.RELEASED
        data.point = lv.point_t({'x': x, 'y': y})
        data.state = state

def lvgl_init():
    global disp_img1, disp_img2
    lv.init()
    disp_drv = lv.disp_create(LVGL_W, LVGL_H)
    disp_drv.set_flush_cb(disp_drv_flush_cb)
    disp_img1 = image.Image(LVGL_W, align_to_8(LVGL_H), image.BGRA8888)
    disp_img2 = image.Image(LVGL_W, align_to_8(LVGL_H), image.BGRA8888)
    disp_img1.clear()
    disp_img2.clear()
    disp_drv.set_draw_buffers(disp_img1.bytearray(), disp_img2.bytearray(),
                               disp_img1.size(), lv.DISP_RENDER_MODE.FULL)
    disp_drv.set_antialiasing(True)
    
    tp = touch_screen()

def lvgl_deinit():
    global disp_img1, disp_img2
    lv.deinit()
    del disp_img1
    del disp_img2

def btn_clicked_event(event):
    
    btn = lv.btn.__cast__(event.get_target())
    label = lv.label.__cast__(btn.get_user_data())
    if "on" == label.get_text():
        label.set_text("off")
        print("启动ai检测")
        set_running(True)
        
    else:
        label.set_text("on")
        print("停止ai检测")
        set_running(False)
    
    #lv.task_handler()  # 立即刷新界面状态
#推流开关
def stream_btn_event(event):
    btn = lv.btn.__cast__(event.get_target())
    label = lv.label.__cast__(btn.get_user_data())
    if "on" == label.get_text():
        label.set_text("off")
        print("关闭推流")
        set_stream_enabled(False)
    else:
        label.set_text("on")
        print("开启推流")
        set_stream_enabled(True)

def confidence_slider_event(event):
    slider = lv.slider.__cast__(event.get_target())
    value = slider.get_value()
    change_confidence_threshold(value / 100.0)

    label = lv.label.__cast__(slider.get_user_data())
    label.set_text(f"conf {value}%")

def user_gui_init():
    scr = lv.scr_act()
    scr.set_style_bg_color(lv.color_hex(0x000000), 0)
    scr.set_style_bg_opa(lv.OPA.TRANSP, 0)
    scr.set_style_border_opa(lv.OPA.TRANSP, 0)
    scr.set_style_outline_opa(lv.OPA.TRANSP, 0)
    #ai检测开关
    btn = lv.btn(lv.scr_act())
    btn.set_pos(8, 28)
    btn.set_size(144, 44)

    label = lv.label(btn)
    label.set_text('on')
    label.set_style_text_color(lv.color_hex(0xFFFFFF), 0)
    label.center()

    btn.set_user_data(label)
    btn.add_event(btn_clicked_event, lv.EVENT.CLICKED, None)
    #推流开关
    btn_stream = lv.btn(lv.scr_act())
    btn_stream.set_pos(8, 92)
    btn_stream.set_size(144, 44)

    label_stream = lv.label(btn_stream)
    label_stream.set_text('on')
    label_stream.set_style_text_color(lv.color_hex(0xFFFFFF), 0)
    label_stream.center()

    btn_stream.set_user_data(label_stream)
    btn_stream.add_event(stream_btn_event, lv.EVENT.CLICKED, None)

    conf_label = lv.label(lv.scr_act())
    conf_label.set_pos(8, 156)
    conf_label.set_style_text_color(lv.color_hex(0xFFFFFF), 0)
    conf_label.set_text(f"conf {int(get_confidence_threshold() * 100)}%")

    conf_slider = lv.slider(lv.scr_act())
    conf_slider.set_pos(8, 188)
    conf_slider.set_size(144, 24)
    conf_slider.set_range(1, 99)
    conf_slider.set_value(int(get_confidence_threshold() * 100), lv.ANIM.OFF)
    conf_slider.set_user_data(conf_label)
    conf_slider.add_event(confidence_slider_event, lv.EVENT.VALUE_CHANGED, None)

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    #硬件启动
    media_init()
    #默认状态：AI检测暂停，推流关闭
    set_running(False)
    set_stream_enabled(False)
    # ai推理+图像发送
    _thread.start_new_thread(thread_AI_detect, ())
    utime.sleep_ms(100)

    # EC200推理到云服务器
    _thread.start_new_thread(thread_EC200, ())
    

    utime.sleep_ms(100)

    try:
        lvgl_init()
        user_gui_init()

        while True:
            lv.task_handler()
            os.exitpoint()
            utime.sleep_ms(5)
    except BaseException as e:
        print(f"程序异常退出: {e}")
        sys.print_exception(e)
        set_ai_det_stop(True)#停止子线程
        utime.sleep_ms(500)  # 等子线程退出
    finally:
        lvgl_deinit()
        media_deinit()
        gc.collect()

if __name__ == "__main__":
    main()
