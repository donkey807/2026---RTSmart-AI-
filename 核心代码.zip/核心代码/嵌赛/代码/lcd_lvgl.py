from media.display import *
from media.media import *
from media.sensor import *
import time, os, sys, gc, uctypes
import lvgl as lv
from machine import TOUCH

def align_to_8(value):
    return (value // 8) * 8

DISPLAY_WIDTH  = 960
DISPLAY_HEIGHT = 540

# LVGL 小窗口，放右下角
LVGL_W = 80
LVGL_H = 40
LVGL_X = DISPLAY_WIDTH - LVGL_W
LVGL_Y = DISPLAY_HEIGHT - LVGL_H

def display_init():
    Display.init(Display.NT35516, width=960, height=540, to_ide=True, osd_num=2)
    sensor = Sensor(fps=30)
    sensor.reset()
    sensor.set_framesize(w=960, h=536, chn=CAM_CHN_ID_0)
    sensor.set_pixformat(Sensor.YUV420SP)
    sensor_bind_info = sensor.bind_info(x=0, y=0, chn=CAM_CHN_ID_0)
    Display.bind_layer(**sensor_bind_info, layer=Display.LAYER_VIDEO1)
    MediaManager.init()
    sensor.run()
    return sensor

def display_deinit(sensor=None):
    os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
    if sensor:
        sensor.stop()
    time.sleep_ms(50)
    Display.deinit()
    MediaManager.deinit()

def disp_drv_flush_cb(disp_drv, area, color):
    global disp_img1, disp_img2
    if disp_drv.flush_is_last() == True:
        if disp_img1.virtaddr() == uctypes.addressof(color.__dereference__()):
            Display.show_image(disp_img1, LVGL_X, LVGL_Y, Display.LAYER_OSD1)
        else:
            Display.show_image(disp_img2, LVGL_X, LVGL_Y, Display.LAYER_OSD1)
        time.sleep(0.01)
    disp_drv.flush_ready()

class touch_screen():
    def __init__(self):
        self.state = lv.INDEV_STATE.RELEASED
        self.indev_drv = lv.indev_create()
        self.indev_drv.set_type(lv.INDEV_TYPE.POINTER)
        self.indev_drv.set_read_cb(self.callback)
        self.touch = TOUCH(0)

    def callback(self, driver, data):
        x, y, state = 0, 0, lv.INDEV_STATE.RELEASED
        tp = self.touch.read(1)
        if len(tp):
            x, y, event = tp[0].x, tp[0].y, tp[0].event
            x -= LVGL_X
            y -= LVGL_Y
            if event == 2 or event == 3:
                state = lv.INDEV_STATE.PRESSED
        data.point = lv.point_t({'x': x, 'y': y})
        data.state = state

def lvgl_init():
    global disp_img1, disp_img2
    lv.init()
    disp_drv = lv.disp_create(LVGL_W, LVGL_H)
    disp_drv.set_flush_cb(disp_drv_flush_cb)
    disp_img1 = image.Image(LVGL_W, align_to_8(LVGL_H), image.BGRA8888)
    disp_img2 = image.Image(LVGL_W, align_to_8(LVGL_H), image.BGRA8888)
    disp_drv.set_draw_buffers(disp_img1.bytearray(), disp_img2.bytearray(),
                               disp_img1.size(), lv.DISP_RENDER_MODE.FULL)
    tp = touch_screen()

def lvgl_deinit():
    global disp_img1, disp_img2
    lv.deinit()
    del disp_img1
    del disp_img2

def btn_clicked_event(event):
    btn = lv.btn.__cast__(event.get_target())
    label = lv.label.__cast__(btn.get_user_data())
    if "on" == label.get_text():
        label.set_text("off")
    else:
        label.set_text("on")

def user_gui_init():
    scr = lv.scr_act()
    scr.set_style_bg_color(lv.color_hex(0x000000), 0)  # 黑色背景

    #scr.set_style_bg_opa(0, 0)  # 0 = 完全透明
    #scr.set_style_border_width(0, 0)
    btn = lv.btn(lv.scr_act())
    btn.set_size(80, 40)
    btn.align(lv.ALIGN.CENTER, 0, 0)
    label = lv.label(btn)
    label.set_text('on')
    label.center()
    btn.set_user_data(label)
    btn.add_event(btn_clicked_event, lv.EVENT.CLICKED, None)

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    sensor = None
    try:
        sensor = display_init()
        lvgl_init()
        user_gui_init()
        while True:
            time.sleep_ms(lv.task_handler())
    except BaseException as e:
        sys.print_exception(e)
    finally:
        lvgl_deinit()
        display_deinit(sensor)
        gc.collect()

if __name__ == "__main__":
    main()