import network
import time

# 不用 active(True)，系统已经自动开了
wifi = network.WLAN(network.STA_IF)

# 连接你的路由器
wifi.connect("12345", "12345678")

# 等待连接成功
while not wifi.isconnected():
    print("正在连接 WiFi...")
    time.sleep(1)

# 连接成功后打印 IP
print("WiFi 连接成功！")
print("IP信息：", wifi.ifconfig())