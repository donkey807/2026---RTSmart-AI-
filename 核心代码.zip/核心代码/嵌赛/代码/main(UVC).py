import os
import sys
import time
import urandom

from media.display import *
from media.media import *
from libs.WBCRtsp import WBCRtsp


DISPLAY_WIDTH = ALIGN_UP(640, 16)
DISPLAY_HEIGHT = 480


def main():
    os.exitpoint(os.EXITPOINT_ENABLE)

    try:
        Display.init(Display.VIRT, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, fps=60, to_ide=False)
        MediaManager.init()

        img = image.Image(DISPLAY_WIDTH, DISPLAY_HEIGHT, image.ARGB8888)
        WBCRtsp.configure(wbc_width=DISPLAY_WIDTH, wbc_height=DISPLAY_HEIGHT)
        WBCRtsp.start()

        fps = time.clock()
        frame_count = 0

        print("RTSP server started: rtsp://192.168.43.100:8554/test")

        try:
            while True:
                os.exitpoint()
                fps.tick()

                img.clear()

                # 固定背景块，保证画面永远有内容
                img.draw_rectangle(0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT, color=(0, 0, 0, 255), thickness=0)
                img.draw_rectangle(40, 40, 220, 140, color=(255, 255, 0, 255), thickness=6)
                img.draw_string_advanced(60, 70, 32, "RTSP OK", color=(0, 255, 0, 255))
                img.draw_string_advanced(60, 120, 24, f"frame:{frame_count}", color=(255, 255, 255, 255))

                # 做一点变化，防止 VLC 看到静帧误判
                x = (frame_count * 5) % (DISPLAY_WIDTH - 60)
                y = (frame_count * 3) % (DISPLAY_HEIGHT - 60)
                img.draw_rectangle(x, y, 60, 60, color=(0, 128, 255, 255), thickness=4)

                Display.show_image(img)

                frame_count += 1
                if frame_count % 30 == 0:
                    print(f"fps: {fps.fps():.2f}")

                time.sleep_ms(33)

        except KeyboardInterrupt as e:
            print("user stop:", e)
        except BaseException as e:
            print("program exception:", e)
            try:
                sys.print_exception(e)
            except Exception:
                pass
        finally:
            try:
                WBCRtsp.stop()
            except Exception:
                pass

    finally:
        try:
            Display.deinit()
        except Exception:
            pass
        try:
            MediaManager.deinit()
        except Exception:
            pass
        time.sleep_ms(100)


if __name__ == "__main__":
    main()
