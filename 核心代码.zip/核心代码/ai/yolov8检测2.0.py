import os,sys
from media.sensor import *
from media.display import *
from media.media import *
import nncase_runtime as nn
import ulab.numpy as np
import time,image,random,gc
from libs.Utils import *

#-----------------------------其他必要方法---------------------------------------------
# 多目标检测 非最大值抑制方法实现
def nms(boxes,scores,thresh):
    """Pure Python NMS baseline."""
    x1,y1,x2,y2 = boxes[:, 0],boxes[:, 1],boxes[:, 2],boxes[:, 3]
    areas = (x2 - x1 + 1) * (y2 - y1 + 1)
    order = np.argsort(scores,axis = 0)[::-1]
    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)
        new_x1,new_y1,new_x2,new_y2,new_areas = [],[],[],[],[]
        for order_i in order:
            new_x1.append(x1[order_i])
            new_x2.append(x2[order_i])
            new_y1.append(y1[order_i])
            new_y2.append(y2[order_i])
            new_areas.append(areas[order_i])
        new_x1 = np.array(new_x1)
        new_x2 = np.array(new_x2)
        new_y1 = np.array(new_y1)
        new_y2 = np.array(new_y2)
        xx1 = np.maximum(x1[i], new_x1)
        yy1 = np.maximum(y1[i], new_y1)
        xx2 = np.minimum(x2[i], new_x2)
        yy2 = np.minimum(y2[i], new_y2)
        w = np.maximum(0.0, xx2 - xx1 + 1)
        h = np.maximum(0.0, yy2 - yy1 + 1)
        inter = w * h
        new_areas = np.array(new_areas)
        ovr = inter / (areas[i] + new_areas - inter)
        new_order = []
        for ovr_i,ind in enumerate(ovr):
            if ind < thresh:
                new_order.append(order[ovr_i])
        order = np.array(new_order,dtype=np.uint8)
    return keep

# 修复：letterbox输入是AI推理帧分辨率（320x320），不是屏幕分辨率
def letterbox_pad_param(input_size,output_size):
    ratio_w = output_size[0] / input_size[0]  # 宽度缩放比例
    ratio_h = output_size[1] / input_size[1]   # 高度缩放比例
    ratio = min(ratio_w, ratio_h)  # 取较小的缩放比例
    new_w = int(ratio * input_size[0])  # 新宽度
    new_h = int(ratio * input_size[1])  # 新高度
    dw = (output_size[0] - new_w) / 2  # 宽度差
    dh = (output_size[1] - new_h) / 2  # 高度差
    # 修复：对称填充（避免图像变形）
    top = int(round(dh - 0.1))
    bottom = int(round(dh + 0.1))
    left = int(round(dw - 0.1))
    right = int(round(dw + 0.1))
    return top, bottom, left, right,ratio

#-----------------------------Sensor/Display初始化部分-------------------------------
# 屏幕宽高对调（横屏：960宽，540高）
DISPLAY_WIDTH = 960
DISPLAY_HEIGHT = 540

# AI推理帧分辨率（保持320x320，模型适配）
AI_RGB888P_WIDTH = 320
AI_RGB888P_HEIGHT = 320

# 摄像头通道0的硬件支持分辨率（关键！必须用sensor支持的YUV420SP分辨率）
# 纯显示能运行的分辨率：536x960（竖屏），对调后用960x536（横屏，sensor支持）
CAM_CHN0_WIDTH = 960
CAM_CHN0_HEIGHT = 536

sensor = Sensor()
sensor.reset()
# 关键：开启镜像/翻转，抵消物理旋转，实现横屏正显（不用改分辨率）
sensor.set_hmirror(True)
sensor.set_vflip(True)

# 配置sensor多通道（核心修正：通道0用sensor支持的分辨率）
# 通道0：显示用，YUV420SP格式，分辨率960x536（sensor硬件支持）
sensor.set_framesize(width = CAM_CHN0_WIDTH, height = 536, chn=CAM_CHN_ID_0)
sensor.set_pixformat(Sensor.YUV420SP, chn=CAM_CHN_ID_0)

# 通道1：AI推理用，RGB888P格式，320x320（不变）
sensor.set_framesize(width = AI_RGB888P_WIDTH , height = AI_RGB888P_HEIGHT, chn=CAM_CHN_ID_1)
sensor.set_pixformat(Sensor.RGBP888, chn=CAM_CHN_ID_1)

# 绑定通道0到屏幕（保持显示流畅）
sensor_bind_info = sensor.bind_info(x = 0, y = 0, chn = CAM_CHN_ID_0)
Display.bind_layer(**sensor_bind_info, layer = Display.LAYER_VIDEO1)

# 修正：OSD图层分辨率匹配屏幕（960x540），避免缓冲区不匹配
osd_img = image.Image(DISPLAY_WIDTH, 536, image.ARGB8888)

# 初始化显示屏（横屏960x540）
Display.init(Display.NT35516, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, osd_num=1, to_ide = True)

# 限制摄像头帧率，匹配显示帧率
sensor._set_chn_fps(chn = CAM_CHN_ID_0, fps = Display.fps())

#-----------------------------AI模型初始化部分-------------------------------
kmodel_path="/sdcard/examples/kmodel/yolov8n_320.kmodel"
labels = ["person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant", "bed", "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone", "microwave", "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush"]
model_input_size=[320,320]
confidence_threshold = 0.3
nms_threshold = 0.4
max_boxes_num = 50
colors=get_colors(len(labels))

# 初始化ai2d预处理（核心修正：输入是AI推理帧分辨率320x320，不是屏幕分辨率）
ai2d=nn.ai2d()
ai2d.set_dtype(nn.ai2d_format.NCHW_FMT, nn.ai2d_format.NCHW_FMT, np.uint8, np.uint8)
# 修正：letterbox输入是AI推理帧分辨率[320,320]
top,bottom,left,right,ratio=letterbox_pad_param([AI_RGB888P_WIDTH,AI_RGB888P_HEIGHT],model_input_size)
ai2d.set_pad_param(True,[0,0,0,0,top,bottom,left,right], 0, [128,128,128])
ai2d.set_resize_param(True,nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
# 修正：AI2D输入维度是通道1的分辨率（320x320），和模型输出匹配
ai2d_builder = ai2d.build([1,3,AI_RGB888P_HEIGHT,AI_RGB888P_WIDTH], [1,3,model_input_size[1],model_input_size[0]])

# 初始化KPU输入tensor
input_init_data = np.ones((1,3,model_input_size[1],model_input_size[0]),dtype=np.uint8)
kpu_input_tensor = nn.from_numpy(input_init_data)

# 创建kpu实例并加载模型
kpu=nn.kpu()
kpu.load_kmodel(kmodel_path)

# media初始化
MediaManager.init()
sensor.run()
fps = time.clock()

while True:
    fps.tick()
    #------------------------图像采集----------------------------------
    img=sensor.snapshot(chn=CAM_CHN_ID_1)
    img_np=img.to_numpy_ref()
    ai2d_input_tensor=nn.from_numpy(img_np)
    
    #------------------------AI预处理----------------------------------
    ai2d_builder.run(ai2d_input_tensor, kpu_input_tensor)
    
    #------------------------模型推理----------------------------------
    kpu.set_input_tensor(0,kpu_input_tensor)
    kpu.run()
    
    #------------------------结果解析----------------------------------
    results=[]
    for i in range(kpu.outputs_size()):
        output_i_tensor = kpu.get_output_tensor(i)
        result_i = output_i_tensor.to_numpy()
        results.append(result_i)
        del output_i_tensor
    
    #------------------------后处理----------------------------------
    output_data=results[0][0].transpose()
    boxes_ori = output_data[:,0:4]
    class_ori = output_data[:,4:]
    class_res=np.argmax(class_ori,axis=-1)
    scores_ = np.max(class_ori,axis=-1)
    
    boxes,inds,scores=[],[],[]
    for i in range(len(boxes_ori)):
        if scores_[i]>confidence_threshold:
            x,y,w,h=boxes_ori[i][0],boxes_ori[i][1],boxes_ori[i][2],boxes_ori[i][3]
            # 修正：坐标还原到AI推理帧（320x320），并做边界保护
            x1 = int((x - left - 0.5 * w)/ratio)
            y1 = int((y - top - 0.5 * h)/ratio)
            x2 = int((x - left + 0.5 * w)/ratio)
            y2 = int((y - top + 0.5 * h)/ratio)
            # 边界保护：避免坐标超出图像范围
            x1 = max(0, min(x1, AI_RGB888P_WIDTH-1))
            y1 = max(0, min(y1, AI_RGB888P_HEIGHT-1))
            x2 = max(0, min(x2, AI_RGB888P_WIDTH-1))
            y2 = max(0, min(y2, AI_RGB888P_HEIGHT-1))
            boxes.append([x1,y1,x2,y2])
            inds.append(class_res[i])
            scores.append(scores_[i])
    
    if len(boxes)==0:
        osd_img.clear()
        Display.show_image(osd_img)
        continue
    
    # NMS去重
    boxes = np.array(boxes)
    scores = np.array(scores)
    inds = np.array(inds)
    keep = nms(boxes,scores,nms_threshold)
    
    # 整理最终结果
    concat_list = [
    boxes,                  # 检测框坐标 (n,4)
    scores.reshape(-1, 1),  # 置信度 (n,1)
    inds.reshape(-1, 1)     # 类别索引 (n,1)
    ]
    # 步骤2：调用concatenate，只传2个参数（列表、轴）
    dets = np.concatenate(concat_list, axis=1)
    det_res = np.array([dets[ki] for ki in keep])[:max_boxes_num]
    
    #------------------------绘制检测框（适配横屏）----------------------------------
    osd_img.clear()
    for det in det_res:
        x1, y1, x2, y2 = map(int, det[:4])
        score = det[4]
        cls_idx = int(det[5])
        
        # 修正：横屏坐标缩放（AI推理帧320x320 → 屏幕960x540）
        scale_w = DISPLAY_WIDTH / AI_RGB888P_WIDTH
        scale_h = DISPLAY_HEIGHT / AI_RGB888P_HEIGHT
        
        draw_x = int(x1 * scale_w)
        draw_y = int(y1 * scale_h)
        draw_w = int((x2 - x1) * scale_w)
        draw_h = int((y2 - y1) * scale_h)
        
        # 绘制框和文字（横屏适配）
        osd_img.draw_rectangle(draw_x, draw_y, draw_w, draw_h, color=colors[cls_idx], thickness=4)
        text_y = max(24, draw_y - 10)
        osd_img.draw_string_advanced(draw_x, text_y, 24, 
                                    f"{labels[cls_idx]} {score:.3f}", 
                                    color=colors[cls_idx])
    
    #------------------------显示结果----------------------------------
    Display.show_image(osd_img)
    print("det fps:",fps.fps())
    gc.collect()

# 释放资源
del ai2d, kpu
sensor.stop()
Display.deinit()
time.sleep_ms(50)
MediaManager.deinit()
nn.shrink_memory_pool()