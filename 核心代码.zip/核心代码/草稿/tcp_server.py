# 阿里云服务器端：接收K230裸TCP推流，转发给浏览器MJPEG
# 运行：python3 tcp_server.py
# 浏览器访问：http://服务器IP:8080/stream

import socket
import threading
import struct
from flask import Flask, Response

app = Flask(__name__)
latest_frame = None
frame_lock = threading.Lock()

# ========================
# TCP Server：接收K230推流
# ========================
def tcp_server():
    global latest_frame
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("0.0.0.0", 8082))
    server.listen(1)
    print("TCP Server 监听 8082，等待K230连接...")

    while True:
        conn, addr = server.accept()
        print(f"K230已连接: {addr}")
        try:
            while True:
                # 读4字节长度头
                raw = b""
                while len(raw) < 4:
                    chunk = conn.recv(4 - len(raw))
                    if not chunk:
                        raise ConnectionError("断开")
                    raw += chunk
                size = struct.unpack(">I", raw)[0]

                # 读完整JPEG数据
                data = b""
                while len(data) < size:
                    chunk = conn.recv(min(4096, size - len(data)))
                    if not chunk:
                        raise ConnectionError("断开")
                    data += chunk

                with frame_lock:
                    latest_frame = data

        except Exception as e:
            print(f"K230断开: {e}")
            conn.close()

# ========================
# Flask：推流给浏览器
# ========================
@app.route('/stream')
def stream():
    def generate():
        import time
        while True:
            with frame_lock:
                frame = latest_frame
            if frame:
                yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            time.sleep(0.03)
    return Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    t = threading.Thread(target=tcp_server, daemon=True)
    t.start()
    print("Flask 启动 8080，浏览器访问 /stream")
    app.run(host='0.0.0.0', port=8080, threaded=True)
