# 水下检测系统 - 多线程版本
# 线程分工：
#   主线程：AI推理 + 本地显示（生产者）
#   线程1：TCP发送图像到PC（消费者）
#   线程2：蓝牙命令监听（控制者）

import os
import sys
import gc
import time
import _thread
import socket
from machine import UART, FPIOA
import nncase_runtime as nn
import ulab.numpy as np
import image

# 媒体库导入
from media.sensor import *
from media.display import *
from media.media import *
from media.uvc import *
from libs.Utils import *

# ==================== 硬件配置区（修改这里） ====================

# 屏幕分辨率
DISPLAY_WIDTH = 960
DISPLAY_HEIGHT = 540

# AI输入分辨率（必须和模型训练时一致）
AI_WIDTH = 320
AI_HEIGHT = 320

# 网络配置（你的电脑IP和端口）
PC_IP = "192.168.1.100"
PC_PORT = 8080

# 蓝牙串口配置
BT_UART = UART.UART2
BT_TX_PIN = 11          # FPIOA引脚号
BT_RX_PIN = 12
BT_BAUDRATE = 9600

# 图像传输质量（1-100，越小带宽占用越低）
JPEG_QUALITY = 50

# 发送队列长度（满了自动丢弃最老的，保证实时性）
QUEUE_SIZE = 2

# ===============================================================

# ==================== 全局状态管理（线程安全） ====================

class SystemState:
    """
    系统全局状态，所有线程共享
    用互斥锁保护，防止数据竞争
    """
    def __init__(self):
        # 创建互斥锁（像C的pthread_mutex_init）
        self.lock = _thread.allocate_lock()
        
        # 控制状态
        self._running = False       # AI是否运行
        self._quality = JPEG_QUALITY # 图像压缩质量
        
        # 统计信息
        self.frame_count = 0        # 总帧数
        self.send_count = 0         # 成功发送帧数
        
    def set_running(self, value):
        """设置运行状态，线程安全"""
        with self.lock:             # 自动获取和释放锁
            self._running = value
            
    def get_running(self):
        """获取运行状态，线程安全"""
        with self.lock:
            return self._running
            
    def set_quality(self, value):
        """设置图像质量"""
        with self.lock:
            # 限制范围1-100
            if value < 1:
                value = 1
            if value > 100:
                value = 100
            self._quality = value
            
    def get_quality(self):
        """获取图像质量"""
        with self.lock:
            return self._quality
            
    def add_frame(self):
        """帧计数+1"""
        with self.lock:
            self.frame_count += 1
            
    def add_send(self):
        """发送计数+1"""
        with self.lock:
            self.send_count += 1

# 创建全局状态实例（所有线程共享这一个）
g_state = SystemState()

# ==================== 图像队列（生产者-消费者） ====================

class ImageQueue:
    """
    线程安全的图像队列
    生产者（AI线程）put，消费者（发送线程）get
    满了自动丢弃最老的，保证实时性不卡顿
    """
    def __init__(self, maxsize):
        self.lock = _thread.allocate_lock()     # 队列操作锁
        self.maxsize = maxsize
        self.queue = []                         # 内部列表
        
    def put(self, img, results):
        """
        生产者调用：放入一帧图像和检测结果
        如果队列满了，丢弃最老的一帧
        """
        with self.lock:
            # 队列满了，丢弃最老的（保证实时性）
            if len(self.queue) >= self.maxsize:
                old_img, old_res = self.queue.pop(0)
                # 注意：img是image对象，需要手动释放内存
                del old_img
                del old_res
                gc.collect()                    # 强制垃圾回收
                
            # 放入新数据
            self.queue.append((img, results))
            
    def get(self):
        """
        消费者调用：取出一帧数据
        如果队列为空，返回None（非阻塞）
        """
        with self.lock:
            if len(self.queue) > 0:
                return self.queue.pop(0)        # 取最老的（FIFO）
        return None

# 创建全局队列
g_queue = ImageQueue(QUEUE_SIZE)

# ==================== 蓝牙初始化（你的原始代码） ====================

def init_bluetooth():
    """
    初始化蓝牙串口
    返回UART对象，失败返回None
    """
    print("[BT] 初始化蓝牙...")
    
    try:
        # 配置FPIOA引脚复用
        fpioa = FPIOA()
        fpioa.set_function(BT_TX_PIN, FPIOA.UART2_TXD)
        fpioa.set_function(BT_RX_PIN, FPIOA.UART2_RXD)
        
        # 初始化UART（像C的serial_init）
        uart = UART(BT_UART, baudrate=BT_BAUDRATE, 
                   bits=UART.EIGHTBITS,
                   parity=UART.PARITY_NONE, 
                   stop=UART.STOPBITS_ONE)
        
        # 部分硬件需要二次init
        uart.init(baudrate=BT_BAUDRATE,
                 bits=UART.EIGHTBITS,
                 parity=UART.PARITY_NONE,
                 stop=UART.STOPBITS_ONE)
        
        print("[BT] 初始化成功")
        return uart
        
    except Exception as e:
        print("[BT] 初始化失败:", e)
        return None

def send_bluetooth(uart, msg):
    """通过蓝牙发送字符串"""
    if uart is None:
        return
    try:
        uart.write(msg + "\r\n")
        print("[BT] 发送:", msg)
    except Exception as e:
        print("[BT] 发送失败:", e)

# ==================== YOLOv8初始化（你的原始代码） ====================

_display_initialized = False

def letterbox_pad_param(input_size, output_size):
    """
    计算letterbox填充参数
    保持图像比例，避免拉伸变形
    """
    ratio_w = output_size[0] / input_size[0]
    ratio_h = output_size[1] / input_size[1]
    ratio = ratio_w if ratio_w < ratio_h else ratio_h
    
    new_w = int(ratio * input_size[0])
    new_h = int(ratio * input_size[1])
    
    dw = (output_size[0] - new_w) / 2
    dh = (output_size[1] - new_h) / 2
    
    top = 0
    bottom = int(round(dh * 2 + 0.1))
    left = 0
    right = int(round(dw * 2 - 0.1))
    
    return top, bottom, left, right, ratio

def nms(boxes, scores, thresh):
    """
    非极大值抑制（NMS）
    去除重叠的检测框，保留置信度最高的
    """
    x1 = boxes[:, 0]
    y1 = boxes[:, 1]
    x2 = boxes[:, 2]
    y2 = boxes[:, 3]
    
    areas = (x2 - x1 + 1) * (y2 - y1 + 1)
    order = np.argsort(scores, axis=0)[::-1]    # 降序排列
    
    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)
        
        # 计算当前框与其余框的IoU
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])
        
        w = np.maximum(0.0, xx2 - xx1 + 1)
        h = np.maximum(0.0, yy2 - yy1 + 1)
        inter = w * h
        
        # IoU = 交集 / 并集
        ovr = inter / (areas[i] + areas[order[1:]] - inter)
        
        # 保留IoU小于阈值的框（不重叠的）
        inds = np.where(ovr <= thresh)[0]
        order = order[inds + 1]
        
    return keep

def init_yolov8():
    """
    初始化YOLOv8模型
    返回包含所有模型资源的字典
    """
    global _display_initialized
    
    print("[YOLO] 初始化YOLOv8...")
    
    # 反初始化显示（确保摄像头绑定成功）
    if _display_initialized:
        try:
            Display.unbind_layer(layer=Display.LAYER_VIDEO1)
        except:
            pass
    
    # 初始化显示
    Display.init(Display.NT35516, 
                width=DISPLAY_WIDTH, 
                height=DISPLAY_HEIGHT,
                osd_num=1, 
                to_ide=True)
    MediaManager.init()
    
    # 等待UVC摄像头插入
    while True:
        plugin, dev_info = UVC.probe()
        if plugin:
            print("[CAM] 摄像头已插入")
            break
        time.sleep_ms(500)
    
    # 选择视频模式
    mode = UVC.video_mode()
    succ, mode = UVC.select_video_mode(mode)
    print("[CAM] 视频模式:", mode)
    
    UVC.start(cvt=False)
    print("[CAM] 摄像头启动成功")
    
    # 模型配置
    kmodel_path = "/sdcard/examples/kmodel/yolov8n_224.kmodel"
    
    labels = ["person", "bicycle", "car", "motorcycle", "airplane", "bus", "train",
              "truck", "boat", "traffic light", "fire hydrant", "stop sign",
              "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep",
              "cow", "elephant", "bear", "zebra", "giraffe", "backpack",
              "umbrella", "handbag", "tie", "suitcase", "frisbee", "skis",
              "snowboard", "sports ball", "kite", "baseball bat", "baseball glove",
              "skateboard", "surfboard", "tennis racket", "bottle", "wine glass",
              "cup", "fork", "knife", "spoon", "bowl", "banana", "apple",
              "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza",
              "donut", "cake", "chair", "couch", "potted plant", "bed",
              "dining table", "toilet", "tv", "laptop", "mouse", "remote",
              "keyboard", "cell phone", "microwave", "oven", "toaster", "sink",
              "refrigerator", "book", "clock", "vase", "scissors", "teddy bear",
              "hair drier", "toothbrush"]
    
    model_input_size = [224, 224]
    confidence_threshold = 0.3
    nms_threshold = 0.5
    max_boxes_num = 50
    colors = get_colors(len(labels))
    
    # 初始化AI2D（图像预处理）
    my_ai2d = Ai2d(debug_mode=0)
    my_ai2d.set_ai2d_dtype(input_format=nn.ai2d_format.NCHW_FMT,
                          output_format=nn.ai2d_format.NCHW_FMT,
                          input_type=np.uint8,
                          output_type=np.uint8)
    
    # 计算letterbox参数
    top, bottom, left, right, ratio = letterbox_pad_param([AI_WIDTH, AI_HEIGHT], 
                                                          model_input_size)
    my_ai2d.set_pad_param(True, [0, 0, 0, 0, top, bottom, left, right], 
                         0, [128, 128, 128])
    my_ai2d.set_resize_param(True, nn.interp_method.tf_bilinear,
                            nn.interp_mode.half_pixel)
    
    ai2d_builder = my_ai2d.build([1, 3, AI_HEIGHT, AI_WIDTH],
                                [1, 3, model_input_size[1], model_input_size[0]])
    
    # 初始化KPU（模型推理）
    my_kpu = nn.kpu()
    my_kpu.load_kmodel(kmodel_path)
    
    # 预分配输入内存
    input_init_data = np.ones((1, 3, model_input_size[1], model_input_size[0]),
                             dtype=np.uint8)
    kpu_input_tensor = nn.from_numpy(input_init_data)
    
    # 创建OSD图像（用于显示）
    osd_img = image.Image(DISPLAY_WIDTH, DISPLAY_HEIGHT, image.ARGB8888)
    
    print("[YOLO] 初始化完成")
    
    return {
        'model_input_size': model_input_size,
        'confidence_threshold': confidence_threshold,
        'nms_threshold': nms_threshold,
        'max_boxes_num': max_boxes_num,
        'labels': labels,
        'colors': colors,
        'ai2d_builder': ai2d_builder,
        'kpu_input_tensor': kpu_input_tensor,
        'kpu': my_kpu,
        'ratio': ratio,
        'osd_img': osd_img
    }

def deinit_yolov8(yolo_data):
    """释放YOLO资源"""
    if yolo_data is None:
        return
        
    print("[YOLO] 释放资源...")
    
    kpu = yolo_data.get('kpu')
    ai2d = yolo_data.get('ai2d_builder')
    osd_img = yolo_data.get('osd_img')
    
    if osd_img:
        del osd_img
    if kpu:
        del kpu
    if ai2d:
        del ai2d
        
    gc.collect()
    print("[YOLO] 资源释放完成")

# ==================== 线程1：TCP发送图像 ====================

# ==================== 线程1：4G串口发送图像（EC200M 专用） ====================

from usb import Serial  # 移远4G模块需要

def thread_sender():
    """
    4G 发送线程（消费者）
    从队列取图像，通过 EC200M 串口分包发送
    独立线程，不影响AI推理
    """
    print("[SEND] 4G发送线程启动")

    # ===================== 4G串口初始化 =====================
    try:
        serial = Serial("/dev/ttyUSB1", timeout_ms=500)
        serial.open()
        print("[SEND] EC200M 4G串口打开成功 ✅")
    except Exception as e:
        print("[SEND] 4G串口打开失败 ❌", e)
        return

    # 发送协议头（和你的接收端对应）
    HEAD = b"[IMG_START]"
    TAIL = b"[IMG_END]"
    BUFFER_SIZE = 4096  # 串口分包大小（EC200M 稳定值）

    # ======================================================
    # 主循环
    while True:
        # 系统未运行 → 休眠
        if not g_state.get_running():
            time.sleep_ms(100)
            continue

        # 从队列取图（生产者-消费者）
        item = g_queue.get()
        if item is None:
            time.sleep_ms(10)
            continue

        img, results = item
        quality = g_state.get_quality()

        # ===================== 压缩JPEG =====================
        try:
            jpeg_img = img.compress(quality=quality)
            jpeg_bytes = jpeg_img.to_bytes()
            size = len(jpeg_bytes)
        except:
            del img
            gc.collect()
            continue

        # ===================== 4G串口分包发送 =====================
        try:
            # 1. 发送开始标记
            serial.write(HEAD)
            time.sleep_ms(5)

            # 2. 分包发送（核心！串口不能一次发大数据）
            for i in range(0, size, BUFFER_SIZE):
                chunk = jpeg_bytes[i:i+BUFFER_SIZE]
                serial.write(chunk)
                time.sleep_ms(5)  # 防止模块发爆

            # 3. 发送结束标记
            serial.write(TAIL)
            time.sleep_ms(5)

            # 统计+日志
            g_state.add_send()
            print(f"[SEND] 4G发送成功 | 大小:{size} byte")

        except Exception as e:
            print("[SEND] 4G发送失败:", e)

        # ===================== 强制释放内存 =====================
        del img
        del jpeg_img
        gc.collect()

# ==================== 线程2：蓝牙命令监听 ====================

def thread_command():
    """
    命令线程（控制者）
    监听蓝牙串口，接收控制命令
    修改全局状态，控制AI启停
    """
    print("[CMD] 命令线程启动")
    
    # 初始化蓝牙
    uart = init_bluetooth()
    if uart is None:
        print("[CMD] 蓝牙初始化失败，命令线程退出")
        return
    
    # 发送欢迎信息
    send_bluetooth(uart, "================")
    send_bluetooth(uart, "水下检测系统")
    send_bluetooth(uart, "命令: run/stop/q50/q80")
    send_bluetooth(uart, "================")
    
    # 主循环
    while True:
        # 检查串口数据
        if uart.any():
            try:
                data = uart.readline()
                if data:
                    cmd = data.decode().strip()
                    print("[CMD] 收到:", cmd)
                    
                    # 解析命令
                    if cmd == "run":
                        g_state.set_running(True)
                        send_bluetooth(uart, "OK: 开始检测")
                        print("[CMD] 系统启动")
                        
                    elif cmd == "stop":
                        g_state.set_running(False)
                        send_bluetooth(uart, "OK: 停止检测")
                        print("[CMD] 系统停止")
                        
                    elif cmd == "q30":
                        g_state.set_quality(30)
                        send_bluetooth(uart, "OK: 质量30%")
                        
                    elif cmd == "q50":
                        g_state.set_quality(50)
                        send_bluetooth(uart, "OK: 质量50%")
                        
                    elif cmd == "q80":
                        g_state.set_quality(80)
                        send_bluetooth(uart, "OK: 质量80%")
                        
                    elif cmd == "status":
                        # 返回状态
                        st = "运行中" if g_state.get_running() else "停止"
                        msg = "状态:" + st + " 帧:" + str(g_state.frame_count)
                        send_bluetooth(uart, msg)
                        
                    else:
                        send_bluetooth(uart, "未知命令:" + cmd)
                        
            except Exception as e:
                print("[CMD] 处理错误:", e)
        
        # 休眠避免CPU占满
        time.sleep_ms(50)

# ==================== 主线程：AI推理 ====================

def main():
    """
    主线程（生产者）
    初始化硬件，启动子线程，运行AI推理主循环
    """
    print("=" * 50)
    print("水下检测系统 - 多线程版本")
    print("=" * 50)
    
    # 启动发送线程
    _thread.start_new_thread(thread_sender, ())
    time.sleep_ms(100)          # 给线程启动时间
    
    # 启动命令线程
    _thread.start_new_thread(thread_command, ())
    time.sleep_ms(100)
    
    # 初始化YOLO
    print("[MAIN] 初始化AI模型...")
    yolo_data = init_yolov8()
    if yolo_data is None:
        print("[MAIN] 初始化失败，退出")
        return -1
    
    # 提取常用变量（避免重复字典查找）
    osd_img = yolo_data['osd_img']
    ai2d_builder = yolo_data['ai2d_builder']
    kpu_input_tensor = yolo_data['kpu_input_tensor']
    kpu = yolo_data['kpu']
    ratio = yolo_data['ratio']
    labels = yolo_data['labels']
    colors = yolo_data['colors']
    conf_thresh = yolo_data['confidence_threshold']
    nms_thresh = yolo_data['nms_threshold']
    max_boxes = yolo_data['max_boxes_num']
    
    # FPS计时器
    fps = time.clock()
    
    print("[MAIN] 系统就绪，等待命令...")
    print("[MAIN] 请通过蓝牙发送 'run' 启动检测")
    
    # 主循环
    while True:
        # 检查运行状态
        if not g_state.get_running():
            # 停止状态，显示静止画面
            Display.show_image(osd_img)
            time.sleep_ms(100)
            continue
        
        # 开始一帧处理
        fps.tick()
        
        # 1. 从摄像头获取图像
        img = UVC.snapshot(timeout_ms=1000)
        if img is None:
            print("[MAIN] 取图失败")
            continue
        
        # 2. 预处理（letterbox + resize）
        img_np = img.to_numpy_ref()
        ai2d_input_tensor = nn.from_numpy(img_np)
        ai2d_builder.run(ai2d_input_tensor, kpu_input_tensor)
        
        # 3. KPU推理
        kpu.set_input_tensor(0, kpu_input_tensor)
        kpu.run()
        
        # 4. 获取输出
        results = []
        for i in range(kpu.outputs_size()):
            output_tensor = kpu.get_output_tensor(i)
            results.append(output_tensor.to_numpy())
            del output_tensor
        
        # 5. 后处理（解码检测框）
        output_data = results[0][0].transpose()
        boxes_ori = output_data[:, 0:4]
        class_ori = output_data[:, 4:]
        class_res = np.argmax(class_ori, axis=-1)
        scores_ = np.max(class_ori, axis=-1)
        
        # 筛选高置信度框
        boxes = []
        inds = []
        scores = []
        
        for i in range(len(boxes_ori)):
            if scores_[i] > conf_thresh:
                x, y, w, h = boxes_ori[i][0], boxes_ori[i][1], \
                           boxes_ori[i][2], boxes_ori[i][3]
                # 转换到原图坐标
                x1 = int((x - 0.5 * w) / ratio)
                y1 = int((y - 0.5 * h) / ratio)
                x2 = int((x + 0.5 * w) / ratio)
                y2 = int((y + 0.5 * h) / ratio)
                boxes.append([x1, y1, x2, y2])
                inds.append(class_res[i])
                scores.append(scores_[i])
        
        # 6. NMS去重
        det_res = []
        if len(boxes) > 0:
            boxes = np.array(boxes)
            scores = np.array(scores)
            inds = np.array(inds)
            
            keep = nms(boxes, scores, nms_thresh)
            
            # 组合结果 [x1,y1,x2,y2,score,class]
            dets = np.concatenate((boxes, 
                                  scores.reshape((len(boxes), 1)),
                                  inds.reshape((len(boxes), 1))), 
                                 axis=1)
            
            for k in keep:
                det_res.append(dets[k])
            
            det_res = np.array(det_res)
            if len(det_res) > max_boxes:
                det_res = det_res[:max_boxes, :]
        
        # 7. 绘制OSD
        osd_img.clear()
        
        for det in det_res:
            x1, y1, x2, y2 = int(round(det[0])), int(round(det[1])), \
                            int(round(det[2])), int(round(det[3]))
            score = det[4]
            cls = int(det[5])
            
            # 缩放到显示分辨率
            sx1 = int(x1 * DISPLAY_WIDTH // AI_WIDTH)
            sy1 = int(y1 * DISPLAY_HEIGHT // AI_HEIGHT)
            sw = int((x2 - x1) * DISPLAY_WIDTH // AI_WIDTH)
            sh = int((y2 - y1) * DISPLAY_HEIGHT // AI_HEIGHT)
            
            # 画框
            osd_img.draw_rectangle(sx1, sy1, sw, sh, 
                                color=colors[cls], thickness=4)
            
            # 画标签
            label_text = labels[cls] + " %.2f" % score
            label_y = sy1 - 50
            if label_y < 0:
                label_y = 0
            osd_img.draw_string_advanced(sx1, label_y, 24, 
                                        label_text, 
                                        color=colors[cls])
        
        # 8. 显示
        Display.show_image(osd_img)
        
        # 9. 扔进发送队列（复制图像，避免内存问题）
        # 注意：img是UVC的缓冲区，需要复制才能跨线程
        img_copy = img.copy()
        g_queue.put(img_copy, det_res)
        
        # 10. 更新统计
        g_state.add_frame()
        
        # 11. 打印FPS
        current_fps = fps.fps()
        print("[MAIN] FPS:%.1f 目标:%d 队列:%d" % 
              (current_fps, len(det_res), len(g_queue.queue)))
        
        # 12. 强制垃圾回收（K210内存紧张）
        gc.collect()

# ==================== 程序入口 ====================

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[SYSTEM] 用户中断")
    except Exception as e:
        print("[SYSTEM] 错误:", e)
        import sys
        sys.print_exception(e)
    finally:
        print("[SYSTEM] 程序结束")
        # 清理资源
        gc.collect()