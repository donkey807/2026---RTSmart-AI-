import utime
clock = utime.clock()
while True:
    clock.tick()
    # 你的代码逻辑放在这里
    utime.sleep(0.1)
    print("fps=",clock.fps())  
