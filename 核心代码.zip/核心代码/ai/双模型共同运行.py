from libs.PipeLine import PipeLine, ScopedTiming  # 导入管线类和性能计时器
from libs.AIBase import AIBase  # AI模型基类
from libs.AI2D import Ai2d  # AI图像预处理类
import nncase_runtime as nn  # NNCase运行时（神经网络推理引擎）
import ulab.numpy as np  # 类NumPy的科学计算库
import aidemo  # AI演示辅助库（后处理函数）
from media.display import *  # 显示模块
from media.media import *  # 媒体管理模块
from media.sensor import *  # 摄像头传感器模块
import utime, os, sys, gc  # 时间、系统、垃圾回收模块
import _thread  # 多线程支持

# ===================== 核心参数配置 =====================
# 显示尺寸（替换原800x480为960x540）
DISPLAY_WIDTH = 960   # LCD物理宽度（原生分辨率）
DISPLAY_HEIGHT = 540  # LCD物理高度（原生分辨率）

# 对齐函数（满足硬件对齐要求）
def align_to_8(x):
    """8字节对齐（用于高度）"""
    return (x // 8) * 8

def align_to_16(x):
    """16字节对齐（用于宽度）"""
    return (x // 16) * 16

# Sensor输出尺寸配置
SENSOR_WIDTH = DISPLAY_WIDTH   # 传感器宽度 = 显示宽度
SENSOR_HEIGHT = 536             # 传感器高度（略小于显示高度）
rgb888p_size = [320, 320]       # AI输入分辨率（RGB888格式）
display_size = [960, 540]       # 显示分辨率

# 全局变量（线程间共享）
sensor = None           # 摄像头传感器对象
face_det_stop = False   # 人脸检测线程停止标志
yolo_det_stop = False   # YOLO检测线程停止标志
face_osd_img = None     # 人脸检测OSD图像层
yolo_osd_img = None     # YOLO检测OSD图像层
lock = _thread.allocate_lock()  # 线程锁（保护共享资源）

# ===================== YOLOv8目标检测类 =====================
class ObjectDetectionApp(AIBase):
    """YOLOv8目标检测应用类（继承自AIBase）"""
    
    def __init__(self, kmodel_path, labels, model_input_size, max_boxes_num, 
                 confidence_threshold=0.5, nms_threshold=0.2, 
                 rgb888p_size=[224,224], display_size=[1920,1080], debug_mode=0):
        """
        初始化YOLO检测器
        Args:
            kmodel_path: kmodel模型文件路径
            labels: 类别标签列表
            model_input_size: 模型输入尺寸 [w, h]
            max_boxes_num: 最大检测框数量
            confidence_threshold: 置信度阈值
            nms_threshold: NMS阈值
            rgb888p_size: Sensor给AI的图像分辨率
            display_size: 显示分辨率
            debug_mode: 调试模式（0=关闭，>0=开启）
        """
        super().__init__(kmodel_path, model_input_size, rgb888p_size, debug_mode)
        self.kmodel_path = kmodel_path
        self.labels = labels
        self.model_input_size = model_input_size
        self.confidence_threshold = confidence_threshold
        self.nms_threshold = nms_threshold
        self.max_boxes_num = max_boxes_num
        
        # 分辨率对齐（满足硬件要求）
        self.rgb888p_size = [align_to_16(rgb888p_size[0]), rgb888p_size[1]]
        self.display_size = [align_to_16(display_size[0]), align_to_8(display_size[1])]
        self.debug_mode = debug_mode
        
        # 坐标缩放因子（模型坐标 -> Sensor坐标）
        self.x_factor = float(self.rgb888p_size[0]) / self.model_input_size[0]
        self.y_factor = float(self.rgb888p_size[1]) / self.model_input_size[1]
        
        # AI2D预处理对象（用于图像缩放、填充等）
        self.ai2d = Ai2d(debug_mode)
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT, nn.ai2d_format.NCHW_FMT, 
                                  np.uint8, np.uint8)

    def config_preprocess(self, input_image_size=None):
        """配置图像预处理流程（缩放+填充）"""
        with ScopedTiming("set preprocess config", self.debug_mode > 0):
            ai2d_input_size = input_image_size if input_image_size else self.rgb888p_size
            # 计算填充参数
            top, bottom, left, right = self.get_padding_param()
            # 添加填充（灰色背景）
            self.ai2d.pad([0,0,0,0,top,bottom,left,right], 0, [128,128,128])
            # 双线性插值缩放
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
            # 构建预处理流程
            self.ai2d.build([1,3,ai2d_input_size[1],ai2d_input_size[0]],
                           [1,3,self.model_input_size[1],self.model_input_size[0]])

    def get_padding_param(self):
        """计算填充参数（保持宽高比的Letterbox填充）"""
        dst_w = self.model_input_size[0]   # 目标宽度
        dst_h = self.model_input_size[1]   # 目标高度
        ratio_w = dst_w / self.rgb888p_size[0]  # 宽度缩放比
        ratio_h = dst_h / self.rgb888p_size[1]  # 高度缩放比
        ratio = min(ratio_w, ratio_h)      # 取较小比例（保持完整图像）
        
        new_w = int(ratio * self.rgb888p_size[0])  # 缩放后宽度
        new_h = int(ratio * self.rgb888p_size[1])  # 缩放后高度
        
        # 计算需要填充的像素数
        dw = (dst_w - new_w) / 2
        dh = (dst_h - new_h) / 2
        top = int(round(0))
        bottom = int(round(dh * 2 + 0.1))
        left = int(round(0))
        right = int(round(dw * 2 - 0.1))
        return top, bottom, left, right

    def postprocess(self, results):
        """后处理：解析模型输出，提取检测框"""
        with ScopedTiming("postprocess", self.debug_mode > 0):
            # 转置模型输出
            new_result = results[0][0].transpose()
            # 调用aidemo库的后处理函数
            det_res = aidemo.yolov8_det_postprocess(
                new_result.copy(),
                [self.rgb888p_size[1], self.rgb888p_size[0]],
                [self.model_input_size[1], self.model_input_size[0]],
                [self.display_size[1], self.display_size[0]],
                len(self.labels), self.confidence_threshold, 
                self.nms_threshold, self.max_boxes_num
            )
            return det_res

    def draw_result(self, osd_img, dets):
        """在OSD图层上绘制检测结果（边界框+标签）"""
        with ScopedTiming("display_draw", self.debug_mode > 0):
            osd_img.clear()  # 清除上一帧残留
            
            if dets:
                # 遍历所有检测到的目标
                for i in range(len(dets[0])):
                    # 获取原始坐标
                    x, y, w, h = map(lambda x: int(round(x, 0)), dets[0][i])
                    
                    # 坐标缩放（模型坐标 -> 显示坐标）
                    x = x * self.display_size[0] // self.rgb888p_size[0]
                    y = y * self.display_size[1] // self.rgb888p_size[1]
                    w = w * self.display_size[0] // self.rgb888p_size[0]
                    h = h * self.display_size[1] // self.rgb888p_size[1]
                    
                    # 绘制黄色边界框
                    osd_img.draw_rectangle(x, y, w, h, color=(255, 255, 0, 255), thickness=2)
                    
                    # 绘制标签和置信度
                    label_text = f"{self.labels[dets[1][i]]} {round(dets[2][i], 2)}"
                    osd_img.draw_string_advanced(x, y-50, 32, label_text, color=(255, 255, 0, 255))

# ===================== 人脸检测类 =====================
class FaceDetectionApp(AIBase):
    """人脸检测应用类"""
    
    def __init__(self, kmodel_path, anchors, model_input_size=[640,640], 
                 confidence_threshold=0.5, nms_threshold=0.2, 
                 rgb888p_size=[224,224], display_size=[1920,1080], debug_mode=0):
        """
        初始化人脸检测器
        Args:
            kmodel_path: 模型文件路径
            anchors: 锚点数据（用于目标检测）
            model_input_size: 模型输入尺寸
            confidence_threshold: 置信度阈值
            nms_threshold: NMS阈值
            rgb888p_size: Sensor输入分辨率
            display_size: 显示分辨率
            debug_mode: 调试模式
        """
        super().__init__(kmodel_path, model_input_size, rgb888p_size, debug_mode)
        self.kmodel_path = kmodel_path
        self.model_input_size = model_input_size
        self.confidence_threshold = confidence_threshold
        self.nms_threshold = nms_threshold
        self.anchors = anchors
        
        # 分辨率对齐
        self.rgb888p_size = [align_to_16(rgb888p_size[0]), rgb888p_size[1]]
        self.display_size = [align_to_16(display_size[0]), display_size[1]]
        self.debug_mode = debug_mode
        
        # AI2D预处理对象
        self.ai2d = Ai2d(debug_mode)
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT, nn.ai2d_format.NCHW_FMT, 
                                  np.uint8, np.uint8)

    def config_preprocess(self, input_image_size=None):
        """配置预处理（人脸检测使用特定的填充颜色）"""
        with ScopedTiming("set preprocess config", self.debug_mode > 0):
            ai2d_input_size = input_image_size if input_image_size else self.rgb888p_size
            top, bottom, left, right = self.get_padding_param()
            # 人脸检测使用RGB(104,117,123)填充（常见的人脸检测预处理）
            self.ai2d.pad([0, 0, 0, 0, top, bottom, left, right], 0, [104, 117, 123])
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
            self.ai2d.build([1,3,ai2d_input_size[1],ai2d_input_size[0]],
                           [1,3,self.model_input_size[1],self.model_input_size[0]])

    def postprocess(self, results):
        """后处理：解析人脸检测结果"""
        with ScopedTiming("postprocess", self.debug_mode > 0):
            # 调用aidemo的人脸检测后处理
            post_ret = aidemo.face_det_post_process(
                self.confidence_threshold, self.nms_threshold, 
                self.model_input_size[1], self.anchors, 
                self.rgb888p_size, results
            )
            return post_ret[0] if len(post_ret) > 0 else post_ret

    def draw_result(self, osd_img, dets):
        """绘制人脸检测框"""
        with ScopedTiming("display_draw", self.debug_mode > 0):
            osd_img.clear()
            if dets:
                for det in dets:
                    x, y, w, h = map(lambda x: int(round(x, 0)), det[:4])
                    # 坐标缩放到显示分辨率
                    x = x * self.display_size[0] // self.rgb888p_size[0]
                    y = y * self.display_size[1] // self.rgb888p_size[1]
                    w = w * self.display_size[0] // self.rgb888p_size[0]
                    h = h * self.display_size[1] // self.rgb888p_size[1]
                    # 绘制黄色矩形框
                    osd_img.draw_rectangle(x, y, w, h, color=(255, 255, 0, 255), thickness=2)

    def get_padding_param(self):
        """计算填充参数（同YOLO）"""
        dst_w = self.model_input_size[0]
        dst_h = self.model_input_size[1]
        ratio_w = dst_w / self.rgb888p_size[0]
        ratio_h = dst_h / self.rgb888p_size[1]
        ratio = min(ratio_w, ratio_h)
        new_w = int(ratio * self.rgb888p_size[0])
        new_h = int(ratio * self.rgb888p_size[1])
        dw = (dst_w - new_w) / 2
        dh = (dst_h - new_h) / 2
        top = int(round(0))
        bottom = int(round(dh * 2 + 0.1))
        left = int(round(0))
        right = int(round(dw * 2 - 0.1))
        return top, bottom, left, right

# ===================== 人脸检测线程 =====================
def face_det_thread():
    """人脸检测线程函数（独立运行）"""
    global sensor, rgb888p_size, display_size, face_osd_img
    
    # 模型配置
    kmodel_path = "/sdcard/examples/kmodel/face_detection_320.kmodel"
    confidence_threshold = 0.5
    nms_threshold = 0.2
    anchor_len = 4200
    det_dim = 4
    anchors_path = "/sdcard/examples/utils/prior_data_320.bin"
    anchors = np.fromfile(anchors_path, dtype=np.float)
    anchors = anchors.reshape((anchor_len, det_dim))
    
    # 创建人脸检测器实例
    face_det = FaceDetectionApp(kmodel_path, anchors, 
                                model_input_size=[320, 320],
                                confidence_threshold=confidence_threshold, 
                                nms_threshold=nms_threshold,
                                rgb888p_size=rgb888p_size, 
                                display_size=display_size, 
                                debug_mode=0)
    face_det.config_preprocess()
    
    # FPS计算器
    fps = utime.clock()
    fps.tick()
    frame_count = 0
    
    while True:
        if face_det_stop:
            break
            
        # 从Sensor通道2获取RGB图像
        img_2 = sensor.snapshot(chn=CAM_CHN_ID_2)
        img_np = img_2.to_numpy_ref()
        
        # 加锁执行推理（保护共享资源）
        with lock:
            res = face_det.run(img_np)
        
        # 绘制并显示结果（OSD图层2）
        face_det.draw_result(face_osd_img, res)
        Display.show_image(face_osd_img, 0, 0, Display.LAYER_OSD2)
        
        # 定期打印检测统计
        frame_count += 1
        fps.tick()
        if frame_count % 10 == 0:
            face_count = len(res) if res else 0
            print(f"[人脸检测] 检测到 {face_count} 个人脸, FPS: {fps.fps():.2f}")
        
        gc.collect()  # 垃圾回收
    
    face_det.deinit()  # 释放资源

# ===================== YOLOv8检测线程 =====================
def yolov8_det_thread():
    """YOLOv8目标检测线程函数"""
    global sensor, rgb888p_size, display_size, yolo_osd_img
    
    # YOLO模型配置
    kmodel_path = "/sdcard/examples/kmodel/yolov8n_224.kmodel"
    labels = ["person", "bicycle", "car", "motorcycle", "airplane", "bus", 
              "train", "truck", "boat", "traffic light", "fire hydrant", 
              "stop sign", "parking meter", "bench", "bird", "cat", "dog", 
              "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe"]
    confidence_threshold = 0.3
    nms_threshold = 0.4
    
    # 创建YOLO检测器实例
    ob_det = ObjectDetectionApp(kmodel_path, labels=labels, 
                                model_input_size=[224,224], 
                                max_boxes_num=50,
                                confidence_threshold=confidence_threshold, 
                                nms_threshold=nms_threshold,
                                rgb888p_size=rgb888p_size, 
                                display_size=display_size, 
                                debug_mode=0)
    ob_det.config_preprocess()
    
    # FPS计算器
    fps = utime.clock()
    fps.tick()
    frame_count = 0
    
    while True:
        if yolo_det_stop:
            break
            
        # 获取图像并推理
        img_2 = sensor.snapshot(chn=CAM_CHN_ID_2)
        img_np = img_2.to_numpy_ref()
        
        with lock:
            det_res = ob_det.run(img_np)
        
        # 绘制结果（OSD图层1）
        ob_det.draw_result(yolo_osd_img, det_res)
        Display.show_image(yolo_osd_img, 0, 0, Display.LAYER_OSD1)
        
        # 打印检测统计
        frame_count += 1
        fps.tick()
        if frame_count % 10 == 0:
            det_count = len(det_res[0]) if det_res else 0
            print(f"[YOLOv8检测] 检测到 {det_count} 个物体, FPS: {fps.fps():.2f}")
        
        gc.collect()
    
    ob_det.deinit()

# ===================== 媒体初始化函数 =====================
def media_init():
    """初始化摄像头、显示等媒体设备"""
    global sensor, face_osd_img, yolo_osd_img
    
    # 初始化显示（NT35516驱动，960x540分辨率，3个OSD图层）
    Display.init(Display.NT35516, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, 
                 to_ide=True, osd_num=3)
    
    # 初始化摄像头
    sensor = Sensor(fps=30)
    sensor.reset()
    
    # 配置通道0（YUV420，用于视频显示）
    sensor.set_framesize(w=DISPLAY_WIDTH, h=SENSOR_HEIGHT, chn=CAM_CHN_ID_0)
    sensor.set_pixformat(Sensor.YUV420SP)
    
    # 配置通道2（RGB888，用于AI推理）
    sensor.set_framesize(w=rgb888p_size[0], h=rgb888p_size[1], chn=CAM_CHN_ID_2)
    sensor.set_pixformat(Sensor.RGBP888, chn=CAM_CHN_ID_2)
    
    # 绑定视频层到显示
    sensor_bind_info = sensor.bind_info(x=0, y=0, chn=CAM_CHN_ID_0)
    Display.bind_layer(**sensor_bind_info, layer=Display.LAYER_VIDEO1)
    
    # 创建OSD图像层（用于绘制检测框）
    face_osd_img = image.Image(display_size[0], align_to_8(display_size[1]), image.ARGB8888)
    yolo_osd_img = image.Image(display_size[0], align_to_8(display_size[1]), image.ARGB8888)
    
    # 启动媒体管理和摄像头
    MediaManager.init()
    sensor.run()

def media_deinit():
    """反初始化媒体设备，释放资源"""
    global sensor
    os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
    sensor.stop()
    Display.deinit()
    utime.sleep_ms(50)
    MediaManager.deinit()

# ===================== 主程序入口 =====================
if __name__ == "__main__":
    # 初始化硬件
    media_init()
    
    # 启动两个检测线程（YOLO和人脸检测同时运行）
    _thread.start_new_thread(yolov8_det_thread, ())
    _thread.start_new_thread(face_det_thread, ())
    
    # 主循环：保持线程运行，直到收到退出信号（如Ctrl+C）
    try:
        while True:
            utime.sleep_ms(50)  # 让出CPU给子线程
    except BaseException as e:
        print(f"程序异常退出: {e}")
        sys.print_exception(e)
        # 设置停止标志，通知子线程退出
        yolo_det_stop = True
        face_det_stop = True
    
    # 清理资源
    media_deinit()
    gc.collect()