import network, socket, time, gc, os
from media.sensor import *
from media.media import *
from media.display import *

DISPLAY_WIDTH  = 960
DISPLAY_HEIGHT = 540
SERVER_HOST    = "8.156.80.207"
SERVER_PORT    = 8080  # 裸TCP端口，和Flask 8080分开
JPEG_QUALITY   = 30

def align_to_8(x):
    return (x // 8) * 8

os.exitpoint(os.EXITPOINT_ENABLE)

nic = network.LAN()
print(f"EC200 IP: {nic.ifconfig()[0]}")

sensor = Sensor()
sensor.reset()
sensor.set_framesize(width=DISPLAY_WIDTH, height=align_to_8(DISPLAY_HEIGHT))
sensor.set_pixformat(Sensor.RGB565)

Display.init(Display.NT35516, DISPLAY_WIDTH, DISPLAY_HEIGHT)
MediaManager.init()
sensor.run()

# ========================
# 裸TCP长连接发送
# 帧格式：4字节长度头 + JPEG数据
# ========================
sock = None

def connect():
    global sock
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
        s.settimeout(5)
        s.connect((SERVER_HOST, SERVER_PORT))
        sock = s
        print("TCP连接成功")
    except Exception as e:
        print("TCP连接失败:", e)
        sock = None

def send_frame(jpeg_bytes):
    global sock
    if sock is None:
        connect()
    if sock is None:
        return
    try:
        size = len(jpeg_bytes)
        # 4字节大端长度头
        header = bytes([(size>>24)&0xFF, (size>>16)&0xFF, (size>>8)&0xFF, size&0xFF])
        sock.send(header + jpeg_bytes)
    except Exception as e:
        print("发送失败:", e)
        try: sock.close()
        except: pass
        sock = None

connect()
clock = time.clock()
try:
    while True:
        os.exitpoint()
        clock.tick()
        img = sensor.snapshot()
        Display.show_image(img)

        #img.save("/tmp/f.jpg")
        #with open("/tmp/f.jpg", "rb") as f:
        #    jpeg = f.read()
        #send_frame(jpeg)
        #del jpeg

        #改为压缩图片直接内存压缩，避免文件IO延迟
        small = img.scale(x_scale=0.5, y_scale=0.5)  # 480x270 降低传输大小
        jpeg = small.compressed(JPEG_QUALITY)
        if jpeg:
            send_frame(jpeg)
            del jpeg, small

        print(f"fps: {clock.fps():.2f}")
        gc.collect()

finally:
    if sock:
        sock.close()
    sensor.stop()
    Display.deinit()
    time.sleep_ms(100)
    MediaManager.deinit()
    print("资源已释放")
