# 导入显示相关核心模块，提供显示屏初始化、图像显示等底层功能
from media.display import *
# 导入媒体管理相关模块，负责媒体缓冲区分配、释放等资源管理
from media.media import *
# 导入系统基础模块：时间控制、操作系统接口、系统参数、垃圾回收
import time, os, sys, gc
# 导入LVGL图形库，用于构建嵌入式GUI界面（核心GUI库）
import lvgl as lv
# 导入触摸设备驱动模块，用于触摸屏幕的读取和控制
from machine import TOUCH

def align_to_8(value):
    """
    数值对齐到8的倍数（内存对齐/显示缓冲区优化辅助函数）
    嵌入式显示硬件通常要求缓冲区大小为8的整数倍，提升数据传输效率
    :param value: 原始数值（此处为显示屏高度）
    :return: 向下取整后的8的倍数数值
    """
    return (value // 8) * 8

# 定义显示屏分辨率常量 - 宽度960像素
DISPLAY_WIDTH = 960
# 定义显示屏分辨率常量 - 高度540像素（先对齐到8的倍数，保证显示缓冲区兼容性）
DISPLAY_HEIGHT = align_to_8(540)

def display_init():
    """
    底层显示系统初始化函数
    完成显示屏硬件初始化和媒体管理器初始化，为LVGL提供显示硬件支撑
    """
    # 初始化显示屏：使用NT35516驱动芯片，分辨率960x540，开启IDE调试输出
    Display.init(Display.NT35516, width = 960, height = 540, to_ide = True)
    # 初始化媒体管理器：分配媒体缓冲区、初始化媒体硬件资源
    MediaManager.init()

def display_deinit():
    """
    底层显示系统反初始化函数
    优雅释放显示相关硬件资源和内存，避免资源泄漏
    """
    # 启用系统退出点，允许系统进入睡眠模式（嵌入式系统低功耗处理）
    os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
    # 延时50毫秒，确保硬件状态稳定后再释放资源
    time.sleep_ms(50)
    # 反初始化显示屏：关闭显示输出，释放显示屏硬件资源
    Display.deinit()
    # 反初始化媒体管理器：释放媒体缓冲区，回收媒体相关系统资源
    MediaManager.deinit()

def disp_drv_flush_cb(disp_drv, area, color):
    """
    LVGL显示驱动刷新回调函数（核心回调）
    LVGL渲染完成后，通过此函数将渲染结果输出到物理显示屏
    :param disp_drv: LVGL显示驱动对象
    :param area: 待刷新的显示区域（本次渲染的矩形区域）
    :param color: 渲染后的颜色数据缓冲区地址
    """
    # 声明全局变量：两个双缓冲图像对象，用于LVGL双缓冲渲染
    global disp_img1, disp_img2

    # 判断是否为本次刷新的最后一步（LVGL渲染完成标志）
    if disp_drv.flush_is_last() == True:
        # 对比缓冲区地址，判断本次渲染使用的是哪个缓冲
        if disp_img1.virtaddr() == uctypes.addressof(color.__dereference__()):
            # 显示第一个缓冲的图像数据到物理屏幕
            Display.show_image(disp_img1)
            # 打印调试信息，标记当前使用的缓冲
            print(f"disp disp_img1 {disp_img1}")
        else:
            # 显示第二个缓冲的图像数据到物理屏幕
            Display.show_image(disp_img2)
            # 打印调试信息，标记当前使用的缓冲
            print(f"disp disp_img2 {disp_img2}")
        # 短暂延时10毫秒，确保图像稳定显示（避免刷新过快导致的闪屏）
        time.sleep(0.01)

    # 通知LVGL：本次刷新完成，可以进行下一次渲染（必须调用，否则LVGL会阻塞）
    disp_drv.flush_ready()

class touch_screen():
    """
    触摸屏幕驱动封装类
    实现LVGL触摸输入设备的适配，将硬件触摸数据转换为LVGL可识别的输入事件
    """
    def __init__(self):
        """
        类初始化方法：创建LVGL输入设备驱动并初始化硬件触摸对象
        """
        # 初始化触摸状态为"释放"（默认无触摸）
        self.state = lv.INDEV_STATE.RELEASED

        # 创建LVGL输入设备驱动对象
        self.indev_drv = lv.indev_create()
        # 设置输入设备类型为"指针设备"（触摸屏属于指针输入设备）
        self.indev_drv.set_type(lv.INDEV_TYPE.POINTER)
        # 设置触摸数据读取回调函数，LVGL会周期性调用此函数获取触摸状态
        self.indev_drv.set_read_cb(self.callback)
        # 初始化硬件触摸对象：使用第0个触摸设备（硬件编号）
        self.touch = TOUCH(0)

    def callback(self, driver, data):
        """
        触摸数据读取回调函数（LVGL输入设备回调）
        读取硬件触摸数据，并转换为LVGL输入设备数据格式
        :param driver: LVGL输入设备驱动对象
        :param data: LVGL输入设备数据对象（用于存储触摸坐标和状态）
        """
        # 初始化触摸坐标和状态（默认无触摸）
        x, y, state = 0, 0, lv.INDEV_STATE.RELEASED
        # 读取触摸数据：最多读取1个触摸点（单点触摸）
        tp = self.touch.read(1)
        # 判断是否读取到有效触摸数据
        if len(tp):
            # 提取触摸坐标（x:横坐标，y:纵坐标）和触摸事件
            x, y, event = tp[0].x, tp[0].y, tp[0].event
            # 判断触摸事件类型：2（按下）、3（按住）均视为有效触摸
            if event == 2 or event == 3:
                # 设置触摸状态为"按下"
                state = lv.INDEV_STATE.PRESSED
        # 将触摸坐标赋值给LVGL输入数据对象
        data.point = lv.point_t({'x': x, 'y': y})
        # 将触摸状态赋值给LVGL输入数据对象
        data.state = state

def lvgl_init():
    """
    LVGL图形库初始化函数
    完成LVGL核心初始化、显示缓冲配置、触摸设备初始化，为GUI界面提供运行环境
    """
    # 声明全局变量：两个显示缓冲图像对象，用于LVGL双缓冲渲染
    global disp_img1, disp_img2

    # 初始化LVGL核心库（必须先调用，初始化LVGL内部资源）
    lv.init()
    # 创建LVGL显示驱动对象：指定显示屏分辨率（960x540）
    disp_drv = lv.disp_create(DISPLAY_WIDTH, DISPLAY_HEIGHT)
    # 设置LVGL显示刷新回调函数：关联到自定义的disp_drv_flush_cb
    disp_drv.set_flush_cb(disp_drv_flush_cb)
    # 创建第一个显示缓冲：分辨率960x540，像素格式BGRA8888（32位色深）
    disp_img1 = image.Image(DISPLAY_WIDTH, DISPLAY_HEIGHT, image.BGRA8888)
    # 创建第二个显示缓冲：与第一个缓冲参数一致，用于双缓冲交替渲染
    disp_img2 = image.Image(DISPLAY_WIDTH, DISPLAY_HEIGHT, image.BGRA8888)
    # 配置LVGL显示缓冲：使用双缓冲模式，指定缓冲数据、大小和渲染模式
    # lv.DISP_RENDER_MODE.DIRECT：直接渲染模式，提升渲染效率
    disp_drv.set_draw_buffers(disp_img1.bytearray(), disp_img2.bytearray(), disp_img1.size(), lv.DISP_RENDER_MODE.DIRECT)
    # 初始化触摸屏幕对象：创建触摸输入设备，完成LVGL输入适配
    tp = touch_screen()

def lvgl_deinit():
    """
    LVGL图形库反初始化函数
    优雅释放LVGL相关资源，避免内存泄漏
    """
    # 声明全局变量：两个显示缓冲图像对象
    global disp_img1, disp_img2

    # 反初始化LVGL核心库，释放LVGL内部资源
    lv.deinit()
    # 删除第一个显示缓冲对象，回收内存
    del disp_img1
    # 删除第二个显示缓冲对象，回收内存
    del disp_img2

def btn_clicked_event(event):
    """
    按钮点击事件回调函数
    处理按钮点击事件，实现标签文本在"on"和"off"之间切换
    :param event: LVGL事件对象，包含事件类型、目标对象等信息
    """
    # 获取事件目标对象，并强制转换为LVGL按钮对象
    btn = lv.btn.__cast__(event.get_target())
    # 获取按钮的用户数据，并强制转换为LVGL标签对象（存储按钮关联的标签）
    label = lv.label.__cast__(btn.get_user_data())
    # 判断标签当前文本内容
    if "on" == label.get_text():
        # 若当前为"on"，切换为"off"
        label.set_text("off")
    else:
        # 若当前为"off"，切换为"on"
        label.set_text("on")

def user_gui_init():
    """
    用户GUI界面初始化函数
    构建完整的用户界面：包含文本标签、动画图片、可点击按钮，实现多元素布局
    """
    # 定义资源文件根路径：存储字体、图片等GUI资源（SD卡路径）
    res_path = "/sdcard/examples/15-LVGL/data/"

    # 加载英文字体：Montserrat-16号字体（从SD卡资源路径加载）
    # "A:" 为SD卡设备别名，对应底层存储设备映射
    font_montserrat_16 = lv.font_load("A:" + res_path + "font/montserrat-16.fnt")
    # 创建英文文本标签：父对象为屏幕活动对象（默认全屏窗口）
    ltr_label = lv.label(lv.scr_act())
    # 设置英文标签显示文本内容
    ltr_label.set_text("In modern terminology, a microcontroller is similar to a system on a chip (SoC).")
    # 设置标签文本字体为加载的Montserrat-16号字体
    ltr_label.set_style_text_font(font_montserrat_16,0)
    # 设置标签宽度为310像素（超出宽度自动换行）
    ltr_label.set_width(310)
    # 对齐方式：屏幕顶部中间，偏移量(0,0)
    ltr_label.align(lv.ALIGN.TOP_MID, 0, 0)

    # 加载中文字体：宋体16号CJK字体（支持中文显示的LVGL专用字体）
    font_simsun_16_cjk = lv.font_load("A:" + res_path + "font/lv_font_simsun_16_cjk.fnt")
    # 创建中文文本标签：父对象为屏幕活动对象
    cz_label = lv.label(lv.scr_act())
    # 设置中文标签文本字体为加载的宋体16号字体
    cz_label.set_style_text_font(font_simsun_16_cjk, 0)
    # 设置中文标签显示文本内容（支持换行符\n）
    cz_label.set_text("嵌入式系统（Embedded System），\n是一种嵌入机械或电气系统内部、具有专一功能和实时计算性能的计算机系统。")
    # 设置标签宽度为310像素（超出宽度自动换行）
    cz_label.set_width(310)
    # 对齐方式：屏幕底部中间，偏移量(0,0)
    cz_label.align(lv.ALIGN.BOTTOM_MID, 0, 0)

    # 初始化动画图片数组：长度为4，存储动画帧数据
    anim_imgs = [None]*4
    # 读取第一张动画图片文件（animimg001.png），以二进制模式打开
    with open(res_path + 'img/1.png','rb') as f:
        anim001_data = f.read()

    # 构建LVGL图片描述符对象（存储第一张动画图片数据）
    anim_imgs[0] = lv.img_dsc_t({
    'data_size': len(anim001_data),  # 图片数据大小（字节数）
    'data': anim001_data             # 图片二进制数据
    })
    # 最后一帧与第一帧相同（形成循环动画的平滑过渡）
    anim_imgs[-1] = anim_imgs[0]

    # 读取第二张动画图片文件（animimg002.png），以二进制模式打开
    with open(res_path + 'img/2.png','rb') as f:
        anim002_data = f.read()

    # 构建LVGL图片描述符对象（存储第二张动画图片数据）
    anim_imgs[1] = lv.img_dsc_t({
    'data_size': len(anim002_data),
    'data': anim002_data
    })

    # 读取第三张动画图片文件（animimg003.png），以二进制模式打开
    with open(res_path + 'img/3.png','rb') as f:
        anim003_data = f.read()

    # 构建LVGL图片描述符对象（存储第三张动画图片数据）
    anim_imgs[2] = lv.img_dsc_t({
    'data_size': len(anim003_data),
    'data': anim003_data
    })

    with open(res_path + 'img/4.png','rb') as f:
        anim004_data = f.read()

    # 构建LVGL图片描述符对象（存储第三张动画图片数据）
    anim_imgs[2] = lv.img_dsc_t({
    'data_size': len(anim004_data),
    'data': anim004_data
    })
    with open(res_path + 'img/5.png','rb') as f:
        anim005_data = f.read()

    # 构建LVGL图片描述符对象（存储第三张动画图片数据）
    anim_imgs[2] = lv.img_dsc_t({
    'data_size': len(anim005_data),
    'data': anim005_data
    })
    with open(res_path + 'img/6.png','rb') as f:
        anim006_data = f.read()

    # 构建LVGL图片描述符对象（存储第三张动画图片数据）
    anim_imgs[2] = lv.img_dsc_t({
    'data_size': len(anim006_data),
    'data': anim006_data
    })
    with open(res_path + 'img/7.png','rb') as f:
        anim007_data = f.read()

    # 构建LVGL图片描述符对象（存储第三张动画图片数据）
    anim_imgs[2] = lv.img_dsc_t({
    'data_size': len(anim007_data),
    'data': anim007_data
    })
    with open(res_path + 'img/8.png','rb') as f:
        anim008_data = f.read()

    # 构建LVGL图片描述符对象（存储第三张动画图片数据）
    anim_imgs[2] = lv.img_dsc_t({
    'data_size': len(anim008_data),
    'data': anim008_data
    })
    with open(res_path + 'img/9.png','rb') as f:
        anim009_data = f.read()

    # 构建LVGL图片描述符对象（存储第三张动画图片数据）
    anim_imgs[2] = lv.img_dsc_t({
    'data_size': len(anim009_data),
    'data': anim009_data
    })

    # 创建动画图片控件：父对象为屏幕活动对象
    animimg0 = lv.animimg(lv.scr_act())
    # 动画图片居中显示（屏幕水平+垂直居中）
    animimg0.center()
    # 设置动画图片数据源：传入动画帧数组，指定帧数量为4
    animimg0.set_src(anim_imgs, 4)
    # 设置动画总时长：2000毫秒（2秒播放完所有帧）
    animimg0.set_duration(2000)
    # 设置动画重复次数：无限循环（LVGL内置常量）
    animimg0.set_repeat_count(lv.ANIM_REPEAT_INFINITE)
    # 启动动画播放
    animimg0.start()

    # 创建按钮控件：父对象为屏幕活动对象
    btn = lv.btn(lv.scr_act())
    # 按钮对齐方式：屏幕中心，垂直方向偏移25%屏幕高度（向下偏移）
    btn.align(lv.ALIGN.CENTER, 0, lv.pct(25))
    # 在按钮上创建标签控件（按钮文本）
    label = lv.label(btn)
    # 设置按钮标签默认文本为"on"
    label.set_text('on')
    # 将标签对象设置为按钮的用户数据（便于事件回调中获取标签）
    btn.set_user_data(label)
    # 为按钮添加点击事件回调：关联到btn_clicked_event函数
    btn.add_event(btn_clicked_event, lv.EVENT.CLICKED, None)

def main():
    """
    程序主函数
    负责串联整个系统的初始化、主循环运行和资源释放，是程序入口核心
    """
    # 启用系统退出点：允许嵌入式系统正常退出和资源回收
    os.exitpoint(os.EXITPOINT_ENABLE)
    try:
        # 第一步：初始化底层显示系统（硬件级）
        display_init()
        # 第二步：初始化LVGL图形库（GUI框架级）
        lvgl_init()
        # 第三步：初始化用户GUI界面（业务界面级）
        user_gui_init()
        # 程序主循环：持续运行，维持GUI界面响应
        while True:
            # 运行LVGL任务处理器：处理GUI事件、渲染、动画等
            # 传入延时参数，让LVGL自动管理循环频率，降低CPU占用
            time.sleep_ms(lv.task_handler())
    # 捕获所有基础异常（避免程序异常崩溃，便于调试）
    except BaseException as e:
        # 导入系统模块，打印异常详细信息（堆栈跟踪）
        import sys
        sys.print_exception(e)
    # 无论是否发生异常，最终都执行资源释放流程
    finally:
        # 第一步：反初始化LVGL图形库，释放GUI资源
        lvgl_deinit()
        # 第二步：反初始化底层显示系统，释放硬件资源
        display_deinit()
        # 第三步：手动触发垃圾回收，回收未释放的内存
        gc.collect()

# 程序入口：当脚本直接运行时，执行main函数
if __name__ == "__main__":
    main()