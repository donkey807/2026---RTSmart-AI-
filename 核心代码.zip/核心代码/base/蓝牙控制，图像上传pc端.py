#蓝牙控制开发板启动，同时传递图像至pc端
import os, sys
from media.sensor import *
from media.display import *
from media.media import *
from machine import UART, FPIOA
import nncase_runtime as nn
import ulab.numpy as np
import time, image, random, gc
from libs.Utils import *
from media.uvc import *

# 硬件配置
DISPLAY_WIDTH = 960
DISPLAY_HEIGHT = 540
AI_RGB888P_WIDTH = 320
AI_RGB888P_HEIGHT = 320
_display_initialized = 0

def init_bluetooth():
    print("正在初始化蓝牙模块...")
    fpioa = FPIOA()
    fpioa.set_function(11, FPIOA.UART2_TXD)
    fpioa.set_function(12, FPIOA.UART2_RXD)

    u2 = UART(UART.UART2, baudrate=9600, bits=UART.EIGHTBITS, parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)
    ret = u2.init(baudrate=9600, bits=UART.EIGHTBITS, parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)
    
    if ret != 0:
        print("[蓝牙] 初始化失败")
        return None
    
    print("[蓝牙] 初始化成功")
    return u2

def send_bluetooth(u2, msg):
    if u2 == None:
        return -1
    u2.write(msg + "\r\n")
    print("[蓝牙发送] " + msg)
    return 0

def receive_bluetooth(u2, timeout_ms):
    if u2 == None:
        return None
    if u2.any():
        data = u2.readline()
        if data:
            msg = data.decode().strip()
            print("[蓝牙接收] " + msg)
            return msg
    return None

def letterbox_pad_param(input_size, output_size):
    ratio_w = output_size[0] / input_size[0]
    ratio_h = output_size[1] / input_size[1]
    ratio = ratio_w if ratio_w < ratio_h else ratio_h
    new_w = int(ratio * input_size[0])
    new_h = int(ratio * input_size[1])
    dw = (output_size[0] - new_w) / 2
    dh = (output_size[1] - new_h) / 2
    top = int(round(0))
    bottom = int(round(dh * 2 + 0.1))
    left = int(round(0))
    right = int(round(dw * 2 - 0.1))
    return top, bottom, left, right, ratio

def nms(boxes, scores, thresh):
    x1 = boxes[:, 0]
    y1 = boxes[:, 1]
    x2 = boxes[:, 2]
    y2 = boxes[:, 3]
    areas = (x2 - x1 + 1) * (y2 - y1 + 1)
    order = np.argsort(scores, axis=0)[::-1]
    keep = []
    
    while order.size > 0:
        i = order[0]
        keep.append(i)
        
        # 计算IoU
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])
        
        w = np.maximum(0.0, xx2 - xx1 + 1)
        h = np.maximum(0.0, yy2 - yy1 + 1)
        inter = w * h
        
        ovr = inter / (areas[i] + areas[order[1:]] - inter)
        
        # 保留IoU小于阈值的框
        inds = np.where(ovr <= thresh)[0]
        order = order[inds + 1]
        
    return keep

def init_yolov8():
    global _display_initialized
    
    if _display_initialized:
        Display.unbind_layer(layer=Display.LAYER_VIDEO1)
    
    init_camera()
    
    print("正在初始化YOLOv8模型...")
    kmodel_path = "/sdcard/examples/kmodel/yolov8n_224.kmodel"
    
    labels = ["person", "bicycle", "car", "motorcycle", "airplane", "bus", "train",
              "truck", "boat", "traffic light", "fire hydrant", "stop sign",
              "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep",
              "cow", "elephant", "bear", "zebra", "giraffe", "backpack",
              "umbrella", "handbag", "tie", "suitcase", "frisbee", "skis",
              "snowboard", "sports ball", "kite", "baseball bat", "baseball glove",
              "skateboard", "surfboard", "tennis racket", "bottle", "wine glass",
              "cup", "fork", "knife", "spoon", "bowl", "banana", "apple",
              "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza",
              "donut", "cake", "chair", "couch", "potted plant", "bed",
              "dining table", "toilet", "tv", "laptop", "mouse", "remote",
              "keyboard", "cell phone", "microwave", "oven", "toaster", "sink",
              "refrigerator", "book", "clock", "vase", "scissors", "teddy bear",
              "hair drier", "toothbrush"]
    
    model_input_size = [224, 224]
    confidence_threshold = 0.3
    nms_threshold = 0.5
    max_boxes_num = 50
    colors = get_colors(len(labels))
    
    # ai2d初始化
    my_ai2d = Ai2d(debug_mode=0)
    my_ai2d.set_ai2d_dtype(input_format=nn.ai2d_format.NCHW_FMT, output_format=nn.ai2d_format.NCHW_FMT, input_type=np.uint8, output_type=np.uint8)
    
    top, bottom, left, right, ratio = letterbox_pad_param([AI_RGB888P_WIDTH, AI_RGB888P_HEIGHT], model_input_size)
    my_ai2d.set_pad_param(True, [0, 0, 0, 0, top, bottom, left, right], 0, [128, 128, 128])
    my_ai2d.set_resize_param(True, nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
    ai2d_builder = my_ai2d.build([1, 3, AI_RGB888P_HEIGHT, AI_RGB888P_WIDTH], [1, 3, model_input_size[1], model_input_size[0]])
    
    # kpu初始化
    my_kpu = nn.kpu()
    my_kpu.load_kmodel(kmodel_path)
    input_init_data = np.ones((1, 3, model_input_size[1], model_input_size[0]), dtype=np.uint8)
    kpu_input_tensor = nn.from_numpy(input_init_data)
    
    osd_img = image.Image(DISPLAY_WIDTH, DISPLAY_HEIGHT, image.ARGB8888)
    
    print("YOLOv8初始化完成")
    
    return {
        'model_input_size': model_input_size,
        'confidence_threshold': confidence_threshold,
        'nms_threshold': nms_threshold,
        'max_boxes_num': max_boxes_num,
        'labels': labels,
        'colors': colors,
        'ai2d_builder': ai2d_builder,
        'kpu_input_tensor': kpu_input_tensor,
        'kpu': my_kpu,
        'ratio': ratio,
        'osd_img': osd_img
    }

def deinit_yolov8(yolo_data):
    global _display_initialized
    
    print("[YOLO] 开始释放资源...")
    
    if yolo_data == None:
        return
    
    kpu = yolo_data.get('kpu')
    ai2d = yolo_data.get('ai2d_builder')
    osd_img = yolo_data.get('osd_img')
    
    if osd_img:
        del osd_img
        print("[YOLO] osd_img已删除")
    
    if kpu:
        del kpu
        print("[YOLO] kpu已删除")
    
    if ai2d:
        del ai2d
        print("[YOLO] ai2d已删除")
    
    print("[YOLO] 资源释放完成")

def init_camera():
    print("正在初始化摄像头...")
    Display.init(Display.NT35516, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, osd_num=1, to_ide=True)
    MediaManager.init()
    
    while True:
        plugin, dev_info = UVC.probe()
        if plugin:
            print("摄像头已插入")
            break
        time.sleep_ms(500)
    
    mode = UVC.video_mode()
    succ, mode = UVC.select_video_mode(mode)
    print("视频模式: " + str(mode))
    
    UVC.start(cvt=False)
    print("摄像头启动成功")
    
    return 0

def run_yolov8_detection(yolo_data, u2):
    osd_img = yolo_data['osd_img']
    model_input_size = yolo_data['model_input_size']
    confidence_threshold = yolo_data['confidence_threshold']
    nms_threshold = yolo_data['nms_threshold']
    max_boxes_num = yolo_data['max_boxes_num']
    labels = yolo_data['labels']
    colors = yolo_data['colors']
    ai2d_builder = yolo_data['ai2d_builder']
    kpu_input_tensor = yolo_data['kpu_input_tensor']
    kpu = yolo_data['kpu']
    ratio = yolo_data['ratio']
    
    fps = time.clock()
    
    print("[YOLO] 开始检测循环,发送'stop'可停止")
    
    while True:
        fps.tick()
        
        # 检查蓝牙命令
        cmd = receive_bluetooth(u2, 10)
        if cmd == "stop":
            print("[YOLO] 收到停止命令")
            send_bluetooth(u2, "Detection stopped")
            return 1
        
        if cmd:
            print("[YOLO] 收到命令: " + cmd + " (仅'stop'有效)")
        
        # 获取图像
        img = UVC.snapshot(timeout_ms=1000)
        if img == None:
            print("[YOLO] 获取图像失败")
            continue
        
        img_np = img.to_numpy_ref()
        ai2d_input_tensor = nn.from_numpy(img_np)
        
        # 预处理
        ai2d_builder.run(ai2d_input_tensor, kpu_input_tensor)
        
        # 推理
        kpu.set_input_tensor(0, kpu_input_tensor)
        kpu.run()
        
        # 获取输出
        results = []
        for i in range(kpu.outputs_size()):
            output_i_tensor = kpu.get_output_tensor(i)
            result_i = output_i_tensor.to_numpy()
            results.append(result_i)
            del output_i_tensor
        
        # 后处理
        output_data = results[0][0].transpose()
        boxes_ori = output_data[:, 0:4]
        class_ori = output_data[:, 4:]
        class_res = np.argmax(class_ori, axis=-1)
        scores_ = np.max(class_ori, axis=-1)
        
        # 筛选检测框
        boxes = []
        inds = []
        scores = []
        
        for i in range(len(boxes_ori)):
            if scores_[i] > confidence_threshold:
                x = boxes_ori[i][0]
                y = boxes_ori[i][1]
                w = boxes_ori[i][2]
                h = boxes_ori[i][3]
                x1 = int((x - 0.5 * w) / ratio)
                y1 = int((y - 0.5 * h) / ratio)
                x2 = int((x + 0.5 * w) / ratio)
                y2 = int((y + 0.5 * h) / ratio)
                boxes.append([x1, y1, x2, y2])
                inds.append(class_res[i])
                scores.append(scores_[i])
        
        # NMS
        det_res = []
        if len(boxes) > 0:
            boxes = np.array(boxes)
            scores = np.array(scores)
            inds = np.array(inds)
            
            keep = nms(boxes, scores, nms_threshold)
            dets = np.concatenate((boxes, scores.reshape((len(boxes), 1)), inds.reshape((len(boxes), 1))), axis=1)
            
            for keep_i in keep:
                det_res.append(dets[keep_i])
            
            det_res = np.array(det_res)
            if len(det_res) > max_boxes_num:
                det_res = det_res[:max_boxes_num, :]
            
            # 绘制
            osd_img.clear()
            for det in det_res:
                x_1 = int(round(det[0], 0))
                y_1 = int(round(det[1], 0))
                x_2 = int(round(det[2], 0))
                y_2 = int(round(det[3], 0))
                
                draw_x = int(x_1 * DISPLAY_WIDTH // AI_RGB888P_WIDTH)
                draw_y = int(y_1 * DISPLAY_HEIGHT // AI_RGB888P_HEIGHT)
                draw_w = int((x_2 - x_1) * DISPLAY_WIDTH // AI_RGB888P_WIDTH)
                draw_h = int((y_2 - y_1) * DISPLAY_HEIGHT // AI_RGB888P_HEIGHT)
                
                label_idx = int(det[5])
                score_str = "{0:.3f}".format(det[4])
                
                osd_img.draw_rectangle(draw_x, draw_y, draw_w, draw_h, color=colors[label_idx], thickness=4)
                
                label_y = draw_y - 50
                if label_y < 0:
                    label_y = 0
                
                osd_img.draw_string_advanced(draw_x, label_y, 24, labels[label_idx] + " " + score_str, color=colors[label_idx])
        else:
            osd_img.clear()
        
        Display.show_image(osd_img)
        print("[YOLO] FPS: " + str(fps.fps()) + ", 检测数: " + str(len(det_res)))
        gc.collect()

def main():
    print("=" * 50)
    print("嵌赛 - 蓝牙控制YOLOv8检测")
    print("=" * 50)
    
    u2 = init_bluetooth()
    if u2 == None:
        print("[错误] 蓝牙初始化失败,程序退出")
        return -1
    
    send_bluetooth(u2, "========================================")
    send_bluetooth(u2, "嵌赛系统已启动")
    send_bluetooth(u2, "可用命令:")
    send_bluetooth(u2, "  run  - 启动YOLOv8检测")
    send_bluetooth(u2, "  stop - 停止检测")
    send_bluetooth(u2, "  help - 显示帮助")
    send_bluetooth(u2, "========================================")
    
    yolo_data = None
    os.exitpoint(os.EXITPOINT_ENABLE)
    
    while True:
        os.exitpoint()
        
        cmd = receive_bluetooth(u2, 100)
        
        if cmd == None:
            time.sleep_ms(50)
            continue
        
        cmd_lower = cmd.lower()
        
        if cmd_lower == "run":
            if yolo_data != None:
                send_bluetooth(u2, "检测已在运行中,先发送'stop'停止")
                continue
            
            send_bluetooth(u2, "正在初始化YOLOv8系统...")
            yolo_data = init_yolov8()
            
            if yolo_data == None:
                send_bluetooth(u2, "YOLOv8初始化失败")
                continue
            
            send_bluetooth(u2, "YOLOv8检测已启动")
            send_bluetooth(u2, "发送'stop'可停止检测")
            
            stopped = run_yolov8_detection(yolo_data, u2)
            
            if stopped:
                deinit_yolov8(yolo_data)
                yolo_data = None
                send_bluetooth(u2, "检测已停止,系统回到等待状态")
        
        elif cmd_lower == "stop":
            if yolo_data == None:
                send_bluetooth(u2, "当前没有运行的检测")
            else:
                send_bluetooth(u2, "检测正在停止中...")
        
        elif cmd_lower == "help":
            send_bluetooth(u2, "可用命令:")
            send_bluetooth(u2, "  run  - 启动YOLOv8检测")
            send_bluetooth(u2, "  stop - 停止检测")
            send_bluetooth(u2, "  help - 显示帮助")
        
        else:
            send_bluetooth(u2, "未知命令: " + cmd)
            send_bluetooth(u2, "发送'help'查看可用命令")
        
        time.sleep_ms(50)

if __name__ == "__main__":
    main()