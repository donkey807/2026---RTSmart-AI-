#此例程通过拓展板上的UART2_TXD和UART2_RXD能进行发送数据到pc端
from machine import UART
from machine import FPIOA

#引脚11和12复用为UART2_RX和UART_TX
fpioa = FPIOA()
fpioa.set_function(11,FPIOA.UART2_TXD)
fpioa.set_function(12,FPIOA.UART2_RXD)

# UART2: baudrate 115200, 8bits, parity none, one stopbits
u2 = UART(UART.UART2, baudrate=115200, bits=UART.EIGHTBITS, parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)
#UART init
u2.init(baudrate=115200, bits=UART.EIGHTBITS, parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)
# UART write
i = 0;
for i  in range (i,10):
    u2.write("你好世界\r\n")
# UART read
r = u2.read()
# UART readline
r = u2.readline()
# UART readinto
b = bytearray(8)
r = u2.readinto(b)
# UART deinit
u2.deinit()
