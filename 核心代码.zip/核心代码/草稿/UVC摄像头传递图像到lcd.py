import time, gc, os, image,sys
from media.display import *
from media.media import *
from media.uvc import *



DISPLAY_WIDTH  = 960
DISPLAY_HEIGHT = 536

os.exitpoint(os.EXITPOINT_ENABLE)

Display.init(Display.NT35516, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, to_ide=False,osd_num=3)
MediaManager.init()

try:
    print("等待UVC摄像头...")
    while True:
        plugin, dev = UVC.probe()
        if plugin:
            print(f"检测到摄像头: {dev}")
            break
        time.sleep_ms(500)

    mode = UVC.video_mode(640,480,UVC.FOURCC_YUY2,30)#摄像头最大分辨率，格式只支持这一种

    succ, mode = UVC.select_video_mode(mode)
    print(f"select mode success: {succ}, mode: {mode}")
    
    UVC.start(cvt=True)

    fps = time.clock()
    while True:
        os.exitpoint()
        fps.tick()
        img = UVC.snapshot()
        if img is not None:
            
            img = img.to_rgb565()
            #拉伸图像适配lcd
            img = img.scale(x_scale=1.49, y_scale=1.1)#960/480,536/480
            Display.show_image(img,Display.LAYER_OSD0)
            del img
            gc.collect()
            print(f"fps: {fps.fps():.2f}")

finally:
    UVC.stop()
    Display.deinit()
    time.sleep_ms(100)
    MediaManager.deinit()
    print("资源已释放")