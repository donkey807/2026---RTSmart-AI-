from machine import UART, FPIOA, Pin
import time
import gc

# 禁用垃圾回收，减少内存溢出导致的软重启
gc.disable()

# ====================== 1. 硬件初始化 ======================
# 1.1 配置LED引脚（引脚6）- 增加初始化日志
fpioa = FPIOA()
fpioa.set_function(6, FPIOA.GPIO6)
LED1 = Pin(6, Pin.OUT)
LED1.value(0)  # 初始灭灯
print(f"🔧 LED引脚初始化完成（引脚6），初始状态：{LED1.value()}")

# 1.2 配置UART2（连接ESP8266，引脚11=TX，12=RX）
fpioa.set_function(11, FPIOA.UART2_TXD)
fpioa.set_function(12, FPIOA.UART2_RXD)

# 统一波特率为115200（ESP8266默认115200，避免不匹配）
u2 = UART(UART.UART2, baudrate=115200, bits=UART.EIGHTBITS,
          parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)

# ====================== 2. ESP8266 AT指令通信函数 ======================
def send_at_cmd(cmd, timeout=2):
    """
    稳定版AT指令发送函数（适配华为热点Client模式）
    :param cmd: AT指令（不带\r\n）
    :param timeout: 等待响应超时时间（秒）
    :return: 响应结果（过滤后的字符串）
    """
    # 发送前清空串口缓冲区（关键：避免历史数据干扰）
    if u2.any():
        u2.read(u2.any())
        time.sleep_ms(50)

    # 发送AT指令（严格加\r\n，ESP8266必需）
    u2.write((cmd + "\r\n").encode('utf-8'))
    time.sleep_ms(100)  # 给ESP8266处理时间

    resp = ""
    start_time = time.time()
    # 循环读取响应，直到超时
    while (time.time() - start_time) < timeout:
        if u2.any():  # 有数据可读
            raw_data = u2.read(u2.any())
            # 过滤乱码，只保留可打印ASCII字符
            resp += ''.join([chr(b) for b in raw_data if 0x20 <= b <= 0x7E])
            time.sleep_ms(50)
    return resp

# ====================== 3. 初始化ESP8266（Client模式：主动连PC） ======================
def esp8266_init(ssid, password, pc_ip, pc_port=8888):
    print("开始初始化ESP8266...")
    # 步骤1：测试AT指令通信（基础校验）
    resp = send_at_cmd("AT")
    if "OK" not in resp:
        print("❌ ESP8266通信失败！检查接线/波特率")
        print(f"响应数据：{resp}")
        return False

    # 步骤2：重启ESP8266（清除旧配置）
    print("🔄 重启ESP8266...")
    send_at_cmd("AT+RST")
    time.sleep(3)  # 重启必需等待3秒

    # 步骤3：关闭回显（避免响应重复）
    send_at_cmd("ATE0")
    time.sleep(0.5)

    # 步骤4：设置STA模式（连接WiFi）
    resp = send_at_cmd("AT+CWMODE=1")
    if "OK" not in resp:
        print("❌ 设置STA模式失败")
        print(f"响应数据：{resp}")
        return False
    time.sleep(1)

    # 步骤5：连接华为手机热点（延长超时，适配热点连接速度）
    print(f"📶 连接热点：{ssid}...")
    cmd = f'AT+CWJAP="{ssid}","{password}"'
    resp = send_at_cmd(cmd, timeout=10)  # 超时延长至10秒
    time.sleep(2)

    # 严格判断连接成功
    if "WIFI CONNECTED" in resp or "WIFI GOT IP" in resp:
        print("✅ 热点连接成功！")
    else:
        print("❌ 热点连接失败！检查热点名/密码/距离")
        print(f"响应数据：{resp}")
        return False

    # 步骤6：关闭多连接（单连接更稳定，适配Client模式）
    send_at_cmd("AT+CIPMUX=0")
    time.sleep(0.5)

    # 步骤7：ESP8266主动连接PC的TCP Server（核心：绕过华为隔离）
    print(f"🔌 连接PC的TCP Server ({pc_ip}:{pc_port})...")
    cmd = f'AT+CIPSTART="TCP","{pc_ip}",{pc_port}'
    resp = send_at_cmd(cmd, timeout=8)
    if "OK" in resp or "CONNECT" in resp:
        print(f"✅ 已成功连接PC: {pc_ip}:{pc_port}")
    else:
        print("❌ 连接PC失败！检查：")
        print("  1. PC是否连同一华为热点")
        print("  2. PC是否开启TCP Server（NetAssist）")
        print("  3. PC防火墙是否关闭")
        print(f"响应数据：{resp}")
        return False

    # 操作提示
    print("=================== 初始化完成 ===================")
    print("📱 操作提示：")
    print(f"1. 在PC的NetAssist中发送 1=亮灯，0=灭灯")
    print(f"2. 断开连接可发送 AT+CIPCLOSE")
    print("==================================================")
    return True

# ====================== 4. 主逻辑：接收PC指令控制LED（核心修复） ======================
def main():
    # ====================== 你需要修改的3个参数 ======================
    PHONE_HOTSPOT_SSID = "12345"       # 你的华为热点名（无中文）
    PHONE_HOTSPOT_PWD = "12345678"     # 你的华为热点密码
    PC_IP = "192.168.43.251"           # 你的PC在热点下的IPv4地址
    # =================================================================

    # 初始化ESP8266（主动连接PC）
    init_ok = esp8266_init(PHONE_HOTSPOT_SSID, PHONE_HOTSPOT_PWD, PC_IP, 8888)
    if not init_ok:
        print("❌ 初始化失败，退出主循环")
        return

    # 循环接收PC的TCP指令（核心控制逻辑）
    print("\n⏳ 等待PC发送控制指令（1=亮，0=灭）...")
    while True:
        if u2.any():  # 有串口数据（ESP转发的PC指令）
            raw_data = u2.read(u2.any())
            # 过滤可打印字符，避免乱码
            data = ''.join([chr(b) for b in raw_data if 0x20 <= b <= 0x7E]).strip()
            if data:
                print(f"📥 收到PC指令：{data}")

                # 核心修复1：精准提取0/1（去掉+IPD,1:前缀）
                pure_data = data.split(":")[-1].strip()  # 只保留冒号后的数据
                print(f"🔍 提取纯指令：{pure_data}")

                # 核心修复2：严格判断指令，增加引脚状态打印
                if pure_data == "1":
                    LED1.value(1)  # 强制设为高电平
                    current_state = LED1.value()
                    print(f"🔴 指令执行：LED亮（引脚实际状态：{current_state}）")
                    # 回复PC：确认指令
                    send_at_cmd("AT+CIPSEND=6")
                    time.sleep_ms(100)
                    send_at_cmd("LED ON")
                elif pure_data == "0":
                    LED1.value(0)  # 强制设为低电平
                    current_state = LED1.value()
                    print(f"⚫ 指令执行：LED灭（引脚实际状态：{current_state}）")
                    # 回复PC：确认指令
                    send_at_cmd("AT+CIPSEND=7")
                    time.sleep_ms(100)
                    send_at_cmd("LED OFF")
                else:
                    print(f"❌ 无效指令：{pure_data}，仅支持发送0或1")
        time.sleep_ms(100)

# 启动主程序
if __name__ == "__main__":
    main()
