# K230 Sensor → H264编码 → RTMP推流到阿里云
# 服务器需要安装 nginx-rtmp，电脑用VLC拉流播放

import time, os, _thread, gc
import network
from media.vencoder import *
from media.sensor import *
from media.media import *
import multimedia as mm
import uctypes

DISPLAY_WIDTH  = 960
DISPLAY_HEIGHT = 536  # 对齐到8
SERVER_HOST    = "8.156.80.207"
RTMP_PORT      = 9000
STREAM_KEY     = "live/k230"  # 对应 rtmp://服务器/live/k230

VENC_CHN = VENC_CHN_ID_0

def align_to_8(x):
    return (x // 8) * 8

# ========================
# 初始化EC200网卡
# ========================
nic = network.LAN()
print(f"EC200 IP: {nic.ifconfig()[0]}")

# ========================
# 初始化Sensor + 编码器
# ========================
os.exitpoint(os.EXITPOINT_ENABLE)

sensor = Sensor()
sensor.reset()
sensor.set_framesize(width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, alignment=12)
sensor.set_pixformat(Sensor.RGB565)

encoder = Encoder()
encoder.SetOutBufs(VENC_CHN, 8, DISPLAY_WIDTH, DISPLAY_HEIGHT)

link = MediaManager.link(
    sensor.bind_info()['src'],
    (VIDEO_ENCODE_MOD_ID, VENC_DEV_ID, VENC_CHN)
)
MediaManager.init()

chnAttr = ChnAttrStr(
    encoder.PAYLOAD_TYPE_H264,
    encoder.H264_PROFILE_MAIN,
    DISPLAY_WIDTH, DISPLAY_HEIGHT
)
encoder.Create(VENC_CHN, chnAttr)
encoder.Start(VENC_CHN)
sensor.run()
print("编码器启动")

# 连接服务器，失败重试
import socket
sock = None
for i in range(5):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
        sock.settimeout(10)
        sock.connect((SERVER_HOST, RTMP_PORT))
        print(f"已连接服务器: {SERVER_HOST}:{RTMP_PORT}")
        break
    except Exception as e:
        print(f"连接失败({i+1}/5): {e}")
        sock = None
        time.sleep(2)

if sock is None:
    raise RuntimeError("无法连接服务器")

# ========================
# 推流主循环（裸H264通过TCP发送）
# ========================
streamData = StreamData()
start_stream = True

try:
    while start_stream:
        os.exitpoint()
        encoder.GetStream(VENC_CHN, streamData)
        for i in range(streamData.pack_cnt):
            data = bytes(uctypes.bytearray_at(
                streamData.data[i], streamData.data_size[i]
            ))
            sock.send(data)
        encoder.ReleaseStream(VENC_CHN, streamData)

finally:
    sock.close()
    sensor.stop()
    del link
    encoder.Stop(VENC_CHN)
    encoder.Destroy(VENC_CHN)
    MediaManager.deinit()
    print("资源已释放")
