'''
主线程（main.py）
├── 初始化所有硬件（Display、Sensor、LVGL、蓝牙、WiFi）
├── 启动子线程
└── 主循环：LVGL task_handler（必须在主线程跑）+ 蓝牙轮询

子线程：AI推理线程
├── 从Sensor取帧
├── 运行模型推理
├── 绘制OSD结果
└── 受全局状态控制（运行/暂停）

子线程：WiFi推流线程
├── 从队列取帧
└── HTTP/TCP上传到云服务

#在按键按下前先开始预热模型，保证帧率稳定

'''
#ai检测
from libs.PipeLine import PipeLine, ScopedTiming
from libs.AI2D import Ai2d
from libs.AIBase import AIBase
import nncase_runtime as nn
import ulab.numpy as np
import aidemo
#硬件驱动
from media.display import *  # 显示模块
from media.media import *  # 媒体管理模块
#固件系统
import utime, os, sys, gc, image  # 时间、系统、垃圾回收模块
import _thread  # 多线程支持
#蓝牙
from machine import UART, FPIOA
#云服务器
import network,socket
from machine import UART
#lvgl控件
import lvgl as lv
from machine import TOUCH

from media.uvc import *
import uctypes

#屏幕
DISPLAY_WIDTH = 960
DISPLAY_HEIGHT = 536
# LVGL 放到左侧空白区域，UVC 原图显示在右侧
LVGL_W = 280
LVGL_H = DISPLAY_HEIGHT
LVGL_X = 0
LVGL_Y = 0
ENABLE_LVGL = True

rgb888p_size = [640, 480]       # UVC原始分辨率，AI2D自动padding
display_size = [960, 536]       # 显示分辨率
UVC_DISPLAY_X = DISPLAY_WIDTH - rgb888p_size[0]
UVC_DISPLAY_Y = 0
# 触摸屏原始坐标校准边界（按当前固件实测）
TOUCH_RAW_X_MIN = 55
TOUCH_RAW_X_MAX = 946
TOUCH_RAW_Y_MIN = 52
TOUCH_RAW_Y_MAX = 451
#蓝牙串口
# BT_UART = UART.UART2
# BT_TX_PIN = 11          # FPIOA引脚
# BT_RX_PIN = 12
# BT_BAUDRATE = 9600
# 图像传输质量
JPEG_QUALITY = 30
AI_INFER_EVERY_N_FRAMES = 2
STREAM_SEND_EVERY_N_FRAMES = 2
STREAM_SCALE_X = 0.5
STREAM_SCALE_Y = 0.5
SAVE_IMAGE_DIR = "/data/image"

DET_KMODEL_PATH = "/sdcard/examples/kmodel/best_simplified.kmodel"
DET_MODEL_INPUT_SIZE = [640, 640]
DET_LABELS = ["stones"]
DET_MAX_BOXES_NUM = 50
DET_NMS_THRESHOLD = 0.2
DET_DEFAULT_CONFIDENCE = 0.5

#服务端口
SERVER_HOST    = "8.156.80.207"
SERVER_PORT    = 8080  # 裸TCP端口，和Flask 8080分开

# WiFi配置（共享热点名字和密码）
WIFI_SSID = "12345"
WIFI_PASSWORD = "12345678"

# 网络模式选择: "wifi" 或 "ec200"
NETWORK_MODE = "ec200"

#sock = None           # TCP socket


# --- 线程安全的状态管理---
_state_lock = _thread.allocate_lock()#状态锁，保护_ai_det_stop、_running、_stream_enabled等变量的读写
_confidence_lock = _thread.allocate_lock()#线程锁，保护置信度等变量的读写
_queue_lock = _thread.allocate_lock()#帧队列锁，保护_frame_queue等变量的读写
_sock_lock = _thread.allocate_lock()#socket锁，保护sock变量的读写

# 内部状态变量
_ai_det_stop = False
_running = False
_stream_enabled = False
_confidence_threshold = DET_DEFAULT_CONFIDENCE#默认值
_save_image_requested = False
_stream_connected = False
_wlan = None
# LCD toast提示（最上端显示2秒后消失）
_toast_msg = ""
_toast_tick = 0

def set_ai_det_stop(val):
    with _state_lock:
        global _ai_det_stop
        _ai_det_stop = val

def is_ai_det_stop():
    with _state_lock:
        return _ai_det_stop

def set_running(val):
    with _state_lock:
        global _running
        _running = val

def is_running():
    with _state_lock:
        return _running

def set_stream_enabled(val):
    with _state_lock:
        global _stream_enabled
        _stream_enabled = val

def is_stream_enabled():
    with _state_lock:
        return _stream_enabled

def set_stream_connected(val):
    with _state_lock:
        global _stream_connected
        _stream_connected = val

def is_stream_connected():
    with _state_lock:
        return _stream_connected
    
def change_confidence_threshold(val):
    with _confidence_lock:
        global _confidence_threshold
        _confidence_threshold = val
def get_confidence_threshold():
    with _confidence_lock:
        return _confidence_threshold

def request_save_image():
    with _state_lock:
        global _save_image_requested
        _save_image_requested = True

def consume_save_image_request():
    with _state_lock:
        global _save_image_requested
        requested = _save_image_requested
        _save_image_requested = False
        return requested

def align_to_8(x): return (x // 8) * 8
def align_to_16(x): return (x // 16) * 16

# ========================
# 帧队列（AI线程 -> 推流线程）
# ========================

_frame_queue = []
# 发送队列长度
QUEUE_SIZE = 2
_last_socket_fail_ms = 0
def queue_put(frame_obj):
    global _frame_queue
    with _queue_lock:
        while len(_frame_queue) >= QUEUE_SIZE:
            _frame_queue.pop(0)
        _frame_queue.append(frame_obj)

def queue_get():
    with _queue_lock:
        if _frame_queue:
            return _frame_queue.pop(0)
    return None

def print_det_config():
    print("[DET] kmodel =", DET_KMODEL_PATH)
    print("[DET] input_size =", DET_MODEL_INPUT_SIZE)
    print("[DET] labels =", DET_LABELS)

def ensure_dir(path):
    normalized = path.replace("\\", "/")
    parts = [part for part in normalized.split("/") if part]
    current = "/" if normalized.startswith("/") else ""

    for part in parts:
        current = current + part if current in ("", "/") else current + "/" + part
        try:
            os.mkdir(current)
        except OSError:
            pass

def save_detected_image(img):
    ensure_dir(SAVE_IMAGE_DIR)
    timestamp = utime.ticks_ms()
    file_path = f"{SAVE_IMAGE_DIR}/det_{timestamp}.jpg"
    img.save(file_path)
    print(f"[SAVE] {file_path}")
    return file_path

class ObjectDetectionApp(AIBase):
    """YOLOv8目标检测应用类（继承自AIBase）"""

    def __init__(self, kmodel_path, labels, model_input_size, max_boxes_num,
                 confidence_threshold = get_confidence_threshold(), nms_threshold=0.2,
                 rgb888p_size=[224,224], display_size=[1920,1080], debug_mode=0):
        """
        初始化YOLO检测器
        Args:
            kmodel_path: kmodel模型文件路径
            labels: 类别标签列表
            model_input_size: 模型输入尺寸 [w, h]
            max_boxes_num: 最大检测框数量
            confidence_threshold: 置信度阈值
            nms_threshold: NMS阈值
            rgb888p_size: Sensor给AI的图像分辨率
            display_size: 显示分辨率
            debug_mode: 调试模式0=关闭1=开启
        """
        super().__init__(kmodel_path, model_input_size, rgb888p_size, debug_mode)
        self.kmodel_path = kmodel_path
        self.labels = labels
        self.model_input_size = model_input_size
        self.confidence_threshold = confidence_threshold
        self.nms_threshold = nms_threshold
        self.max_boxes_num = max_boxes_num

        # 分辨率对齐（满足硬件要求）
        self.rgb888p_size = [align_to_16(rgb888p_size[0]), rgb888p_size[1]]
        self.display_size = [align_to_16(display_size[0]), align_to_8(display_size[1])]
        self.debug_mode = debug_mode

        # 坐标缩放因子（模型坐标-> Sensor坐标）
        self.x_factor = float(self.rgb888p_size[0]) / self.model_input_size[0]
        self.y_factor = float(self.rgb888p_size[1]) / self.model_input_size[1]

        # AI2D预处理对象（用于图像缩放、填充等）
        self.ai2d = Ai2d(debug_mode)
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.RGB_packed, nn.ai2d_format.NCHW_FMT,
                                  np.uint8, np.uint8)

    def config_preprocess(self, input_image_size=None):
        """配置图像预处理流程（缩放+填充）"""
        with ScopedTiming("set preprocess config", self.debug_mode > 0):
            ai2d_input_size = input_image_size if input_image_size else self.rgb888p_size
            # 计算填充参数
            top, bottom, left, right = self.get_padding_param()
            # 添加填充（灰色背景）
            self.ai2d.pad([0,0,0,0,top,bottom,left,right], 0, [128,128,128])
            # 双线性插值缩放
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
            # 构建预处理流程
            self.ai2d.build([1, ai2d_input_size[1], ai2d_input_size[0], 3],
                           [1, 3, self.model_input_size[1], self.model_input_size[0]])

    def get_padding_param(self):
        """计算填充参数（保持宽高比的Letterbox填充）"""
        dst_w = self.model_input_size[0]   # 目标宽度
        dst_h = self.model_input_size[1]   # 目标高度
        ratio_w = dst_w / self.rgb888p_size[0]  # 宽度缩放比
        ratio_h = dst_h / self.rgb888p_size[1]  # 高度缩放比
        ratio = min(ratio_w, ratio_h)      # 取较小比例（保持完整图像）

        new_w = int(ratio * self.rgb888p_size[0])  # 缩放后宽度
        new_h = int(ratio * self.rgb888p_size[1])  # 缩放后高度

        # 计算需要填充的像素
        dw = (dst_w - new_w) / 2
        dh = (dst_h - new_h) / 2
        top = int(round(0))
        bottom = int(round(dh * 2 + 0.1))
        left = int(round(0))
        right = int(round(dw * 2 - 0.1))
        return top, bottom, left, right

    def postprocess(self, results):
        with ScopedTiming("postprocess", self.debug_mode > 0):
            # 人头检测模型输出[1,6,8400]=4坐标+1置信度+1类别
            output = results[0][0]  # shape [6, 8400]
            det_res = aidemo.yolov8_det_postprocess(
                output.transpose().copy(),
                [self.rgb888p_size[1], self.rgb888p_size[0]],#640x480
                [self.model_input_size[1], self.model_input_size[0]],#320x320
                [self.display_size[1], self.display_size[0]],#960x536
                len(self.labels), self.confidence_threshold,
                self.nms_threshold, self.max_boxes_num
            )
            return det_res

    def draw_result(self, osd_img, dets):
        """在OSD图层上绘制检测结果（边界框、标签）"""
        with ScopedTiming("display_draw", self.debug_mode > 0):
            osd_img.clear()  # 清除上一帧残留

            if dets:
                # 遍历所有检测到的目标
                for i in range(len(dets[0])):
                    # 后处理结果是显示坐标系下的左上角 + 宽高
                    x, y, w, h = map(lambda v: int(round(v, 0)), dets[0][i])
                    x1, y1, w, h = clamp_box(
                        x, y, w, h, self.display_size[0], self.display_size[1]
                    )

                    # 绘制黄色边界框
                    osd_img.draw_rectangle(x1, y1, w, h, color=(255, 255, 0, 255), thickness=3)

                    # 绘制标签和置信度
                    conf = dets[2][i]
                    label_text = f"{self.labels[dets[1][i]]} {conf:.1%}"
                    label_y = y1 - 36
                    if label_y < 0:
                        label_y = min(self.display_size[1] - 32, y1 + 4)
                    osd_img.draw_string_advanced(x1, label_y, 28, label_text, color=(255, 255, 0, 255))

def thread_AI_detect():
    """YOLOv8目标检测线程函数"""
    global uvc, rgb888p_size, display_size, yolo_osd_img

    # YOLO模型配置
    print_det_config()
    ob_det = ObjectDetectionApp(DET_KMODEL_PATH, labels=DET_LABELS,
                                model_input_size=DET_MODEL_INPUT_SIZE,
                                max_boxes_num=DET_MAX_BOXES_NUM,
                                confidence_threshold=get_confidence_threshold(),
                                nms_threshold=DET_NMS_THRESHOLD,
                                rgb888p_size=rgb888p_size,
                                display_size=rgb888p_size,
                                debug_mode=0)
    ob_det.config_preprocess()


    # FPS计算器
    fps = utime.clock()
    fps.tick()
    frame_count = 0

    print("[预热] 开始..")
    for _ in range(5):
        raw_uvc = UVC.snapshot()
        img_uvc = None
        img_ai = None
        img_np = None
        if raw_uvc is not None:
            try:
                img_uvc = raw_uvc.to_rgb565()
                img_ai = img_uvc.to_rgb888()
                img_np = img_ai.to_numpy_ref()
                try:
                    ob_det.run(img_np)
                except RuntimeError as e:
                    print("[DET] warmup KPU run failed")
                    print_det_config()
                    print("[DET] error =", e)
                    raise
            finally:
                if img_np is not None:
                    del img_np
                if img_ai is not None:
                    del img_ai
                if img_uvc is not None:
                    del img_uvc
                raw_uvc.__del__()
    print("[预热] 完成")

    
    last_display_img = None  # 上一帧显示图像
    last_det_res = None
    ai_frame_index = 0
    stream_frame_index = 0
    while True:
        if is_ai_det_stop():
            break

        if not is_running():
            raw_uvc = UVC.snapshot()
            if raw_uvc is None:
                utime.sleep_ms(10)
                continue

            img_uvc = None
            img_display = None
            try:
                img_uvc = raw_uvc.to_rgb565()
                img_display = img_uvc

                if is_stream_enabled() and is_stream_connected():
                    queue_put(img_uvc)

                draw_toast(img_display)
                Display.show_image(img_display, UVC_DISPLAY_X, UVC_DISPLAY_Y, Display.LAYER_OSD0)

                if last_display_img is not None:
                    del last_display_img
                last_display_img = img_display
            finally:
                if img_uvc is not None and img_uvc is not last_display_img:
                    del img_uvc
                raw_uvc.__del__()

            utime.sleep_ms(1)
            continue

        # 获取图像并推理
        raw_uvc = UVC.snapshot()
        if raw_uvc is None:# 判断图像无效
        
            utime.sleep_ms(10)
            continue
        
        img_uvc = None
        img_ai = None
        img_np = None
        det_res = last_det_res
        try:
            fps.tick()
            img_uvc = raw_uvc.to_rgb565()  # 用于显示
            img_display = img_uvc
            ai_frame_index += 1
            if ai_frame_index % AI_INFER_EVERY_N_FRAMES == 0:
                img_ai = img_uvc.to_rgb888()   # 用于AI推理
                img_np = img_ai.to_numpy_ref()
                ob_det.confidence_threshold = get_confidence_threshold()
                try:
                    det_res = ob_det.run(img_np)
                except RuntimeError as e:
                    print("[DET] inference KPU run failed")
                    print_det_config()
                    print("[DET] error =", e)
                    raise
                last_det_res = det_res

            current_fps = fps.fps()
            if det_res and det_res[0]:

                for i in range(len(det_res[0])):
                    x, y, w, h = map(lambda v: int(round(v, 0)), det_res[0][i])
                    x, y, w, h = clamp_box(x, y, w, h, rgb888p_size[0], rgb888p_size[1])
                    # 绘制黄色边界框到原始图像上
                    img_display.draw_rectangle(x, y, w, h, color=(255, 255, 0), thickness=2)
                    conf = det_res[2][i]
                    label_text = f"{DET_LABELS[det_res[1][i]]} {conf:.1%}"
                    label_y = y - 24 if y - 24 >= 0 else y + 4
                    img_display.draw_string_advanced(x, label_y, 24, label_text, color=(255, 255, 0))
           
            img_display.draw_string_advanced(400, 450, 24, get_osd_status_text(current_fps), color=(255, 0, 0))
            
            if consume_save_image_request():
                if det_res and det_res[0]:
                    try:
                        saved_path = save_detected_image(img_display)
                        set_toast(f"保存成功 {saved_path}")
                    except Exception as e:
                        print(f"[SAVE] failed: {e}")
                else:
                    print("[SAVE] skip: no detection in current frame")
            
            # 减轻多余运算，提升帧率（启用WiFi上传到云服务器时启用）
            # if is_stream_enabled():
            #     img_ec200 = img_uvc.scale(x_scale=0.5, y_scale=0.5)
            #     jpeg = img_ec200.compressed(JPEG_QUALITY)
            #     queue_put(jpeg)
            #     del img_ec200, jpeg
            if is_stream_enabled() and is_stream_connected():
                stream_frame_index += 1
                if stream_frame_index % STREAM_SEND_EVERY_N_FRAMES == 0:
                    queue_put(img_uvc)
            # 3. 居中显示 (计算偏移量，消除黑边不对)
            # 缩放后宽度：640 * 1.1166 = 714
            # 居中偏移量：(960 - 714) / 2 = 123
            OFFSET_X = UVC_DISPLAY_X
            OFFSET_Y = UVC_DISPLAY_Y
            
            # 显示放大后的画面和放大后的框
            draw_toast(img_display)
            Display.show_image(img_display, OFFSET_X, OFFSET_Y, Display.LAYER_OSD0)
            
            # 安全释放内存
            if last_display_img is not None:
                del last_display_img
            last_display_img = img_display
          

            # 打印检测统计
            frame_count += 1
            if frame_count % 10 == 0:
                det_count = len(det_res[0]) if det_res and det_res[0] else 0
                print(f"[YOLOv8检测] FPS:{current_fps:.2f} 检测到 {det_count} 个物体")
                
        finally:
            if img_np is not None:
                del img_np
            if img_ai is not None:
                del img_ai
            if img_uvc is not None and img_uvc is not last_display_img:
                del img_uvc
            raw_uvc.__del__()

            if frame_count % 30 == 0:  
                gc.collect()

            

    ob_det.deinit()

def media_init():
    print("media_init OK")
    global yolo_osd_img
    osd_num = 3 if ENABLE_LVGL else 2
    Display.init(Display.NT35516, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT, to_ide=False, osd_num=osd_num)

    yolo_osd_img = image.Image(display_size[0], align_to_8(display_size[1]), image.ARGB8888)

    MediaManager.init()
    print("waiting for UVC camera...")
    probe_retry = 0
    while True:
        plugin, dev = UVC.probe()
        probe_retry += 1
        if plugin:
            print(f"UVC detected: {dev}")
            break
        if probe_retry % 10 == 0:
            print(f"UVC probe retry={probe_retry}, plugin={plugin}, dev={dev}")
        utime.sleep_ms(500)

    mode = UVC.video_mode(640, 480, UVC.FOURCC_YUY2, 30)
    succ, mode = UVC.select_video_mode(mode)
    print(f"select mode success: {succ}, mode: {mode}")
    UVC.start(cvt=True)
    print("media_init OK")

def media_deinit():
    global uvc
    UVC.stop()
    Display.deinit()
    utime.sleep_ms(100)
    MediaManager.deinit()
    print("media_deinit OK")



_sock = None

def get_socket():

    '''
    获取socket连接的函数，使用单例模式确保只有一个TCP连接
    如果连接不存在则创建新的连接，如果存在则直接返回
    '''
    global _sock  # 声明全局变量_sock，用于存储socket连接
    global _last_socket_fail_ms
    with _sock_lock:  # 使用锁机制确保线程安全
        if _sock is None:  # 检查socket连接是否存在
            now = utime.ticks_ms()
            if _last_socket_fail_ms and utime.ticks_diff(now, _last_socket_fail_ms) < 2000:
                return None
            try:
                # 创建TCP socket连接
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
                s.settimeout(0.5)
                s.connect((SERVER_HOST, SERVER_PORT))
                _sock = s
                _last_socket_fail_ms = 0
                print("TCP连接成功")
            except Exception as e:
                print("TCP连接失败:", e)
                _last_socket_fail_ms = utime.ticks_ms()
                _sock = None
        return _sock

def close_socket():
    global _sock
    global _last_socket_fail_ms
    with _sock_lock:
        if _sock:
            try:
                _sock.close()
            except:
                pass
            _sock = None
        _last_socket_fail_ms = 0

def get_net_status_text():
    if not is_stream_enabled():
        return "NET:OFF"

    if not is_stream_connected():
        return "NET:WAIT"

    with _sock_lock:
        if _sock:
            return "NET:OK"

    return "NET:WAIT"

def set_toast(msg):
    """设置LCD顶部提示消息，持续2秒"""
    global _toast_msg, _toast_tick
    _toast_msg = msg
    _toast_tick = utime.ticks_ms()

def draw_toast(img):
    """在图像顶部绘制toast消息"""
    global _toast_msg, _toast_tick
    if _toast_msg:
        elapsed = utime.ticks_diff(utime.ticks_ms(), _toast_tick)
        if elapsed < 2000:
            img.draw_string_advanced(10, 5, 28, _toast_msg, color=(0, 255, 0))
        else:
            _toast_msg = ""

def get_osd_status_text(fps_value):
    return f"FPS:{fps_value:.1f} {get_net_status_text()}"

def clamp_box(x, y, w, h, width, height):
    x = max(0, min(int(x), width - 1))
    y = max(0, min(int(y), height - 1))
    w = max(1, int(w))
    h = max(1, int(h))
    if x + w > width:
        w = width - x
    if y + h > height:
        h = height - y
    return x, y, max(1, w), max(1, h)

def draw_detections_on_image(img, dets, src_size, dst_size):
    if not dets:
        return

    scale_x = float(dst_size[0]) / src_size[0]
    scale_y = float(dst_size[1]) / src_size[1]

    for i in range(len(dets[0])):
        x, y, w, h = map(lambda v: int(round(v, 0)), dets[0][i])
        x = int(x * scale_x)
        y = int(y * scale_y)
        w = int(w * scale_x)
        h = int(h * scale_y)
        x, y, w, h = clamp_box(x, y, w, h, dst_size[0], dst_size[1])
        img.draw_rectangle(x, y, w, h, color=(255, 255, 0), thickness=2)

def send_frame_safe(jpeg_bytes):
    sock = get_socket()
    if not sock:
        return
    
    try:
        size = len(jpeg_bytes)
        header = bytes([(size>>24)&0xFF, (size>>16)&0xFF, (size>>8)&0xFF, size&0xFF])
        sock.send(header + jpeg_bytes)
    except Exception as e:
        print("发送失败", e)
        close_socket() # 安全关闭并置空

def thread_WIFI():
    global _wlan
    _wlan = network.WLAN(network.STA_IF)
    _wlan.active(True)
    print("connecting to WiFi...")
    _wlan.connect(WIFI_SSID, WIFI_PASSWORD)

    wait_ms = 0
    while not _wlan.isconnected():
        if is_ai_det_stop():
            return
        os.exitpoint()
        utime.sleep_ms(200)
        wait_ms += 200
        if wait_ms % 2000 == 0:
            print("waiting WiFi connect...")

    nic_info = _wlan.ifconfig()
    if nic_info:
        print(f"WiFi IP: {nic_info[0]}")
    else:
        print("⚠️ WiFi 网卡未获取到 IP")

    send_fps = utime.clock()
    send_fps.tick()
    sent_count = 0
    set_stream_connected(False)

    try:
        while True:
            if is_ai_det_stop():
                break

            os.exitpoint()

            if not is_stream_enabled():
                close_socket()
                set_stream_connected(False)
                utime.sleep_ms(100)
                continue

            if _wlan is None or not _wlan.isconnected():
                set_stream_connected(False)
                utime.sleep_ms(500)
                continue

            sock = get_socket()
            if not sock:
                set_stream_connected(False)
                utime.sleep_ms(500)
                continue
            set_stream_connected(True)

            preview_img = queue_get()  # 从AI模型获取图像
            if preview_img:
                try:
                    preview_small = preview_img.scale(x_scale=STREAM_SCALE_X, y_scale=STREAM_SCALE_Y)
                    jpeg_byte = preview_small.compressed(JPEG_QUALITY)
                    if jpeg_byte:
                        send_frame_safe(jpeg_byte)
                finally:
                    try:
                        del preview_small
                    except:
                        pass
                    try:
                        del preview_img
                    except:
                        pass
                sent_count += 1
                send_fps.tick()
                if sent_count % 10 == 0:
                    print(f"[WiFi发送] FPS: {send_fps.fps():.2f}")
            else:
                utime.sleep_ms(10)  # 让出cpu，避免空转占用过高
    finally:
        close_socket()
        set_stream_connected(False)

def thread_EC200():
    """EC200蜂窝推流线程（调network.LAN()注册NIC后直接用socket）"""
    print("[EC200] 注册网络接口...")
    print("[EC200] 提示: 若连不上，先在终端执行 wr /dev/ttyUSB1 AT+QNETDEVCTL=1,1,1")
    # 必须调network.LAN()注册NIC，MicroPython的socket才能找到接口
    try:
        nic = network.LAN()
        utime.sleep_ms(200)
    except Exception as e:
        print(f"[EC200] 注册NIC失败: {e}")

    send_fps = utime.clock()
    send_fps.tick()
    sent_count = 0
    set_stream_connected(False)

    try:
        while True:
            if is_ai_det_stop():
                break
            os.exitpoint()

            if not is_stream_enabled():
                close_socket()
                set_stream_connected(False)
                utime.sleep_ms(100)
                continue

            sock = get_socket()
            if not sock:
                set_stream_connected(False)
                utime.sleep_ms(1000)  # EC200连接慢，等久一点
                continue
            set_stream_connected(True)

            jpeg_byte = queue_get()
            if jpeg_byte:
                try:
                    preview_small = jpeg_byte.scale(x_scale=STREAM_SCALE_X, y_scale=STREAM_SCALE_Y)
                    jpeg = preview_small.compressed(JPEG_QUALITY)
                    if jpeg:
                        send_frame_safe(jpeg)
                finally:
                    try:
                        del preview_small
                    except:
                        pass
                    try:
                        del jpeg_byte
                    except:
                        pass
                sent_count += 1
                send_fps.tick()
                if sent_count % 10 == 0:
                    print(f"[EC200发送] FPS: {send_fps.fps():.2f}")
            else:
                utime.sleep_ms(10)
    finally:
        close_socket()
        set_stream_connected(False)
     


def disp_drv_flush_cb(disp_drv, area, color):
    global disp_img1, disp_img2
    if disp_drv.flush_is_last() == True:
        if disp_img1.virtaddr() == uctypes.addressof(color.__dereference__()):
            Display.show_image(disp_img1, LVGL_X, LVGL_Y, Display.LAYER_OSD2)
            disp_img1.clear()
        else:
            Display.show_image(disp_img2, LVGL_X, LVGL_Y, Display.LAYER_OSD2)
            disp_img2.clear()
        #utime.sleep(0.01)
    disp_drv.flush_ready()

class touch_screen():
    def __init__(self):
        self.state = lv.INDEV_STATE.RELEASED
        self.indev_drv = lv.indev_create()
        self.indev_drv.set_type(lv.INDEV_TYPE.POINTER)
        self.indev_drv.set_read_cb(self.callback)
        self.touch = TOUCH(0)

    def callback(self, driver, data):
        x, y, state = 0, 0, lv.INDEV_STATE.RELEASED
        tp = self.touch.read(1)
        if len(tp):
            raw_x, raw_y = tp[0].x, tp[0].y
            event = tp[0].event
            # 过滤噪声（无效默认值）
            if raw_x < 0 or raw_y < 0:
                return
            # 当前固件下触摸坐标已经是左上角原点，按实测边界做线性映射
            x = int((raw_x - TOUCH_RAW_X_MIN) * (DISPLAY_WIDTH - 1) / (TOUCH_RAW_X_MAX - TOUCH_RAW_X_MIN))
            y = int((raw_y - TOUCH_RAW_Y_MIN) * (DISPLAY_HEIGHT - 1) / (TOUCH_RAW_Y_MAX - TOUCH_RAW_Y_MIN))
            x = max(0, min(DISPLAY_WIDTH - 1, x))
            y = max(0, min(DISPLAY_HEIGHT - 1, y))
            x -= LVGL_X
            y -= LVGL_Y
            if event == 2 or event == 3:
                state = lv.INDEV_STATE.PRESSED
            else:
                state = lv.INDEV_STATE.RELEASED
        data.point = lv.point_t({'x': x, 'y': y})
        data.state = state

def lvgl_init():
    global disp_img1, disp_img2
    lv.init()
    disp_drv = lv.disp_create(LVGL_W, LVGL_H)
    disp_drv.set_flush_cb(disp_drv_flush_cb)
    disp_img1 = image.Image(LVGL_W, align_to_8(LVGL_H), image.BGRA8888)
    disp_img2 = image.Image(LVGL_W, align_to_8(LVGL_H), image.BGRA8888)
    disp_img1.clear()
    disp_img2.clear()
    disp_drv.set_draw_buffers(disp_img1.bytearray(), disp_img2.bytearray(),
                               disp_img1.size(), lv.DISP_RENDER_MODE.FULL)
    disp_drv.set_antialiasing(True)
    
    tp = touch_screen()

def lvgl_deinit():
    global disp_img1, disp_img2
    lv.deinit()
    del disp_img1
    del disp_img2

def btn_clicked_event(event):
    
    btn = lv.btn.__cast__(event.get_target())
    label = lv.label.__cast__(btn.get_user_data())
    if is_running():
        label.set_text("off")
        print("停止ai检测")
        set_running(False)
    else:
        label.set_text("on")
        print("启动ai检测")
        set_running(True)
    
    #lv.task_handler()  # 立即刷新界面状态
#推流开关
def stream_btn_event(event):
    btn = lv.btn.__cast__(event.get_target())
    label = lv.label.__cast__(btn.get_user_data())
    if is_stream_enabled():
        label.set_text("off")
        print("关闭推流")
        set_stream_enabled(False)
    else:
        label.set_text("on")
        print("开启推流")
        set_stream_enabled(True)

def confidence_slider_event(event):
    slider = lv.slider.__cast__(event.get_target())
    value = slider.get_value()
    change_confidence_threshold(value / 100.0)

    label = lv.label.__cast__(slider.get_user_data())
    label.set_text(f"conf {value}%")

def save_btn_event(event):
    request_save_image()
    print("请求保存当前检测图像")

def user_gui_init():
    scr = lv.scr_act()
    scr.set_style_bg_color(lv.color_hex(0x000000), 0)
    scr.set_style_bg_opa(lv.OPA.TRANSP, 0)
    scr.set_style_border_opa(lv.OPA.TRANSP, 0)
    scr.set_style_outline_opa(lv.OPA.TRANSP, 0)
    yellow = lv.color_hex(0xFFD400)
    black = lv.color_hex(0x000000)
    white = lv.color_hex(0xFFFFFF)
    left_x = 12
    right_x = 118
    label_w = 92
    ctrl_w = 150

    title = lv.label(lv.scr_act())
    title.set_pos(12, 8)
    title.set_style_text_color(yellow, 0)
    title.set_text("CONTROL")

    #ai检测开关
    ai_text = lv.label(lv.scr_act())
    ai_text.set_pos(left_x, 40)
    ai_text.set_size(label_w, 24)
    ai_text.set_style_text_color(white, 0)
    ai_text.set_text("AI RUN")

    btn = lv.btn(lv.scr_act())
    btn.set_pos(right_x, 24)
    btn.set_size(ctrl_w, 52)
    btn.set_style_bg_color(yellow, 0)
    btn.set_style_bg_opa(lv.OPA.COVER, 0)
    btn.set_style_border_color(yellow, 0)
    btn.set_style_shadow_opa(lv.OPA.TRANSP, 0)

    label = lv.label(btn)
    label.set_text('on' if is_running() else 'off')
    label.set_style_text_color(black, 0)
    label.center()

    btn.set_user_data(label)
    btn.add_event(btn_clicked_event, lv.EVENT.CLICKED, None)
    #推流开关
    stream_text = lv.label(lv.scr_act())
    stream_text.set_pos(left_x, 112)
    stream_text.set_size(label_w, 24)
    stream_text.set_style_text_color(white, 0)
    stream_text.set_text("STREAM")

    btn_stream = lv.btn(lv.scr_act())
    btn_stream.set_pos(right_x, 96)
    btn_stream.set_size(ctrl_w, 52)
    btn_stream.set_style_bg_color(yellow, 0)
    btn_stream.set_style_bg_opa(lv.OPA.COVER, 0)
    btn_stream.set_style_border_color(yellow, 0)
    btn_stream.set_style_shadow_opa(lv.OPA.TRANSP, 0)

    label_stream = lv.label(btn_stream)
    label_stream.set_text('on' if is_stream_enabled() else 'off')
    label_stream.set_style_text_color(black, 0)
    label_stream.center()

    btn_stream.set_user_data(label_stream)
    btn_stream.add_event(stream_btn_event, lv.EVENT.CLICKED, None)

    conf_label = lv.label(lv.scr_act())
    conf_label.set_pos(left_x, 176)
    conf_label.set_size(label_w, 24)
    conf_label.set_style_text_color(yellow, 0)
    conf_label.set_text(f"conf {int(get_confidence_threshold() * 100)}%")

    conf_text = lv.label(lv.scr_act())
    conf_text.set_pos(left_x, 212)
    conf_text.set_size(label_w, 24)
    conf_text.set_style_text_color(white, 0)
    conf_text.set_text("THRESH")

    conf_slider = lv.slider(lv.scr_act())
    conf_slider.set_pos(right_x, 212)
    conf_slider.set_size(ctrl_w, 28)
    conf_slider.set_range(1, 99)
    conf_slider.set_value(int(get_confidence_threshold() * 100), lv.ANIM.OFF)
    conf_slider.set_user_data(conf_label)
    conf_slider.set_style_bg_color(white, lv.PART.MAIN)
    conf_slider.set_style_bg_opa(lv.OPA.COVER, lv.PART.MAIN)
    conf_slider.set_style_bg_color(yellow, lv.PART.INDICATOR)
    conf_slider.set_style_bg_opa(lv.OPA.COVER, lv.PART.INDICATOR)
    conf_slider.set_style_bg_color(yellow, lv.PART.KNOB)
    conf_slider.set_style_bg_opa(lv.OPA.COVER, lv.PART.KNOB)
    conf_slider.add_event(confidence_slider_event, lv.EVENT.VALUE_CHANGED, None)

    save_text = lv.label(lv.scr_act())
    save_text.set_pos(left_x, 284)
    save_text.set_size(label_w, 24)
    save_text.set_style_text_color(white, 0)
    save_text.set_text("CAPTURE")

    btn_save = lv.btn(lv.scr_act())
    btn_save.set_pos(right_x, 272)
    btn_save.set_size(ctrl_w, 52)
    btn_save.set_style_bg_color(yellow, 0)
    btn_save.set_style_bg_opa(lv.OPA.COVER, 0)
    btn_save.set_style_border_color(yellow, 0)
    btn_save.set_style_shadow_opa(lv.OPA.TRANSP, 0)
    btn_save.add_event(save_btn_event, lv.EVENT.CLICKED, None)

    label_save = lv.label(btn_save)
    label_save.set_text("save")
    label_save.set_style_text_color(black, 0)
    label_save.center()

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    #硬件启动
    media_init()
    # 默认状态：启动即开始AI检测，按钮可手动暂停
    set_running(True)
    set_stream_enabled(False)
    # ai推理+图像发送
    _thread.start_new_thread(thread_AI_detect, ())
    utime.sleep_ms(100)

    # 推流到云服务（根据NETWORK_MODE选择）
    if NETWORK_MODE == "ec200":
        print(f"[网络模式] EC200 ({SERVER_HOST}:{SERVER_PORT})")
        _thread.start_new_thread(thread_EC200, ())
    else:
        print(f"[网络模式] WiFi ({WIFI_SSID}) → TCP ({SERVER_HOST}:{SERVER_PORT})")
        _thread.start_new_thread(thread_WIFI, ())
    

    utime.sleep_ms(100)

    try:
        if ENABLE_LVGL:
            lvgl_init()
            user_gui_init()

            while True:
                lv.task_handler()
                os.exitpoint()
                utime.sleep_ms(5)
        else:
            while True:
                os.exitpoint()
                utime.sleep_ms(50)
    except BaseException as e:
        print(f"程序异常退出: {e}")
        sys.print_exception(e)
        set_ai_det_stop(True)#停止子线程
        utime.sleep_ms(500)  # 等子线程退出
    finally:
        if ENABLE_LVGL:
            lvgl_deinit()
        media_deinit()
        gc.collect()

if __name__ == "__main__":
    main()
