# 使用 https://github.com/kendryte/canmv_k230
通过make k230_canmv_rtt_evb_defconfig编译出的固件烧录到开发板成功启动启动，且能正常运行RW007，但是该仓库不支持UVC HOST,只能换成原来的固件
