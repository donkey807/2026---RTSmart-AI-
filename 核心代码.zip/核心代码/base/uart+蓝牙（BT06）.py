# 开发板通过蓝牙模块向PC发送数据（基于UART2）
from machine import UART
from machine import FPIOA
import time

# 1. 引脚复用（和你原来的一样，不用改）
fpioa = FPIOA()
fpioa.set_function(11, FPIOA.UART2_TXD)  # 开发板TX → 蓝牙RX
fpioa.set_function(12, FPIOA.UART2_RXD)  # 开发板RX → 蓝牙TX

# 2. 初始化UART2（适配蓝牙模块，参数和蓝牙一致）
u2 = UART(UART.UART2, baudrate=9600, bits=UART.EIGHTBITS,
          parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)
u2.init(baudrate=9600, bits=UART.EIGHTBITS,
        parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)
# ✅ 注意：蓝牙模块默认波特率是9600，别用115200（会乱码）

# 3. 循环发送数据（蓝牙持续向PC发，替代原来的单次循环）
try:
    i = 0
    while True:
        # 发送字符串（支持中文，末尾加\r\n让PC串口助手换行）
        send_data = f"你好世界！第{i}次发送\r\n"
        u2.write(send_data)
        print(f"已发送：{send_data}")  # 开发板终端打印日志
        i += 1
        time.sleep(1)  # 每秒发一次，避免数据刷屏
except KeyboardInterrupt:
    print("停止发送")
finally:
    u2.deinit()  # 释放UART资源



from machine import UART

# 配置 UART1: 波特率 115200, 8 位数据位, 无奇偶校验, 1 个停止位
u1 = UART(UART.UART1, baudrate=115200, bits=UART.EIGHTBITS, parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)

# 写入数据到 UART
u1.write("UART1 test")

# 从 UART 读取数据
r = u1.read()

# 读取一行数据
r = u1.readline()

# 将数据读入字节缓冲区
b = bytearray(8)
r = u1.readinto(b)

# 释放 UART 资源
u1.deinit()