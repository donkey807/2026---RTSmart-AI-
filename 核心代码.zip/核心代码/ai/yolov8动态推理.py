# Untitled - By: 刘庆凯 - Wed Dec 24 2025
from media.sensor import *
from media.display import *
from libs.Utils import ScopedTiming
from libs.PipeLine import PipeLine
from libs.AIBase import AIBase
from libs.AI2D import Ai2d
from libs.YOLO import YOLOv8
import os
import ujson
from media.media import *
import nncase_runtime as nn
import ulab.numpy as np
import utime  # 统一使用嵌入式utime，移除标准time
import time
import image
import aidemo
import random
import gc
import sys

# ===================== 核心配置 =====================
DISPLAY_WIDTH = 960  # LCD物理宽度（原生）
DISPLAY_HEIGHT = 540 # LCD物理高度（原生）

# 向下取整对齐8（和Camera示例一致）
def align_to_8(x):
    return (x // 8) * 8
def align_to_16(x):
    return (x // 16) * 16

# Sensor输出尺寸（对齐后）
SENSOR_WIDTH = DISPLAY_WIDTH
#SENSOR_HEIGHT = align_to_8(DISPLAY_HEIGHT)  # 540→536
SENSOR_HEIGHT = 544
# ===================== 1. 基础配置模块 =====================
YOLOV8_CLASSES = [
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat", "traffic light",
    "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow",
    "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
    "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard",
    "tennis racket", "bottle", "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple",
    "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch",
    "potted plant", "bed", "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone",
    "microwave", "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear",
    "hair drier", "toothbrush"
]
COLORS = [[random.randint(0, 255) for _ in range(3)] for _ in YOLOV8_CLASSES]

# ===================== 2. YOLOv8模型类（核心） =====================
class YOLOv8App(AIBase):
    def __init__(self, kmodel_path, model_input_size,
                 confidence_threshold=0.25, nms_threshold=0.45,
                 rgb888p_size=[SENSOR_WIDTH, SENSOR_HEIGHT],
                 display_size=[DISPLAY_WIDTH, DISPLAY_HEIGHT],
                 debug_mode=0):
        super().__init__(kmodel_path, model_input_size, rgb888p_size, debug_mode)

        self.kmodel_path = kmodel_path
        self.model_input_size = model_input_size
        self.confidence_threshold = confidence_threshold
        self.nms_threshold = nms_threshold
        # AI2D输入尺寸（仅宽度对齐16）
        self.rgb888p_size = [align_to_16(rgb888p_size[0]), rgb888p_size[1]]
        self.display_size = display_size

        # AI2D初始化
        self.ai2d = Ai2d(debug_mode)
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT, nn.ai2d_format.NCHW_FMT,
                                 np.uint8, np.uint8)
        self.config_preprocess()

    def config_preprocess(self):
        # 如需计时，替换为utime.ticks_ms()
        # start = utime.ticks_ms()
        pad_param = self.get_yolov8_pad_param()
        self.ai2d.pad(pad_param, 0, [114, 114, 114])
        self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
        self.ai2d.build([1,3,self.rgb888p_size[1],self.rgb888p_size[0]],
                        [1,3,self.model_input_size[1],self.model_input_size[0]])
        # if self.debug_mode > 0:
        #     print(f"YOLOv8 preprocess config time: {utime.ticks_diff(utime.ticks_ms(), start)}ms")

    def get_yolov8_pad_param(self):
        src_w, src_h = self.rgb888p_size
        dst_w, dst_h = self.model_input_size
        ratio = min(dst_w / src_w, dst_h / src_h)
        new_w = int(src_w * ratio)
        new_h = int(src_h * ratio)
        pad_w = dst_w - new_w
        pad_h = dst_h - new_h
        top = pad_h // 2
        bottom = pad_h - top
        left = pad_w // 2
        right = pad_w - left
        return [0,0,0,0, top, bottom, left, right]

    def postprocess(self, results):
        # start = utime.ticks_ms()
        pred = results[0]
        pred = pred[pred[:,4] > self.confidence_threshold]
        if len(pred) == 0:
            return []
        pred[:,5:] *= pred[:,4:5]
        max_scores = np.max(pred[:,5:], axis=1, keepdims=True)
        max_classes = np.argmax(pred[:,5:], axis=1, keepdims=True)
        det_boxes = np.concatenate([pred[:,:4], max_scores, max_classes], axis=1)
        det_boxes = self.nms(det_boxes)
        # if self.debug_mode > 0:
        #     print(f"YOLOv8 postprocess time: {utime.ticks_diff(utime.ticks_ms(), start)}ms")
        return det_boxes

    def nms(self, boxes):
        if len(boxes) == 0:
            return []
        x1, y1, x2, y2, scores, classes = boxes[:,0], boxes[:,1], boxes[:,2], boxes[:,3], boxes[:,4], boxes[:,5]
        areas = (x2 - x1 + 1) * (y2 - y1 + 1)
        order = np.argsort(-scores)
        keep = []
        while len(order) > 0:
            i = order[0]
            keep.append(i)
            xx1 = np.maximum(x1[i], x1[order[1:]])
            yy1 = np.maximum(y1[i], y1[order[1:]])
            xx2 = np.minimum(x2[i], x2[order[1:]])
            yy2 = np.minimum(y2[i], y2[order[1:]])
            w = np.maximum(0.0, xx2 - xx1 + 1)
            h = np.maximum(0.0, yy2 - yy1 + 1)
            inter = w * h
            iou = inter / (areas[i] + areas[order[1:]] - inter)
            inds = np.where(iou <= self.nms_threshold)[0]
            order = order[inds + 1]
        return boxes[keep]

# ===================== 3. 可视化模块 =====================
class YOLOv8Visualizer:
    def __init__(self, display_size, rgb888p_size, class_names=YOLOV8_CLASSES):
        self.display_size = display_size
        self.rgb888p_size = rgb888p_size
        self.class_names = class_names

    def draw_result(self, pl, det_boxes):
        pl.osd_img.clear()
        if len(det_boxes) == 0:
            return
        # 画布尺寸用LCD原生尺寸
        draw_img_np = np.zeros((self.display_size[1], self.display_size[0],4), dtype=np.uint8)
        draw_img = image.Image(self.display_size[0], self.display_size[1],
                               image.ARGB8888, alloc=image.ALLOC_REF, data=draw_img_np)
        # 遍历检测框
        for box in det_boxes:
            x1, y1, x2, y2, score, cls_id = box
            # 坐标映射：sensor对齐尺寸→LCD原生尺寸
            x1 = int(x1 * self.display_size[0] / self.rgb888p_size[0])
            y1 = int(y1 * self.display_size[1] / self.rgb888p_size[1])
            x2 = int(x2 * self.display_size[0] / self.rgb888p_size[0])
            y2 = int(y2 * self.display_size[1] / self.rgb888p_size[1])
            cls_id = int(cls_id)
            # 边界检查
            x1 = max(0, min(x1, self.display_size[0]-1))
            y1 = max(0, min(y1, self.display_size[1]-1))
            x2 = max(x1+1, min(x2, self.display_size[0]-1))
            y2 = max(y1+1, min(y2, self.display_size[1]-1))
            # 绘制
            color = (255, COLORS[cls_id][0], COLORS[cls_id][1], COLORS[cls_id][2])
            draw_img.draw_rectangle(x1, y1, x2, y2, color, 2)
            label = f"{self.class_names[cls_id]} {score:.2f}"
            draw_img.draw_string(x1, y1-10 if y1-10>0 else y1+10, label, color, scale=1)
        pl.osd_img.copy_from(draw_img)

# ===================== 4. 主程序模块（核心修复） =====================
if __name__=="__main__":
    # 1. 部署配置
    display_mode = "lcd"
    rgb888p_size = [SENSOR_WIDTH, SENSOR_HEIGHT]
    display_size = [DISPLAY_WIDTH, DISPLAY_HEIGHT]
    model_input_size = [640, 640]
    yolov8_kmodel_path = "/sdcard/yolov8n_320.kmodel"  # 替换为你的模型路径
    confidence_threshold = 0.5
    nms_threshold = 0.45

    pl = None
    yolov8_app = None
    visualizer = None

    try:
        # 初始化PipeLine（由PipeLine统一管理Sensor+Display）
        pl = PipeLine(rgb888p_size=rgb888p_size,
                      display_size=display_size,
                      display_mode=display_mode)
        pl.create()

        # 初始化模型和可视化
        yolov8_app = YOLOv8App(
            kmodel_path=yolov8_kmodel_path,
            model_input_size=model_input_size,
            confidence_threshold=confidence_threshold,
            nms_threshold=nms_threshold,
            rgb888p_size=rgb888p_size,
            display_size=display_size
        )
        visualizer = YOLOv8Visualizer(display_size=display_size, rgb888p_size=rgb888p_size)

        # 推理循环
        print("开始推理并显示到LCD...")
        while True:
            # 获取摄像头帧数据（PipeLine已管理Sensor）
            img = pl.get_frame()
            # 模型推理
            det_boxes = yolov8_app.run(img)
            # 绘制检测结果
            visualizer.draw_result(pl, det_boxes)
            # 显示到LCD
            pl.show_image()
            # 内存回收
            gc.collect()
            # 可选：添加微小延时，避免循环过快（嵌入式环境建议）
            utime.sleep_ms(1)

    except KeyboardInterrupt:
        print("\n用户终止程序")
    except BaseException as e:
        print(f"程序异常：{e}")
    finally:
        # 资源释放（由PipeLine统一管理）
        if pl:
            pl.destroy()  # PipeLine会自动释放Sensor+Display+MediaManager
        gc.collect()
        print("资源已释放，程序退出")
