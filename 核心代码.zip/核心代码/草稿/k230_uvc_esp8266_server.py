# K230 + ESP8266 + UVC摄像头 实时图像传输服务器
# 手机连接ESP8266热点后，浏览器访问查看实时图像

from machine import UART, FPIOA
from media.display import *
from media.media import *
from media.uvc import *
import time
import gc

# 禁用垃圾回收，避免内存问题导致软重启
gc.disable()

# ===================== 配置参数 =====================
WIFI_SSID = "K230-Camera"      # ESP8266热点名称
WIFI_PASS = "12345678"         # ESP8266热点密码
SERVER_PORT = 8080             # HTTP服务器端口
UART_BAUDRATE = 115200         # ESP8266通信波特率

# ===================== 硬件初始化 =====================
print("=" * 50)
print("K230 UVC摄像头 + ESP8266 图像传输服务器")
print("=" * 50)

# 配置FPIOA
fpioa = FPIOA()
fpioa.set_function(11, FPIOA.UART2_TXD)  # GPIO11 -> ESP8266 RX
fpioa.set_function(12, FPIOA.UART2_RXD)  # GPIO12 -> ESP8266 TX

# 初始化UART2连接ESP8266
uart = UART(UART.UART2, baudrate=UART_BAUDRATE, 
            bits=UART.EIGHTBITS, parity=UART.PARITY_NONE, 
            stop=UART.STOPBITS_ONE)

print(f"✅ UART2初始化完成，波特率: {UART_BAUDRATE}")

# ===================== ESP8266 AT指令函数 =====================
def send_at_cmd(cmd, timeout=2):
    """
    发送AT指令到ESP8266
    :param cmd: AT指令字符串（不含\r\n）
    :param timeout: 超时时间（秒）
    :return: 响应字符串
    """
    # 清空接收缓冲区
    if uart.any():
        uart.read(uart.any())
        time.sleep_ms(50)
    
    # 发送指令
    uart.write((cmd + "\r\n").encode('utf-8'))
    time.sleep_ms(100)
    
    # 读取响应
    resp = ""
    start_time = time.time()
    while (time.time() - start_time) < timeout:
        if uart.any():
            raw_data = uart.read(uart.any())
            # 过滤可打印ASCII字符
            resp += ''.join([chr(b) for b in raw_data if 0x20 <= b <= 0x7E])
            time.sleep_ms(50)
    
    return resp

def esp8266_init_ap_mode():
    """
    初始化ESP8266为AP模式（热点）
    """
    print("\n📡 正在初始化ESP8266...")
    
    # 测试AT指令
    print("1. 测试AT指令通信...")
    resp = send_at_cmd("AT", timeout=1)
    if "OK" not in resp:
        print("❌ ESP8266通信失败，请检查接线！")
        print(f"   响应: {resp}")
        return False
    print("   ✅ AT指令正常")
    
    # 重启模块
    print("2. 重启ESP8266...")
    send_at_cmd("AT+RST")
    time.sleep(3)  # 等待重启完成
    
    # 关闭回显
    print("3. 关闭命令回显...")
    send_at_cmd("ATE0")
    time.sleep_ms(500)
    
    # 设置AP模式
    print("4. 设置AP模式...")
    resp = send_at_cmd("AT+CWMODE=2")
    if "OK" not in resp:
        print(f"❌ 设置AP模式失败: {resp}")
        return False
    time.sleep(1)
    
    # 配置热点
    print(f"5. 配置WiFi热点: {WIFI_SSID}...")
    cmd = f'AT+CWSAP="{WIFI_SSID}","{WIFI_PASS}",11,3'
    resp = send_at_cmd(cmd, timeout=5)
    if "OK" not in resp:
        print(f"❌ 配置热点失败: {resp}")
        return False
    print(f"   ✅ 热点配置成功")
    
    # 启用多连接模式
    print("6. 启用多连接模式...")
    send_at_cmd("AT+CIPMUX=1")
    time.sleep_ms(500)
    
    # 启动TCP服务器
    print(f"7. 启动TCP服务器，端口: {SERVER_PORT}...")
    resp = send_at_cmd(f"AT+CIPSERVER=1,{SERVER_PORT}")
    if "OK" not in resp and "no change" not in resp:
        print(f"❌ 启动TCP服务器失败: {resp}")
        return False
    
    # 查询IP地址
    print("8. 查询IP地址...")
    resp = send_at_cmd("AT+CIFSR")
    
    print("\n" + "=" * 50)
    print("✅ ESP8266初始化完成！")
    print(f"📶 WiFi名称: {WIFI_SSID}")
    print(f"🔑 WiFi密码: {WIFI_PASS}")
    print(f"🌐 服务器地址: http://192.168.4.1:{SERVER_PORT}")
    print("=" * 50)
    print("\n📱 请用手机连接WiFi，然后浏览器访问上述地址")
    print("⚠️  注意：手机连接此WiFi后无法上网，属于正常现象")
    print("=" * 50 + "\n")
    
    return True

def send_tcp_data(conn_id, data):
    """
    通过TCP发送数据到客户端
    :param conn_id: 连接ID
    :param data: 要发送的字节数据
    :return: 是否成功
    """
    # 发送CIPSEND指令
    cmd = f"AT+CIPSEND={conn_id},{len(data)}"
    resp = send_at_cmd(cmd, timeout=1)
    
    if ">" not in resp:
        return False
    
    # 发送实际数据
    uart.write(data)
    time.sleep_ms(50)
    return True

def close_connection(conn_id):
    """关闭指定连接"""
    send_at_cmd(f"AT+CIPCLOSE={conn_id}", timeout=1)

# ===================== HTTP响应构建 =====================
def build_http_response(jpeg_data, is_stream=False):
    """
    构建HTTP响应（单张图片或MJPEG流）
    """
    if is_stream:
        # MJPEG流模式
        headers = f"""HTTP/1.1 200 OK\r
Content-Type: multipart/x-mixed-replace; boundary=frame\r
Cache-Control: no-cache\r
Connection: keep-alive\r
\r
"""
    else:
        # 单张图片模式
        headers = f"""HTTP/1.1 200 OK\r
Content-Type: image/jpeg\r
Content-Length: {len(jpeg_data)}\r
Cache-Control: no-cache\r
Connection: close\r
\r
"""
    return headers.encode('utf-8') + jpeg_data

def build_mjpeg_frame(jpeg_data):
    """构建MJPEG流中的一帧"""
    frame = f"--frame\r\n".encode('utf-8')
    frame += f"Content-Type: image/jpeg\r\n".encode('utf-8')
    frame += f"Content-Length: {len(jpeg_data)}\r\n\r\n".encode('utf-8')
    frame += jpeg_data
    frame += b"\r\n"
    return frame

def build_mjpeg_stream_header():
    """构建MJPEG流响应头"""
    return b"""HTTP/1.1 200 OK\r
Content-Type: multipart/x-mixed-replace; boundary=frame\r
\r
"""

def build_mjpeg_frame(jpeg_data):
    """构建MJPEG流中的一帧"""
    header = f"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: {len(jpeg_data)}\r\n\r\n"
    return header.encode('utf-8') + jpeg_data + b"\r\n"

# ===================== UVC摄像头初始化 =====================
def init_uvc_camera():
    """初始化UVC摄像头"""
    print("\n📷 正在初始化UVC摄像头...")
    
    # 初始化显示（虚拟显示，用于IDE预览）
    Display.init(Display.VIRT, width=320, height=240, to_ide=True)
    MediaManager.init()
    
    # 等待摄像头连接
    print("等待摄像头插入...")
    while True:
        plugin, dev_info = UVC.probe()
        if plugin:
            print(f"✅ 检测到摄像头: {dev_info}")
            break
        time.sleep_ms(500)
    
    # 获取并选择视频模式
    mode = UVC.video_mode()
    succ, mode = UVC.select_video_mode(mode)
    print(f"✅ 视频模式: {mode}")
    
    # 启动摄像头（cvt=False保持原始YUV422格式）
    UVC.start(cvt=False)
    print("✅ 摄像头启动成功\n")
    
    return True

# ===================== 主程序 =====================
def main():
    # 初始化摄像头
    if not init_uvc_camera():
        print("❌ 摄像头初始化失败")
        return
    
    # 初始化ESP8266
    if not esp8266_init_ap_mode():
        print("❌ ESP8266初始化失败")
        return
    
    print("🚀 开始主循环，等待客户端连接...\n")
    
    frame_count = 0
    last_fps_time = time.time()
    
    while True:
        try:
            # 检查是否有客户端数据（HTTP请求）
            if uart.any():
                raw_data = uart.read(uart.any())
                data_str = ''.join([chr(b) for b in raw_data if 0x20 <= b <= 0x7E])
                
                # 解析+IPD数据（客户端连接）
                # 格式: +IPD,<conn_id>,<len>:<data>
                if "+IPD," in data_str:
                    try:
                        # 提取连接ID - 格式是 +IPD,0,1234:GET ...
                        import re
                        match = re.search(r'\+IPD,(\d+),(\d+):', data_str)
                        if match:
                            conn_id = match.group(1)
                            data_len = int(match.group(2))
                        else:
                            # 备选解析
                            parts = data_str.split(",")
                            if len(parts) >= 2:
                                conn_id = parts[1].strip()
                                # 确保conn_id是纯数字
                                if not conn_id.isdigit():
                                    conn_id = "0"
                            else:
                                conn_id = "0"
                        
                        # 提取HTTP请求内容（在冒号后面）
                        request_content = ""
                        colon_pos = data_str.find(":")
                        if colon_pos != -1:
                            request_content = data_str[colon_pos+1:]
                        
                        print(f"📥 收到HTTP请求，连接ID: {conn_id}")
                        print(f"   请求: {request_content[:80]}...")
                        
                        # 处理系统网络检测请求（安卓/苹果）
                        if "generate_204" in request_content or "connectivitycheck" in request_content or "captive" in request_content:
                            print("   🔄 响应系统网络检测")
                            response = b"HTTP/1.1 204 No Content\r\nContent-Length: 0\r\n\r\n"
                            send_tcp_data(conn_id, response)
                            close_connection(conn_id)
                            continue
                        
                        # 处理 favicon 请求
                        if "favicon.ico" in request_content:
                            response = b"HTTP/1.1 404 Not Found\r\n\r\n"
                            send_tcp_data(conn_id, response)
                            close_connection(conn_id)
                            continue
                        
                        # 检查是否是请求视频流（URL包含 ?stream 或路径为 /stream）
                        is_stream = "stream" in request_content.lower() or "mjpeg" in request_content.lower()
                        
                        if is_stream:
                            print("   🎥 启动MJPEG视频流模式")
                            
                            # 发送MJPEG流头 - 使用正确的boundary格式
                            header = b"HTTP/1.1 200 OK\r\n"
                            header += b"Content-Type: multipart/x-mixed-replace; boundary=frame\r\n"
                            header += b"Cache-Control: no-cache, no-store, must-revalidate\r\n"
                            header += b"Pragma: no-cache\r\n"
                            header += b"Expires: 0\r\n"
                            header += b"Connection: keep-alive\r\n"
                            header += b"\r\n"
                            
                            if not send_tcp_data(conn_id, header):
                                print("   ❌ 发送流头失败")
                                close_connection(conn_id)
                                continue
                            
                            print("   ✅ 流头已发送，开始传输视频帧...")
                            
                            # 连续发送视频帧
                            stream_count = 0
                            no_frame_count = 0
                            
                            while stream_count < 500 and no_frame_count < 50:  # 最多500帧或连续50次无帧
                                # 捕获图像
                                img = UVC.snapshot()
                                if img is None:
                                    no_frame_count += 1
                                    time.sleep_ms(20)
                                    continue
                                
                                no_frame_count = 0
                                
                                # 保存为JPEG
                                try:
                                    img.save("/tmp/stream.jpg")
                                    with open("/tmp/stream.jpg", "rb") as f:
                                        jpeg_data = f.read()
                                except Exception as e:
                                    print(f"   ⚠️  图像保存失败: {e}")
                                    time.sleep_ms(50)
                                    continue
                                
                                # 构建MJPEG帧 - 严格按照multipart格式
                                frame = b"--frame\r\n"
                                frame += b"Content-Type: image/jpeg\r\n"
                                frame += f"Content-Length: {len(jpeg_data)}\r\n".encode('utf-8')
                                frame += b"\r\n"
                                frame += jpeg_data
                                frame += b"\r\n"
                                
                                # 发送帧
                                if not send_tcp_data(conn_id, frame):
                                    print("   ⏹️  客户端断开连接")
                                    break
                                
                                stream_count += 1
                                if stream_count % 30 == 0:
                                    print(f"   📊 已发送 {stream_count} 帧")
                                
                                # 控制帧率约5fps（ESP8266传输能力有限）
                                time.sleep_ms(200)
                            
                            print(f"   ✅ 视频流结束，共发送 {stream_count} 帧")
                            close_connection(conn_id)
                            continue
                        
                        # 单张图片模式
                        print("   📷 单张图片模式")
                        
                        # 捕获一帧图像
                        img = UVC.snapshot()
                        if img is None:
                            print("⚠️  图像捕获失败")
                            close_connection(conn_id)
                            continue
                        
                        # 保存为JPEG
                        img.save("/tmp/capture.jpg")
                        
                        # 读取JPEG数据
                        with open("/tmp/capture.jpg", "rb") as f:
                            jpeg_data = f.read()
                        
                        # 构建并发送HTTP响应
                        response = build_http_response(jpeg_data)
                        
                        # 分块发送（避免ESP8266缓冲区溢出）
                        chunk_size = 1024
                        send_success = True
                        for i in range(0, len(response), chunk_size):
                            chunk = response[i:i+chunk_size]
                            if not send_tcp_data(conn_id, chunk):
                                print("❌ 发送数据失败")
                                send_success = False
                                break
                            time.sleep_ms(10)
                        
                        if send_success:
                            frame_count += 1
                            current_time = time.time()
                            if current_time - last_fps_time >= 5:
                                fps = frame_count / (current_time - last_fps_time)
                                print(f"📊 最近5秒平均帧率: {fps:.1f} fps")
                                frame_count = 0
                                last_fps_time = current_time
                            else:
                                print(f"✅ 发送图像: {len(jpeg_data)} bytes")
                        
                        # 关闭连接
                        close_connection(conn_id)
                        
                    except Exception as e:
                        print(f"❌ 处理请求出错: {e}")
                        try:
                            close_connection(conn_id)
                        except:
                            pass
            
            time.sleep_ms(50)
            
        except Exception as e:
            print(f"❌ 主循环错误: {e}")
            time.sleep_ms(100)

if __name__ == "__main__":
    main()
