from libs.PipeLine import PipeLine, ScopedTiming
from libs.AIBase import AIBase
from libs.AI2D import Ai2d
import os
import ujson
from media.media import *
from media.display import *
from time import *
import nncase_runtime as nn
import ulab.numpy as np
import time
import utime
import image
import random
import gc
import sys
import aidemo
# ===================== 2. 核心外设配置（仅保留需要的，整洁清晰） =====================
DISPLAY_WIDTH = 960  # LCD物理宽度（原生）
DISPLAY_HEIGHT = 540 # LCD物理高度（原生）

# 对齐函数（按需保留，适配Camera要求）
def align_to_8(x):
    return (x // 8) * 8
def align_to_16(x):
    return (x // 16) * 16

# Sensor输出尺寸（对齐后，替换原1280x720）
SENSOR_WIDTH = DISPLAY_WIDTH
SENSOR_HEIGHT = 536

# 自定义人脸检测类，继承自AIBase基类
class FaceDetectionApp(AIBase):
    def __init__(self, kmodel_path, anchors, model_input_size=[640,640], confidence_threshold=0.5, nms_threshold=0.2, rgb888p_size=[224,224], display_size=[1920,1080], debug_mode=0):
        super().__init__(kmodel_path, model_input_size, rgb888p_size, debug_mode)  # 调用基类的构造函数
        self.kmodel_path = kmodel_path  # 模型文件路径
        self.model_input_size = model_input_size  # 模型输入分辨率
        self.confidence_threshold = confidence_threshold  # 置信度阈值
        self.nms_threshold = nms_threshold  # NMS（非极大值抑制）阈值
        self.anchors = anchors  # 锚点数据，用于目标检测
        self.rgb888p_size = [align_to_16(rgb888p_size[0]), rgb888p_size[1]]  # sensor给到AI的图像分辨率，并对宽度进行16的对齐
        self.display_size = [align_to_16(display_size[0]), display_size[1]]  # 显示分辨率，并对宽度进行16的对齐
        self.debug_mode = debug_mode  # 是否开启调试模式
        self.ai2d = Ai2d(debug_mode)  # 实例化Ai2d，用于实现模型预处理
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT, nn.ai2d_format.NCHW_FMT, np.uint8, np.uint8)  # 设置Ai2d的输入输出格式和类型
        # ========== 新增打印：初始化时的尺寸信息 ==========
        #print(f"【初始化】rgb888p_size: {self.rgb888p_size}, 宽度16对齐后是否8对齐？{self.rgb888p_size[0]%8==0}")
        #print(f"【初始化】display_size: {self.display_size}, 宽度16对齐后是否8对齐？{self.display_size[0]%8==0}")

    # 配置预处理操作，这里使用了pad和resize，Ai2d支持crop/shift/pad/resize/affine，具体代码请打开/sdcard/app/libs/AI2D.py查看
    def config_preprocess(self, input_image_size=None):
        with ScopedTiming("set preprocess config", self.debug_mode > 0):  # 计时器，如果debug_mode大于0则开启
            ai2d_input_size = input_image_size if input_image_size else self.rgb888p_size  # 初始化ai2d预处理配置，默认为sensor给到AI的尺寸，可以通过设置input_image_size自行修改输入尺寸
            # ========== 新增打印：AI2D输入尺寸 ==========
            #print(f"【AI2D】输入尺寸: {ai2d_input_size}, 宽度是否8对齐？{ai2d_input_size[0]%8==0}")
            top, bottom, left, right = self.get_padding_param()  # 获取padding参数
            self.ai2d.pad([0, 0, 0, 0, top, bottom, left, right], 0, [104, 117, 123])  # 填充边缘
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)  # 缩放图像
            self.ai2d.build([1,3,ai2d_input_size[1],ai2d_input_size[0]],[1,3,self.model_input_size[1],self.model_input_size[0]])  # 构建预处理流程

    # 自定义当前任务的后处理，results是模型输出array列表，这里使用了aidemo库的face_det_post_process接口
    def postprocess(self, results):
        with ScopedTiming("postprocess", self.debug_mode > 0):
            post_ret = aidemo.face_det_post_process(self.confidence_threshold, self.nms_threshold, self.model_input_size[1], self.anchors, self.rgb888p_size, results)
            if len(post_ret) == 0:
                return post_ret
            else:
                return post_ret[0]

    # 绘制检测结果到画面上
    def draw_result(self, pl, dets):
        with ScopedTiming("display_draw", self.debug_mode > 0):
            if dets:
                pl.osd_img.clear()  # 清除OSD图像
                # ========== 新增打印：PipeLine内部实际尺寸 ==========
                #print(f"【PipeLine】内部rgb888p_size: {pl.rgb888p_size}, 宽度是否8对齐？{pl.rgb888p_size[0]%8==0}")
                #print(f"【PipeLine】内部display_size: {pl.display_size}, 宽度是否8对齐？{pl.display_size[0]%8==0}")

                for i, det in enumerate(dets):
                    # 将检测框的坐标转换为显示分辨率下的坐标
                    x, y, w, h = map(lambda x: int(round(x, 0)), det[:4])
                    x_origin = x  # 原始值
                    y_origin = y
                    w_origin = w
                    h_origin = h

                    x = x * self.display_size[0] // self.rgb888p_size[0]
                    y = y * self.display_size[1] // self.rgb888p_size[1]
                    w = w * self.display_size[0] // self.rgb888p_size[0]
                    h = h * self.display_size[1] // self.rgb888p_size[1]



                    # ========== 新增打印：检测框坐标信息 ==========
                    #print(f"【检测框{i}】原始坐标: x={x_origin}, y={y_origin}, w={w_origin}, h={h_origin}")
                    #print(f"【检测框{i}】缩放后坐标: x={x}, y={y}, w={w}, h={h}")
                    #print(f"【检测框{i}】缩放后宽度w是否8对齐？{w%8==0}, x是否8对齐？{x%8==0}")

                    pl.osd_img.draw_rectangle(x, y, w, h, color=(255, 255, 0, 255), thickness=2)  # 绘制矩形框
            else:
                pl.osd_img.clear()
                # ========== 无检测框时也打印PipeLine尺寸 ==========
                #print(f"【无检测框】PipeLine内部display_size: {pl.display_size}, 宽度是否8对齐？{pl.display_size[0]%8==0}")

    # 获取padding参数
    def get_padding_param(self):
        dst_w = self.model_input_size[0]  # 模型输入宽度
        dst_h = self.model_input_size[1]  # 模型输入高度
        ratio_w = dst_w / self.rgb888p_size[0]  # 宽度缩放比例
        ratio_h = dst_h / self.rgb888p_size[1]  # 高度缩放比例
        ratio = min(ratio_w, ratio_h)  # 取较小的缩放比例
        new_w = int(ratio * self.rgb888p_size[0])  # 新宽度
        new_h = int(ratio * self.rgb888p_size[1])  # 新高度
        # ========== 新增打印：Padding参数 ==========
        #print(f"【Padding】模型输入尺寸: {self.model_input_size}, 缩放后宽度new_w={new_w}, 是否8对齐？{new_w%8==0}")
        dw = (dst_w - new_w) / 2  # 宽度差
        dh = (dst_h - new_h) / 2  # 高度差
        top = int(round(0))
        bottom = int(round(dh * 2 + 0.1))
        left = int(round(0))
        right = int(round(dw * 2 - 0.1))
        return top, bottom, left, right

if __name__ == "__main__":
    # 显示模式，默认"hdmi",可以选择"hdmi"和"lcd"
    display_mode="NT35516"
    # k230保持不变，k230d可调整为[640,360]
    #osd层内容，保证和sensor层一致
    rgb888p_size = [320, 320]
    #rgb888p_size = [640,480]
    display_size = [960, 540]


    # ========== 新增打印：主程序初始尺寸 ==========
    #print(f"【主程序】初始rgb888p_size: {rgb888p_size}, 宽度是否8对齐？{rgb888p_size[0]%8==0}")
    #print(f"【主程序】初始display_size: {display_size}, 宽度是否8对齐？{display_size[0]%8==0}")

    # 设置模型路径和其他参数
    kmodel_path = "/sdcard/examples/kmodel/face_detection_320.kmodel"
    # 其它参数
    confidence_threshold = 0.5
    nms_threshold = 0.2
    anchor_len = 4200
    det_dim = 4
    anchors_path = "/sdcard/examples/utils/prior_data_320.bin"
    anchors = np.fromfile(anchors_path, dtype=np.float)
    anchors = anchors.reshape((anchor_len, det_dim))

    # 初始化PipeLine实例，传入对齐后的尺寸参数
    pl = PipeLine(rgb888p_size=rgb888p_size, display_size=display_size, display_mode=display_mode,osd_layer_num=3)
    pl.create()  # 创建PipeLine实例
    #pl.display_size = [536, 960]
    # ========== 新增打印：PipeLine初始化后尺寸 ==========
    #print(f"【PipeLine初始化后】rgb888p_size: {pl.rgb888p_size}, 宽度是否8对齐？{pl.rgb888p_size[0]%8==0}")
    #print(f"【PipeLine初始化后】display_size: {pl.display_size}, 宽度是否8对齐？{pl.display_size[0]%8==0}")

    # 初始化自定义人脸检测实例
    face_det = FaceDetectionApp(kmodel_path, model_input_size=[320, 320], anchors=anchors, confidence_threshold=confidence_threshold, nms_threshold=nms_threshold, rgb888p_size=rgb888p_size, display_size=display_size, debug_mode=0)
    face_det.config_preprocess()  # 配置预处理

    try:
        while True:
            os.exitpoint()                      # 检查是否有退出信号
            with ScopedTiming("total",1):
                img = pl.get_frame()            # 获取当前帧数据
                # ========== 新增打印：获取帧后的尺寸 ==========
                #print(f"【获取帧】img尺寸: {img.shape if hasattr(img, 'shape') else '未知'}, 宽度是否8对齐？{img.shape[2]%8==0 if hasattr(img, 'shape') else '未知'}")

                res = face_det.run(img)         # 推理当前帧
                face_det.draw_result(pl, res)   # 绘制结果

                # ========== 新增打印：显示前最终尺寸 ==========
                #print(f"【显示前】最终传给show_image的display宽度: {pl.display_size[0]}, 是否8对齐？{pl.display_size[0]%8==0}")
                pl.show_image()                 # 显示结果
                gc.collect()                    # 垃圾回收
    except Exception as e:
        sys.print_exception(e)                  # 打印异常信息
    finally:
        face_det.deinit()                       # 反初始化
        pl.destroy()                            # 销毁PipeLine实例
