from machine import TOUCH
import time

# 实例化触摸
tp = TOUCH(0)

# 防抖标记：记录上一次是否已经处理过触摸
last_touched = False

while True:
    p = tp.read()  # 读取触摸数据

    # ==================== 核心：防抖 + 只处理“按下瞬间”
    if p != ():
        if not last_touched:  # 只有第一次按下时打印
            touch_info = p[0]
            print('='*30)
            print(f"触摸坐标 X: {touch_info.x}  Y: {touch_info.y}")
            print(f"原始数据: {p}")
            last_touched = True  # 标记已处理

        # 退出事件
        if touch_info.event == 255:
            print("\n退出程序")
            tp.deinit()
            break

    else:
        last_touched = False  # 松开后重置标记

    time.sleep_ms(20)  # 延时改短，才灵敏不重复
