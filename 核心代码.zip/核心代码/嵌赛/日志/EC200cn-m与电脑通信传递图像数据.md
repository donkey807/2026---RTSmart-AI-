一，EMQX免费公网MQTT（发送短消息）
    1，将EC200模块连接电脑，打开对应串口，依次输入一下AT指令
    AT+QICLOSE=0
    AT+QMTCFG="version",0,4
    AT+QMTOPEN=0,"broker.emqx.io",1883
    AT+QMTCONN=0,"k230_ec200_001","",""

    2，浏览器进入broker.emqx.io，点击连接，新建订阅，按照以下方式创建设备![alt text](image.png)

    3，在模块串口输入命令：AT+QMTPUB=0,0,0,0,"device/k230/ai","fish_num:3"

    可以在浏览器看到该指令![alt text](image-6.png)，但是显然帧率太低，觉得还是先看看能否用更高帧率的方法
二，实时传递图像连接(EC200M-CN 永远作为 TCP客户端主动发起连接，而不是被动等待被连接,且电脑也是这样，因此需要使用云服务器)
    ![alt text](image-7.png)
    现在的问题有点多，由于我使用的EC200cn-m模块，插的移动sim卡，只能访问移动内网ip（192.168.43.100）无法改ip，且该模块不能开设热点与连接外部wifi，所以计划使用隧道打通ip不在同一网段无法访问问题。
    1，使用Ngrok TCP隧道失败（没有储蓄卡，无法通过验证）
    2，使用ssh.localhost.run，一连接就被服务器主动断开
    3，Cloudflare Tunnel失败，其免费隧道只支持HTTPS协议，k230是裸TCP Socket和RTSP

三，使用阿里云学生优惠云服务器+搭建Flask
电脑使用校园网，EC200使用移动SIM都属于内网，只能主动连接，不能被动接收，因此使用云服务器，EC200主动上传图片数据，电脑主动查看数据
在与服务器启用Flask，添加入方向规则
![alt text](image-8.png)
运行Sensor+ec200.py 
注：
    如果电脑curl http://8.156.80.207:8080/upload -X POST -d "test"返回ok,且服务器正常运行，可能是EC200的wr /dev/ttyUSB1 AT+QNETDEVCTL=1,1,1
需要重新执行一下

四，通过文件读取的方式进行上传，已经可以在浏览器上实时显示画面，但是由于ec200属于内网，api文档中rtsp只支持服务器，不支持客户端，不能用ec200进行被动接收。
使用img.impressed函数处理图像转为bytes格式直接上传，避免文件io，且http改成裸tcp，连接方式改成长连接，在减小图像质量和分辨率下，能跑到30帧（ai检测用原图，帮助ai检测精度）