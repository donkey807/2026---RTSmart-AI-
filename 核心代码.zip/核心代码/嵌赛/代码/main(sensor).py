'''
主线程（main.py）
├── 初始化所有硬件（Display、Sensor、LVGL、蓝牙、EC200）
├── 启动子线程
└── 主循环：LVGL task_handler（必须在主线程跑） + 蓝牙轮询

子线程1：AI推理线程
├── 从 Sensor 取帧
├── 运行模型推理
├── 绘制OSD结果
└── 受全局状态控制（运行/暂停）

子线程2：EC200推流线程
├── 从队列取帧
└── HTTP/TCP上传到云服务器



'''
#ai检测
from libs.PipeLine import PipeLine, ScopedTiming  
from libs.AI2D import Ai2d  
from libs.AIBase import AIBase
import nncase_runtime as nn
import ulab.numpy as np  
import aidemo  
#硬件驱动
from media.display import *  # 显示模块
from media.media import *  # 媒体管理模块
from media.sensor import *  # 摄像头传感器模块
#固件系统
import utime, os, sys, gc  # 时间、系统、垃圾回收模块
import _thread  # 多线程支持
#蓝牙
from machine import UART, FPIOA
#云服务器（EC200）
import network,socket
#lvgl控件
import lvgl as lv
from machine import TOUCH

#传感器
SENSOR_WIDTH = 960
SENSOR_HEIGHT = 536
#屏幕
DISPLAY_WIDTH = 960
DISPLAY_HEIGHT = 536
# LVGL 小窗口，放右下角
LVGL_W = 80
LVGL_H = 40
LVGL_X = DISPLAY_WIDTH - LVGL_W    
LVGL_Y = DISPLAY_HEIGHT - LVGL_H   

rgb888p_size = [320, 320]       # AI输入分辨率（RGB888格式）
display_size = [960, 540]       # 显示分辨率
#蓝牙串口
BT_UART = UART.UART2
BT_TX_PIN = 11          # FPIOA引脚号
BT_RX_PIN = 12
BT_BAUDRATE = 9600
# 图像传输质量
JPEG_QUALITY = 50
# 发送队列长度
QUEUE_SIZE = 2
#服务端口
SERVER_HOST    = "8.156.80.207"
SERVER_PORT    = 8080  # 裸TCP端口，和Flask 8080分开

sensor = None           # 摄像头传感器对象
ai_det_stop = False   # YOLO检测线程停止标志
sock = None           # TCP socket

lock = _thread.allocate_lock()

running = False#通过lvgl控件或者蓝牙控制这个参数，以控制ai检测
def align_to_8(x): return (x // 8) * 8
def align_to_16(x): return (x // 16) * 16

# ========================
# 帧队列（AI线程 -> 推流线程）
# ========================
_queue_lock = _thread.allocate_lock()
_frame_queue = []

def queue_put(jpeg_bytes):
    global _frame_queue
    with _queue_lock:
        if len(_frame_queue) >= QUEUE_SIZE:
            _frame_queue.pop(0)
        _frame_queue.append(jpeg_bytes)

def queue_get():
    with _queue_lock:
        if _frame_queue:
            return _frame_queue.pop(0)
    return None

class ObjectDetectionApp(AIBase):
    """YOLOv8目标检测应用类（继承自AIBase）"""

    def __init__(self, kmodel_path, labels, model_input_size, max_boxes_num,
                 confidence_threshold=0.5, nms_threshold=0.2,
                 rgb888p_size=[224,224], display_size=[1920,1080], debug_mode=0):
        """
        初始化YOLO检测器
        Args:
            kmodel_path: kmodel模型文件路径
            labels: 类别标签列表
            model_input_size: 模型输入尺寸 [w, h]
            max_boxes_num: 最大检测框数量
            confidence_threshold: 置信度阈值
            nms_threshold: NMS阈值
            rgb888p_size: Sensor给AI的图像分辨率
            display_size: 显示分辨率
            debug_mode: 调试模式（0=关闭，>0=开启）
        """
        super().__init__(kmodel_path, model_input_size, rgb888p_size, debug_mode)
        self.kmodel_path = kmodel_path
        self.labels = labels
        self.model_input_size = model_input_size
        self.confidence_threshold = confidence_threshold
        self.nms_threshold = nms_threshold
        self.max_boxes_num = max_boxes_num

        # 分辨率对齐（满足硬件要求）
        self.rgb888p_size = [align_to_16(rgb888p_size[0]), rgb888p_size[1]]
        self.display_size = [align_to_16(display_size[0]), align_to_8(display_size[1])]
        self.debug_mode = debug_mode

        # 坐标缩放因子（模型坐标 -> Sensor坐标）
        self.x_factor = float(self.rgb888p_size[0]) / self.model_input_size[0]
        self.y_factor = float(self.rgb888p_size[1]) / self.model_input_size[1]

        # AI2D预处理对象（用于图像缩放、填充等）
        self.ai2d = Ai2d(debug_mode)
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT, nn.ai2d_format.NCHW_FMT,
                                  np.uint8, np.uint8)

    def config_preprocess(self, input_image_size=None):
        """配置图像预处理流程（缩放+填充）"""
        with ScopedTiming("set preprocess config", self.debug_mode > 0):
            ai2d_input_size = input_image_size if input_image_size else self.rgb888p_size
            # 计算填充参数
            top, bottom, left, right = self.get_padding_param()
            # 添加填充（灰色背景）
            self.ai2d.pad([0,0,0,0,top,bottom,left,right], 0, [128,128,128])
            # 双线性插值缩放
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
            # 构建预处理流程
            self.ai2d.build([1,3,ai2d_input_size[1],ai2d_input_size[0]],
                           [1,3,self.model_input_size[1],self.model_input_size[0]])

    def get_padding_param(self):
        """计算填充参数（保持宽高比的Letterbox填充）"""
        dst_w = self.model_input_size[0]   # 目标宽度
        dst_h = self.model_input_size[1]   # 目标高度
        ratio_w = dst_w / self.rgb888p_size[0]  # 宽度缩放比
        ratio_h = dst_h / self.rgb888p_size[1]  # 高度缩放比
        ratio = min(ratio_w, ratio_h)      # 取较小比例（保持完整图像）

        new_w = int(ratio * self.rgb888p_size[0])  # 缩放后宽度
        new_h = int(ratio * self.rgb888p_size[1])  # 缩放后高度

        # 计算需要填充的像素数
        dw = (dst_w - new_w) / 2
        dh = (dst_h - new_h) / 2
        top = int(round(0))
        bottom = int(round(dh * 2 + 0.1))
        left = int(round(0))
        right = int(round(dw * 2 - 0.1))
        return top, bottom, left, right

    def postprocess(self, results):
        with ScopedTiming("postprocess", self.debug_mode > 0):
            # 人头检测模型输出 [1,6,8400]，6=4坐标+1置信度+1类别
            output = results[0][0]  # shape [6, 8400]
            det_res = aidemo.yolov8_det_postprocess(
                output.transpose().copy(),
                [self.rgb888p_size[1], self.rgb888p_size[0]],
                [self.model_input_size[1], self.model_input_size[0]],
                [self.display_size[1], self.display_size[0]],
                len(self.labels), self.confidence_threshold,
                self.nms_threshold, self.max_boxes_num
            )
            return det_res

    def draw_result(self, osd_img, dets):
        """在OSD图层上绘制检测结果（边界框+标签）"""
        with ScopedTiming("display_draw", self.debug_mode > 0):
            osd_img.clear()  # 清除上一帧残留

            if dets:
                # 遍历所有检测到的目标
                for i in range(len(dets[0])):
                    # 获取原始坐标
                    x, y, w, h = map(lambda x: int(round(x, 0)), dets[0][i])

                    # 坐标缩放（模型坐标 -> 显示坐标）
                    x = x * self.display_size[0] // self.rgb888p_size[0]
                    y = y * self.display_size[1] // self.rgb888p_size[1]
                    w = w * self.display_size[0] // self.rgb888p_size[0]
                    h = h * self.display_size[1] // self.rgb888p_size[1]

                    # 绘制黄色边界框
                    osd_img.draw_rectangle(x, y, w, h, color=(255, 255, 0, 255), thickness=2)

                    # 绘制标签和置信度
                    #label_text = f"{self.labels[dets[1][i]]} {round(dets[2][i], 2)}"
                    conf = dets[2][i] / 100.0
                    label_text = f"{self.labels[dets[1][i]]} {conf:.1%}"

                    osd_img.draw_string_advanced(x, y-50, 32, label_text, color=(255, 255, 0, 255))

def thread_AI_detect():


    """YOLOv8目标检测线程函数"""
    global sensor, rgb888p_size, display_size, yolo_osd_img

    # YOLO模型配置
    kmodel_path = "/sdcard/examples/kmodel/yolov8n_224.kmodel"

    labels = ["person", "bicycle", "car", "motorcycle", "airplane", "bus", "train",
              "truck", "boat", "traffic light", "fire hydrant", "stop sign",
              "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep",
              "cow", "elephant", "bear", "zebra", "giraffe", "backpack",
              "umbrella", "handbag", "tie", "suitcase", "frisbee", "skis",
              "snowboard", "sports ball", "kite", "baseball bat", "baseball glove",
              "skateboard", "surfboard", "tennis racket", "bottle", "wine glass",
              "cup", "fork", "knife", "spoon", "bowl", "banana", "apple",
              "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza",
              "donut", "cake", "chair", "couch", "potted plant", "bed",
              "dining table", "toilet", "tv", "laptop", "mouse", "remote",
              "keyboard", "cell phone", "microwave", "oven", "toaster", "sink",
              "refrigerator", "book", "clock", "vase", "scissors", "teddy bear",
              "hair drier", "toothbrush"]

    confidence_threshold = 0.3
    nms_threshold = 0.4

    ob_det = ObjectDetectionApp(kmodel_path, labels=labels,
                                model_input_size=[224,224],
                                max_boxes_num=50,
                                confidence_threshold=confidence_threshold,
                                nms_threshold=nms_threshold,
                                rgb888p_size=rgb888p_size,
                                display_size=display_size,
                                debug_mode=0)
    ob_det.config_preprocess()

    # FPS计算器
    fps = utime.clock()
    fps.tick()
    frame_count = 0

    while True:
        if ai_det_stop:
            break
        if not running:
            yolo_osd_img.clear()
            Display.show_image(yolo_osd_img, 0, 0, Display.LAYER_OSD1)
            utime.sleep_ms(25)
            continue

        # 获取图像并推理
        img_2 = sensor.snapshot(chn=CAM_CHN_ID_2)
        img_np = img_2.to_numpy_ref()

        with lock:

            det_res = ob_det.run(img_np)
            #print(f"running={running}, det_res={det_res}")


        
        

        # 在img_2上直接画框，合并摄像头图像和检测结果后上传
        if det_res and det_res[0]:
            for i in range(len(det_res[0])):
                x, y, w, h = map(lambda v: int(round(v, 0)), det_res[0][i])
                img_2.draw_rectangle(x, y, w, h, color=(255, 0, 0), thickness=2)

        #small = img_2.scale(x_scale=1, y_scale=1)  # 原始尺寸上传
        small = img_2.scale(x_scale=0.5, y_scale=0.5)  # 缩小一半降低传输大小
        jpeg = small.compressed(JPEG_QUALITY)
        queue_put(jpeg)  # 把byte格式发到队列
        del small, jpeg
        # 绘制结果（OSD图层1），fps打印到屏幕
        ob_det.draw_result(yolo_osd_img, det_res)
        yolo_osd_img.draw_string_advanced(0, 0, 24, f"FPS: {fps.fps():.1f}", color=(255, 0, 0))
        Display.show_image(yolo_osd_img, 0, 0, Display.LAYER_OSD1)

        # 打印检测统计
        frame_count += 1
        fps.tick()
        if frame_count % 10 == 0:
            det_count = len(det_res[0]) if det_res else 0
            print(f"[YOLOv8检测] 检测到 {det_count} 个物体, FPS: {fps.fps():.2f}")

        gc.collect()

    ob_det.deinit()

def media_init():

    print("media_init OK")
    global sensor, yolo_osd_img
    Display.init(Display.NT35516, width = DISPLAY_WIDTH, height = DISPLAY_HEIGHT, to_ide = True, osd_num=3)
    sensor = Sensor(fps=30)
    sensor.reset()

    sensor.set_framesize(w = DISPLAY_WIDTH, h = SENSOR_HEIGHT,chn=CAM_CHN_ID_0)
    sensor.set_pixformat(Sensor.YUV420SP)
    sensor.set_framesize(w = rgb888p_size[0], h = rgb888p_size[1], chn=CAM_CHN_ID_2)
    sensor.set_pixformat(Sensor.RGBP888, chn=CAM_CHN_ID_2)

    sensor_bind_info = sensor.bind_info(x = 0, y = 0, chn = CAM_CHN_ID_0)
    Display.bind_layer(**sensor_bind_info, layer = Display.LAYER_VIDEO1)

    yolo_osd_img = image.Image(display_size[0], align_to_8(display_size[1]), image.ARGB8888)

    MediaManager.init()
    sensor.run()
    print("media_init OK")

def media_deinit():
    global sensor
    sensor.stop()
    Display.deinit()
    utime.sleep_ms(100)
    MediaManager.deinit()
    print("media_deinit OK")

def connect():
    global sock
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
        s.settimeout(5)
        s.connect((SERVER_HOST, SERVER_PORT))
        sock = s
        print("TCP连接成功")
    except Exception as e:
        print("TCP连接失败:", e)
        sock = None

def send_frame(jpeg_bytes):
    global sock
    if sock is None:
        connect()
    if sock is None:
        return
    try:
        size = len(jpeg_bytes)
        # 4字节大端长度头
        header = bytes([(size>>24)&0xFF, (size>>16)&0xFF, (size>>8)&0xFF, size&0xFF])
        sock.send(header + jpeg_bytes)
    except Exception as e:
        print("发送失败:", e)
        try: sock.close()
        except: pass
        sock = None

def thread_EC200():
    nic = network.LAN()
    utime.sleep_ms(50)
    print(f"EC200 IP: {nic.ifconfig()[0]}")
    
    connect()
    clock = utime.clock()
    try:
        while True:
            os.exitpoint()
            clock.tick()

            jpeg_byte = queue_get()#从ai模型获取图像
            if jpeg_byte:

                send_frame(jpeg_byte)
    finally:
        if sock:
            sock.close()


def disp_drv_flush_cb(disp_drv, area, color):
    global disp_img1, disp_img2
    if disp_drv.flush_is_last() == True:
        if disp_img1.virtaddr() == uctypes.addressof(color.__dereference__()):
            Display.show_image(disp_img1, LVGL_X, LVGL_Y, Display.LAYER_OSD2)
        else:
            Display.show_image(disp_img2, LVGL_X, LVGL_Y, Display.LAYER_OSD2)
        utime.sleep(0.01)
    disp_drv.flush_ready()

class touch_screen():
    def __init__(self):
        self.state = lv.INDEV_STATE.RELEASED
        self.indev_drv = lv.indev_create()
        self.indev_drv.set_type(lv.INDEV_TYPE.POINTER)
        self.indev_drv.set_read_cb(self.callback)
        self.touch = TOUCH(0)

    def callback(self, driver, data):
        x, y, state = 0, 0, lv.INDEV_STATE.RELEASED
        tp = self.touch.read(1)
        if len(tp):
            x, y, event = tp[0].x, tp[0].y, tp[0].event
            x -= LVGL_X
            y -= LVGL_Y
            if event == 2 or event == 3:
                state = lv.INDEV_STATE.PRESSED
        data.point = lv.point_t({'x': x, 'y': y})
        data.state = state

def lvgl_init():
    global disp_img1, disp_img2
    lv.init()
    disp_drv = lv.disp_create(LVGL_W, LVGL_H)
    disp_drv.set_flush_cb(disp_drv_flush_cb)
    disp_img1 = image.Image(LVGL_W, align_to_8(LVGL_H), image.BGRA8888)
    disp_img2 = image.Image(LVGL_W, align_to_8(LVGL_H), image.BGRA8888)
    disp_drv.set_draw_buffers(disp_img1.bytearray(), disp_img2.bytearray(),
                               disp_img1.size(), lv.DISP_RENDER_MODE.FULL)
    tp = touch_screen()

def lvgl_deinit():
    global disp_img1, disp_img2
    lv.deinit()
    del disp_img1
    del disp_img2

def btn_clicked_event(event):
    global running
    btn = lv.btn.__cast__(event.get_target())
    label = lv.label.__cast__(btn.get_user_data())
    if "on" == label.get_text():
        label.set_text("off")
        running = True
    else:
        label.set_text("on")
        running = False


def user_gui_init():
    scr = lv.scr_act()
    scr.set_style_bg_color(lv.color_hex(0x000000), 0)

    btn = lv.btn(lv.scr_act())
    btn.align(lv.ALIGN.CENTER, 0, 0)
    btn.set_size(80, 40)

    label = lv.label(btn)
    label.set_text('on')
    label.center()

    btn.set_user_data(label)
    btn.add_event(btn_clicked_event, lv.EVENT.CLICKED, None)

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    #硬件启动
    media_init()

    # ai推理+图像发送
    _thread.start_new_thread(thread_AI_detect, ())
    utime.sleep_ms(100)

    # EC200推理到云服务器
    #_thread.start_new_thread(thread_EC200, ())
    utime.sleep_ms(100)

    try:
        lvgl_init()
        user_gui_init()

        while True:
            utime.sleep_ms(lv.task_handler())
            os.exitpoint()
            utime.sleep_ms(5)
    except BaseException as e:
        print(f"程序异常退出: {e}")
        sys.print_exception(e)
        global ai_det_stop
        ai_det_stop = True#停止子线程
        utime.sleep_ms(500)  # 等子线程退出
    finally:
        lvgl_deinit()
        media_deinit()
        gc.collect()

if __name__ == "__main__":
    main()
