import socket
import struct
import threading

from flask import Flask, Response


TCP_HOST = "0.0.0.0"
TCP_PORT = 8080
HTTP_HOST = "0.0.0.0"
HTTP_PORT = 8081
LISTEN_BACKLOG = 5
RECV_CHUNK = 64 * 1024
MAX_FRAME_SIZE = 2 * 1024 * 1024


app = Flask(__name__)

latest_frame = None
latest_frame_id = 0
frame_cond = threading.Condition()
active_conn = None
active_conn_lock = threading.Lock()


def recv_exact(sock, size):
    buf = bytearray(size)
    view = memoryview(buf)
    offset = 0

    while offset < size:
        recv_len = sock.recv_into(view[offset:], min(RECV_CHUNK, size - offset))
        if recv_len <= 0:
            raise ConnectionError("peer closed")
        offset += recv_len

    return buf


def publish_frame(frame_bytes):
    global latest_frame, latest_frame_id
    with frame_cond:
        latest_frame = bytes(frame_bytes)
        latest_frame_id += 1
        frame_cond.notify_all()


def set_active_conn(conn):
    global active_conn
    with active_conn_lock:
        old_conn = active_conn
        active_conn = conn

    if old_conn and old_conn is not conn:
        try:
            old_conn.close()
        except OSError:
            pass


def clear_active_conn(conn):
    global active_conn
    with active_conn_lock:
        if active_conn is conn:
            active_conn = None


def tcp_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((TCP_HOST, TCP_PORT))
    server.listen(LISTEN_BACKLOG)
    print(f"TCP server listening on {TCP_PORT}, waiting for K230...")

    while True:
        conn, addr = server.accept()
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        conn.settimeout(10)
        set_active_conn(conn)
        print(f"K230 connected: {addr}")

        try:
            while True:
                header = recv_exact(conn, 4)
                frame_size = struct.unpack(">I", header)[0]

                if frame_size <= 0 or frame_size > MAX_FRAME_SIZE:
                    raise ValueError(f"invalid frame size: {frame_size}")

                frame = recv_exact(conn, frame_size)
                publish_frame(frame)
        except Exception as exc:
            print(f"K230 disconnected: {exc}")
        finally:
            clear_active_conn(conn)
            try:
                conn.close()
            except OSError:
                pass


@app.route("/")
def index():
    return '<html><body><img src="/stream"></body></html>'


@app.route("/stream")
def stream():
    def generate():
        last_seen_id = -1

        while True:
            with frame_cond:
                while latest_frame is None or latest_frame_id == last_seen_id:
                    frame_cond.wait(timeout=5.0)

                frame = latest_frame
                last_seen_id = latest_frame_id

            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n"
                b"Cache-Control: no-store\r\n"
                b"Content-Length: " + str(len(frame)).encode() + b"\r\n\r\n" +
                frame +
                b"\r\n"
            )

    headers = {
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
    }
    return Response(
        generate(),
        mimetype="multipart/x-mixed-replace; boundary=frame",
        headers=headers,
    )


if __name__ == "__main__":
    tcp_thread = threading.Thread(target=tcp_server, daemon=True)
    tcp_thread.start()
    print(f"Flask listening on {HTTP_PORT}, open /stream in browser")
    app.run(host=HTTP_HOST, port=HTTP_PORT, threaded=True)
