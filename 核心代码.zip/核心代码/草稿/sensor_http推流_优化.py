import network, socket, time, gc, os
from media.sensor import *
from media.media import *
from media.display import *

DISPLAY_WIDTH  = 960
DISPLAY_HEIGHT = 540
SERVER_HOST    = "8.156.80.207"
SERVER_PORT    = 8080
JPEG_QUALITY   = 50

def align_to_8(x):
    return (x // 8) * 8

os.exitpoint(os.EXITPOINT_ENABLE)

nic = network.LAN()
ip = nic.ifconfig()[0]
print(f"EC200 IP: {ip}")

sensor = Sensor()
sensor.reset()
sensor.set_framesize(width=DISPLAY_WIDTH, height=align_to_8(DISPLAY_HEIGHT))
sensor.set_pixformat(Sensor.RGB565)

Display.init(Display.NT35516, DISPLAY_WIDTH, DISPLAY_HEIGHT)
MediaManager.init()
sensor.run()
print(f"推流到: http://{SERVER_HOST}:{SERVER_PORT}/stream")

# ========================
# 复用 socket 发送
# ========================
sock = None

def get_socket():
    global sock
    if sock is None:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
            s.settimeout(5)
            s.connect((SERVER_HOST, SERVER_PORT))
            sock = s
        except Exception as e:
            print("连接失败:", e)
            sock = None
    return sock

def post_jpeg(jpeg_bytes):
    global sock
    sock = None
    try:
        s = get_socket()
        if s is None:
            return
        header = (
            "POST /upload HTTP/1.1\r\n"
            "Host: " + SERVER_HOST + ":" + str(SERVER_PORT) + "\r\n"
            "Content-Type: image/jpeg\r\n"
            "Content-Length: " + str(len(jpeg_bytes)) + "\r\n"
            "Connection: close\r\n"
            "\r\n"
        ).encode()
        s.send(header + jpeg_bytes)
        s.recv(256)
        s.close()
        sock = None
    except Exception as e:
        print("上传失败:", e)
        try:
            sock.close()
        except:
            pass
        sock = None

clock = time.clock()
try:
    while True:
        os.exitpoint()
        clock.tick()
        img = sensor.snapshot()
        Display.show_image(img)

        jpeg = img.compressed(quality=80)
        if jpeg:
            post_jpeg(bytes(jpeg))
            del jpeg

        print(f"fps: {clock.fps():.2f}")
        gc.collect()

finally:
    if sock:
        sock.close()
    sensor.stop()
    Display.deinit()
    time.sleep_ms(100)
    MediaManager.deinit()
    print("资源已释放")
