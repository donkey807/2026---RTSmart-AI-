import network
import socket

nic = network.LAN()
print(f"本机IP: {nic.ifconfig()[0]}")

try:
    HOST = "8.156.80.207"
    PORT = 8080

    body = b"hello"
    header = (
        "POST /upload HTTP/1.1\r\n"
        "Host: 8.156.80.207:8080\r\n"
        "Content-Type: application/octet-stream\r\n"
        "Content-Length: " + str(len(body)) + "\r\n"
        "Connection: close\r\n"
        "\r\n"
    ).encode()

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    s.settimeout(10)
    s.connect((HOST, PORT))
    s.send(header + body)
    resp = s.recv(1024)
    print("服务器响应:", resp)
    s.close()

except Exception as e:
    print("❌ 连接失败:", e)
