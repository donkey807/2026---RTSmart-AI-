'''


BT06进入AT模式：
1：蓝牙模块通过串口连接到pc端，tx连接到pc的rx，rx连接到pc的tx，波特率9600，无校验位，1个停止位，ASCII模式。
2：波特率9600，无校验位，1个停止位，ASCII模式，发送"AT\r\n"响应"OK"

BT06常见AT指令：
指令             响应            说明
AT\r\n           OK             进入AT模式
AT+RESET\r\n     OK             重置蓝牙模块
AT+VERSION\r\n   VERSION=V2.0.2 查询蓝牙版本
AT+NAMEBT06\r\n  NAME=BT06      设置蓝牙名称为BT06
AT+PIN1234\r\n   PIN=1234       设置蓝牙密码为1234

蓝牙模块rx连接到开发板的tx，tx连接到开发板的rx，波特率9600，无校验位，1个停止位，ASCII模式。
通过手机SPP蓝牙串口软件进行交互
'''
# 开发板通过蓝牙模块向PC发送数据（基于UART2）
from machine import UART
from machine import FPIOA
import time

# 1. 引脚复用（和你原来的一样，不用改）
fpioa = FPIOA()
fpioa.set_function(11, FPIOA.UART2_TXD)  # 开发板TX → 蓝牙RX
fpioa.set_function(12, FPIOA.UART2_RXD)  # 开发板RX → 蓝牙TX

# 2. 初始化UART2（适配蓝牙模块，参数和蓝牙一致）
u2 = UART(UART.UART2, baudrate=9600, bits=UART.EIGHTBITS,
          parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)
u2.init(baudrate=9600, bits=UART.EIGHTBITS,
        parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)

# 3. 循环发送数据（修复核心逻辑）
try:
    i = 0
    # 先发送AT指令验证蓝牙模块是否正常
    
    time.sleep(0.5)  # 等待模块响应
    at_response = u2.read()
    if at_response:
        print("蓝牙模块AT响应：", at_response.decode('ascii'))
    else:
        print("未收到蓝牙模块AT响应，请检查接线/模块状态")
    
    # 持续向PC发送数据
    while True:
        read_buf = u2.read()
        if read_buf:  # 先判断是否收到数据
            recv_str = read_buf.decode('ascii').strip()  # 转字符串并去掉换行/空格
            print(f"收到PC数据：{recv_str}")
            
            # 正确判断收到的是"1"
            if recv_str == '1':
                while True:
                    read_buf = u2.read()
                    if read_buf:  # 先判断是否收到数据
                        recv_str = read_buf.decode('ascii').strip()  # 转字符串并去掉换行/空格
                        print(f"收到PC数据：{recv_str},打印中断")
                        if recv_str == '2':
                            break
                    send_data = f"你好世界！第{i}次发送\r\n"
                    u2.write(send_data.encode('utf-8'))
                    print(f"已发送：{send_data}")
                    i += 1
                    time.sleep(1)
except KeyboardInterrupt:
    print("停止发送")
finally:
    u2.deinit()  # 释放UART资源

