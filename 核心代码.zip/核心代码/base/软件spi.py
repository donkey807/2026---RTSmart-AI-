from machine import FPIOA, Pin
import time

fpioa = FPIOA()

# 閰嶇疆寮曡剼锛堟牴鎹綘鐨勫疄闄呭紩鑴氬彿璋冩暣锛�
fpioa.set_function(15, FPIOA.GPIO15)  # CLK
fpioa.set_function(16, FPIOA.GPIO16)  # MOSI
fpioa.set_function(17, FPIOA.GPIO17)  # MISO
fpioa.set_function(14, FPIOA.GPIO14)  # CS

clk  = Pin(15, Pin.OUT)
mosi = Pin(16, Pin.OUT)
miso = Pin(17, Pin.IN)   # 杈撳叆
cs   = Pin(14, Pin.OUT)

# 鍒濆鐘舵€�
clk.value(0)
mosi.value(0)
cs.value(1)  # 榛樿楂樼數骞�

def spi_transfer_byte(tx):
    """鍙戦€佷竴涓瓧鑺傦紝杩斿洖鎺ユ敹鐨勫瓧鑺�"""
    rx = 0
    for i in range(7, -1, -1):  # MSB first
        # 鍑嗗鏁版嵁
        mosi.value((tx >> i) & 1)
        time.sleep_us(1)

        # 涓婂崌娌块噰鏍�
        clk.value(1)
        time.sleep_us(1)

        # 璇诲彇 MISO
        rx = (rx << 1) | miso.value()

        # 涓嬮檷娌�
        clk.value(0)
        time.sleep_us(1)

    return rx

def spi_transfer(tx_buf):
    """鍙戦€佸瓧鑺傛暟缁勶紝杩斿洖鎺ユ敹鐨勫瓧鑺傛暟缁�"""
    cs.value(0)
    time.sleep_us(1)

    rx_buf = bytearray(len(tx_buf))
    for i, b in enumerate(tx_buf):
        rx_buf[i] = spi_transfer_byte(b)

    cs.value(1)
    time.sleep_us(1)
    return rx_buf

# ===== 娴嬭瘯 =====
tx = bytearray([0x11, 0x22, 0x33])
rx = spi_transfer(tx)
print("TX:", [hex(b) for b in tx])
print("RX:", [hex(b) for b in rx])
