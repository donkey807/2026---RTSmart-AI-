#此代码在lcd上显示文字
from media.display import *  # 导入 display 模块，使用 display 相关接口
from media.media import *    # 导入 media 模块，使用 media 相关接口
import os, time, image       # 导入 image 模块，使用 image 相关接口

# 使用 LCD 作为显示输出
Display.init(Display.NT35516, width=960, height=540, to_ide=True)
# 初始化媒体管理器
MediaManager.init()

# 创建用于绘图的图像
img = image.Image(800, 480, image.RGB565)
img.clear()
img.draw_string_advanced(0, 0, 32, "Hello World!，你好世界！！！", color=(255, 0, 0))

Display.show_image(img)

try:
    while True:
        time.sleep(1)
        os.exitpoint()
except KeyboardInterrupt as e:
    print(" 用户停止：", e)
except BaseException as e:
    print(f" 异常：{e}")

Display.deinit()
MediaManager.deinit()
