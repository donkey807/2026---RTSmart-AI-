# 摄像头实时传递数据到终端，并显示FPS

import time, os, sys, gc
from media.sensor import *
from media.display import *
from media.media import *

DISPLAY_WIDTH = 960
DISPLAY_HEIGHT = 536

def align_to_8(x):
    return (x // 8) * 8

# 全局对象，方便释放
sensor = None

def main():
    global sensor
    try:
        # 初始化
        sensor = Sensor()
        sensor.reset()
        sensor.set_framesize(width=DISPLAY_WIDTH, height=align_to_8(DISPLAY_HEIGHT))
        sensor.set_pixformat(Sensor.RGB565)
        Display.init(Display.NT35516, DISPLAY_WIDTH, DISPLAY_HEIGHT)
        MediaManager.init()
        sensor.run()

        clock = time.clock()

        while True:
            clock.tick()
            img = sensor.snapshot()
            Display.show_image(img)
            print("FPS:", clock.fps())
            gc.collect()

    except BaseException as e:
        pass

    finally:
        # ====================== 【关键：无论怎么停止，都会释放资源】======================
        print("🛑 程序停止，释放资源...")
        global sensor
        if sensor is not None:
            sensor.stop()
            del sensor
        Display.deinit()
        MediaManager.deinit()
        gc.collect()

if __name__ == "__main__":
    main()
