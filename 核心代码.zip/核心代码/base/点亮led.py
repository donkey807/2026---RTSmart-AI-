from machine import FPIOA
from machine import Pin
import time

# 打印gpioA的复用脚
fpioa = FPIOA()
# fpioa.help()  # 如果需要查看帮助，取消注释

# 重定义引脚属性
fpioa.set_function(6, FPIOA.GPIO6)  # 配置引脚6为GPIO6功能
LED1 = Pin(6, Pin.OUT)  # 初始化引脚6为输出模式
LED1.value(0)  # 初始化为低电平

for i in range(10):
    while True:
        LED1.value(1)  # 点亮LED
        time.sleep_ms(500)  # 等待500毫秒
        LED1.value(0)  # 熄灭LED
        time.sleep_ms(500)  # 等待500毫秒

