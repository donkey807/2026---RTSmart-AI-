# 使用免驱的Type-A（3.0）摄像头直插rtsmart-ai开发套件上HOST2口，报错：[E/usbh_core] do not support, Interface 0, Class:0x0e,Subclass:0x01,Protocl:0x00
原因：
    CherryUSB 的 UVC Host 驱动未编译进内核
    CHERRY_USB_HOST_ENABLE_CLASS_UVC 
我在canmv_k230根目录下make menuconfig中启用UVC后编译，其未能同步到RTSmart层（menuconfig修改了sdk顶层的.config,修改RTSmart内核的配置系统（canmv_k230/src/rtsmart/rtsmart/kernel/bsp/maix3/rtconfig.h和canmv_k230/src/rtsmart/rtsmart/kernel/bsp/maix3/configs/k230_canmv_dongshanpi_defconfig））

# 注：修改defconfig后，需要删除rtconfig.h重新生产,否则会被旧的配置覆盖



方法：
   # 第一步：src/canmv/port/Makefile中找到
        SRC_QSTR := $(filter-out $(SRC_QSTR_EXCLUDE),$(SRC_QSTR))
        在其上面一行添加modules目录：
        SRC_QSTR += $(wildcard modules/*.c)
   # 第二步：src/rtsmart/rtsmart/kernel/bsp/maix3/components/Kconfig中找到：
        if CHERRY_USB_HC_DRV_DWC2
            config CHERRY_USB_HOST_ENABLE_CLASS_UVC
                bool "Enable UVC"
                default n
        endif
        修改为（跳出if判断）：
        config CHERRY_USB_HOST_ENABLE_CLASS_UVC
            bool "Enable UVC"
            default n
   # 第三步：src/rtsmart/rtsmart/kernel/bsp/maix3/configs/k230_canmv_dongshanpi_defconfig中添加UVC支持

        echo "#define CHERRY_USB_HOST_ENABLE_CLASS_UVC 1" >> rtconfig.h

   # 第四步：
    cd ~/canmv_k230
    make distclean
    make k230_canmv_dongshanpi_defconfig(内部不含CONFIG_CHERRY_USB_HOST_ENABLE_CLASS_UVC=y，因此执行该命令后，要再次echo "CONFIG_CHERRY_USB_HOST_ENABLE_CLASS_UVC=y" >> .config)

    确保 .config 中有 UVC 配置
    echo "CONFIG_CHERRY_USB_HOST_ENABLE_CLASS_UVC=y" >> .config
    make
   # 第五步：再次插入摄像头 
   bcdVDC:0100
    Num of altsettings:2
    Ingore altsetting 0
    Altsetting:1, Ep=82 Attr=05 Mps=1024 Interval=01 Mult=02
    bNumFormats:1
    FormatIndex:1
    FormatType:uncompressed
    bNumFrames:5
    Resolution:
      FrameIndex:1
      wWidth:  640, wHeight:  480, dwDefaultFrameInterval: 333333
      FrameIndex:2
      wWidth:  352, wHeight:  288, dwDefaultFrameInterval: 333333
      FrameIndex:3
      wWidth:  320, wHeight:  240, dwDefaultFrameInterval: 333333
      FrameIndex:4
      wWidth:  176, wHeight:  144, dwDefaultFrameInterval: 333333
      FrameIndex:5
      wWidth:  160, wHeight:  120, dwDefaultFrameInterval: 333333

    无报错并且显示了摄像头相关信息，在Canmv_IDE中运行脚本：
        from media.uvc import UVC
        plugin, devinfo = UVC.probe()
        print(f"摄像头检测: {'已连接' if plugin else '未连接'}, 设备信息: {devinfo}")
    终端日志：
        摄像头检测: 已连接, 设备信息: Generic#USB2.0 PC CAMERA
        MPY: soft reboot
        CanMV 56632348-dirty(based on Micropython e00a144) on 2026-03-21; k230_canmv_dongshanpi with K230

# UVC摄像头传入是YUY2格式，通过以下代码没能正常显示（cvt = True 没能改变图像格式，无img = img.to_rgb888()会代码报错）
UVC.start(cvt = True)
    fps = time.clock()
    while True:
        os.exitpoint()
        fps.tick()
        img = UVC.snapshot()
        if img is not None:
            img = img.to_rgb888()
            Display.show_image(img)
# 摄像头只支持uncompress,但固件只支持mjpeg,期望使用CSC更改图片格式，但是csc.convert 输入 frame 为 py_video_frame_info ，是 sensor.snapshot() 的输出，而非UVC.snapshot()

# 通过k230_uvc_esp8266_server.py发现，uvc拍摄图片是正常显示的，需要解决固件和摄像头之间的兼容问题（不能使用CSC），通过图片保存到路径，在从该路径显示到屏幕倒是可以正常显示，但显然这会导致屏幕及其卡顿甚至非常容易卡死

