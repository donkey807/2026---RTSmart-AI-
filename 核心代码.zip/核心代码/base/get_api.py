import gc
import os
import sys

# --- 1. 配置 ---
SAVE_ROOT = "/sdcard/k230_full_stubs"

# 普通单文件模块列表
SINGLE_MODULES = [
    "_thread",
    "aidemo",
    "array",
    "audio",
    "binascii",
    "camera",
    "cmath",
    "collections",
    "cv_lite",
    "display",
    "errno",
    "fpioa_manager",
    "fft",
    "gc",
    "hashlib",
    "heapq",
    "image",
    "io",
    "i2c",
    "i2c_salve",
    "json",
    "kpu",
    "machine",
    "maix",
    "math",
    "multimedia",
    "neopixel",
    "network",
    "nncase_runtime",
    "nonai2d",
    "np",
    "os",
    "pin",
    "pwm",
    "random",
    "re",
    "rtc",
    "rtt_interface",
    "select",
    "sensor",
    "socket",
    "spi",
    "spi_lcd",
    "ssl",
    "struct",
    "sys",
    "time",
    "touch",
    "uart",
    "ujson",
    "ubinascii",
    "ucollections",
    "uctypes",
    "uerrno",
    "uhashlib",
    "uheapq",
    "uio",
    "ure",
    "urandom",
    "ustruct",
    "utime",
    "uzlib",
    "video",
    "wdt",
    "zlib",
    "Ucryptolib",
    "uos",
    "usb",
    "mpp",
]

# 包结构模块：key 为包名（小写），value 为子模块名（小写）
PACKAGE_MODULES = {
    "libs": ["AI2D", "AIBase", "PipeLine", "utils", "YOLO"],
    "ulab": ["numpy"],
    "mpp": ["payload_struct"],
    # media 也作为包处理
    "media": [
        "audio",
        "camera",
        "display",
        "image",
        "maix",
        "media",
        "sensor",
        "vencoder",
        "video",
        "wave",
        "player",
        "mp4format",
        "pyaudio",
        "vdecoder",
        "uvc",
    ],
}


# --- 2. 初始化环境 ---
def ensure_dir(path):
    try:
        os.mkdir(path)
    except:
        pass


print(f"Target Directory: {SAVE_ROOT}")
ensure_dir(SAVE_ROOT)


# --- 3. 核心写入函数 (通用) ---
def write_item(f, name, obj, indent_lvl=0):
    indent = "    " * indent_lvl
    if name.startswith("__"):
        return

    try:
        obj_type = str(type(obj))

        # 函数/方法
        if "function" in obj_type or "method" in obj_type:
            f.write(
                f"{indent}def {name}(*args, **kwargs):\n{indent}    pass\n\n"
            )

        # 类 (递归写入类成员)
        elif "class" in obj_type or "type" in obj_type:
            f.write(f"{indent}class {name}:\n")
            members = dir(obj)
            has_member = False
            for m in members:
                if not m.startswith("__"):
                    try:
                        has_member = True
                        # 递归调用自己来写类里面的方法/属性
                        val = getattr(obj, m)
                        write_item(f, m, val, indent_lvl + 1)
                    except:
                        pass
            if not has_member:
                f.write(f"{indent}    pass\n")
            f.write("\n")

        # 模块 (作为类处理，用于单文件生成模式)
        elif "module" in obj_type:
            # 只有在非包模式下才把模块写成类
            f.write(f"{indent}class {name}:\n")
            for m in dir(obj):
                if not m.startswith("__"):
                    try:
                        write_item(f, m, getattr(obj, m), indent_lvl + 1)
                    except:
                        pass
            f.write(f"{indent}    pass\n\n")

        # 变量/常量
        elif "int" in obj_type:
            f.write(f"{indent}{name} = {obj}\n")
        elif "str" in obj_type:
            f.write(f"{indent}{name} = '{obj}'\n")
        elif "list" in obj_type:
            f.write(f"{indent}{name} = []\n")
        elif "dict" in obj_type:
            f.write(f"{indent}{name} = {{}}\n")
        else:
            f.write(f"{indent}{name} = None\n")
    except:
        pass


# --- 4. 生成普通单文件模块 (os.py, sys.py 等) ---
def generate_single_file_stubs():
    print("--- Phase 1: Generating Standard Libraries ---")
    for mod_name in SINGLE_MODULES:
        # 跳过 media 相关，由 Phase 2 处理
        if mod_name.startswith("media"):
            continue

        print(f"--> Processing: {mod_name}")
        try:
            mod = __import__(mod_name)
            path = f"{SAVE_ROOT}/{mod_name}.py"
            with open(path, "w") as f:
                f.write(f'"""Stub file for {mod_name}"""\n\n')
                for attr in dir(mod):
                    write_item(f, attr, getattr(mod, attr), 0)
        except ImportError:
            print(f"    Skipped (Not found)")
        except Exception as e:
            print(f"    Error: {e}")
        gc.collect()


# --- 5. 生成  包结构 ---
def generate_package_stubs():
    print("\n=== Phase 2: Generating Package Structures ===")
    for pkg_name, sub_list in PACKAGE_MODULES.items():
        print(f"\n--- Generating package: {pkg_name} ---")
        pkg_dir = f"{SAVE_ROOT}/{pkg_name}"
        ensure_dir(pkg_dir)

        # 1) 生成 __init__.py
        init_path = f"{pkg_dir}/__init__.py"
        print(f"--> Writing {init_path}")

        try:
            pkg = __import__(pkg_name)
            with open(init_path, "w") as f:
                f.write(f'"""Stub for top-level {pkg_name} package"""\n\n')
                for attr in dir(pkg):
                    write_item(f, attr, getattr(pkg, attr), 0)

        except ImportError:
            print("    Error: media module not found!")
            return

        # 5.2 生成子模块文件
        for sub in sub_list:
            module_name = f"{pkg_name}.{sub}"
            file_path = f"{pkg_dir}/{sub}.py"

            print(f"--> Generating {module_name}")

            try:
                exec(f"import {module_name} as m_sub")
                m_sub = locals()["m_sub"]

                with open(file_path, "w") as f:
                    f.write(f'"""Stub for {module_name}"""\n\n')
                    for attr in dir(m_sub):
                        write_item(f, attr, getattr(m_sub, attr), 0)

                print(f"    Saved: {file_path}")
            except ImportError:
                print(f"    Skipped (Not found): media.{sub}")
            except Exception as e:
                print(f"    Error: {e}")
            gc.collect()


# --- 主程序入口 ---
if __name__ == "__main__":
    print("Pre-loading key modules...")

    generate_single_file_stubs()
    generate_package_stubs()
    print("\n================ DONE ================")
    print(f"Stubs saved to: {SAVE_ROOT}")
    print("Please download this folder to your PC.")
